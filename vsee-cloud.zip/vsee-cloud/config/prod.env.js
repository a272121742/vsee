'use strict';
module.exports = {
  NODE_ENV: '"production"',
  // base: '/webppt/vfront/'
};
