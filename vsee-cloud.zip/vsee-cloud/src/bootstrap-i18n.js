import Vue from 'vue';
import VueI18n from 'vue-i18n';
import messages from './lib/auto-i18n';

Vue.use(VueI18n);


const i18n = new VueI18n({
  // TODO: 可配置化
  locale: 'cn',
  // TODO: 可配置化
  fallbackLocale: 'cn',
  messages
  // messages: {
  //   // en: {
  //   //   home: 'home',

  //   //   demo: 'demo',
  //   //   Card1: '卡片',
     
  //   // },
  //   cn: {
  //     home: '主页',

  //     demo: '案例',
  //     Card1: '卡片1',
  //   }
  // }
});

export default i18n;