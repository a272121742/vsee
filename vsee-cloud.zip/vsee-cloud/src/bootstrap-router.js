import Vue from 'vue';
import VueRouter from 'vue-router';
import localRouters from '@/lib/auto-router';

Vue.use(VueRouter);

/**
 * 路由的加载规则
 * 1. 默认只加载非应用功能，例如/login、/404、/403、/500等
 * 2. 用户登陆后，根据路由权限动态加载模块中的路由
 */
export const homeRouter = [{
  path: '/',
  meta: {
    title: 'home',
    // requireAuth: true
  },
  name: 'home',
  component: () => import('@/modules/layout/view/default.vue'), // @TODO: 配置化
  children: []
  /**
   * @TODO: 
   * {
    // 主页如何设置？
    path: '/',
    component: () => import('@/modules/SimulationOperation/router/SimulationProjectManagement.vue'),
  }
   */
}];

export const router = new VueRouter({
  base: '/',
  mode: 'history',
  routes: localRouters.systemRouters
});

export const appRouters = localRouters.appRouters;
