export const filterModules = [
  'demo',
  // 'table',
  // 'SimulationOperation',
  // 'ModelManagement'
];

export const main_portal_name = 'SimulationProjectManagement';

export const API_PREFIX = '/api';

/**
 * 自动引入的模块
 */
export const auto_requires = {
  // 路由模块
  router: require.context('@/modules', true, /^\.\/[A-Za-z][A-Za-z0-9_]*\/router\/[A-z0-9- ./]+\.vue$/),
  // 数据缓存模块
  store: require.context('@/modules', true, /^\.\/[A-Za-z][A-Za-z0-9_]*\/store\/index\.js$/),
  // 国际化模块
  i18n: require.context('@/modules', true, /^\.\/[A-Za-z][A-Za-z0-9_]*\/locales\/[A-Za-z]+\.json$/),
  directives: require.context('@/directives', true, /^\.\/v-\w*\.js$/)
};