<template>
  <div style="height: 100%; width: 100%; display: table;">
    <div style="display: table-cell; vertical-align: middle; text-align: center;">
      <div>
        加载错误
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

