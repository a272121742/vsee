import AsyncComponent from './AsyncComponent';
import asyncComponentFactory from './factory';

export default AsyncComponent;
export const factory = asyncComponentFactory;