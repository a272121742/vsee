<template>
  <div class="affix-buttons">
    <a-affix
      :offset-top="top"
      :style="{ position: 'absolute', top: `${top}px`, right: '-12px'}"
    >
      <slot></slot>
    </a-affix>
  </div>
</template>

<script>
export default {
  props: {
    top: {
      type: Number,
      default: 0
    }
  },
  data () {
    return {
    }
  },
  mounted () {
    const vm = this;
    const slots = vm.$slots.default;
    console.log(slots);
  }
}

function isEmptyElement (c) {
  return !(c.tag || (c.text && c.text.trim() !== ''));
}
function filterEmpty (children = []) {
  return children.filter(isEmptyElement);
}
</script>

<style lang="less" scoped>
.affix-buttons {
  /deep/ .ant-btn {
    width: auto;
    margin-right: -38px;
    // opacity: 0.65;
    text-align: left;
    &:hover {
      // opacity: 1;
      margin-right: 0px;
    }
  }
  /deep/ .anticon {
    margin-left: -12px;
  }
}
</style>
