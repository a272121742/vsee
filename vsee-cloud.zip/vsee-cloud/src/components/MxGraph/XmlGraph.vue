<template>
  <div>
    <div>
      <a-button
        :disabled="!selectedCells"
        @click="handleRemoveSelected"
      >
        删除
      </a-button>
      <a-button
        :disabled="!undoable"
        @click="handleUndo"
      >
        撤销
      </a-button>
      <a-button
        :disabled="!redoable"
        @click="handleRedo"
      >
        重做
      </a-button>
    </div>
    <div ref="mx-container"></div>
  </div>
</template>

<script>
import mx from '@lib/mx';
import {map} from 'ramda';
const XmlElementNamed_mxGraphModel = 'mxGraphModel';
const XmlElementNamed_mxCell = 'mxCell';


export default {
  props: {
    // 传入的字符串xml或者xml地址（TODO:后期做判断处理）
    xml: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      graph: null,
      undoManager: null,
    };
  },
  computed: {
    selectedCells () {
      return this.graph && this.graph.getSelectionCount()
    },
    undoable () {
      const {graph, undoManager} = this;
      return graph && undoManager && undoManager.indexOfNextAdd && undoManager.history.length;
    },
    redoable () {
      const {graph, undoManager} = this;
      return graph && undoManager && undoManager.indexOfNextAdd !== undoManager.history.length;
    }
  },
  mounted () {
    this.container = this.$refs['mx-container']
    this.initGraph();
    this.listenEvent();
  },
  methods: {
    // 初始化Graph
    initGraph () {
      // 实例化图形
      const graph = this.graph = new mx.mxGraph(this.container);
      // 获取xml文档对象
      const xmlDocument = mx.mxUtils.parseXml(this.xml);
      if (xmlDocument.documentElement != null && xmlDocument.documentElement.nodeName === XmlElementNamed_mxGraphModel) {
        // 获取解码器
        const decoder = new mx.mxCodec(xmlDocument);
        // 获取xml文档根节点
        const root = xmlDocument.documentElement;
        // 将xml解码到图形模型中
        decoder.decode(root, graph.getModel());
      }
      this.configuration();
      this.addUndoManager();
      window.graph = graph;
      window.mx = mx;
    },
    configuration () {
      const { graph } = this;
      // 设置可以连接
      graph.setConnectable(true);
      // 自己无法连接自己
      graph.setAllowLoops(false);
      // 可否重复连接 
      graph.setMultigraph(false); 
      // 不允许图形改变大小
      graph.setCellsResizable(false);
      // 不允许拖动连线
      graph.setAllowDanglingEdges(false);
      // 设置不添加连线端口
      graph.setPortsEnabled(false);
      // 开启指引功能
      mx.mxGraphHandler.prototype.guidesEnabled = true;
      // 选择基本元素开启
      graph.setEnabled(true);
    },
    listenEvent () {
      const vm = this;
      this.graph.dblClick =  function (e, cell) {
        const graph = this;
        if (graph.isEnabled() && !mx.mxEvent.isConsumed(e) && graph.isCellEditable(cell) && graph.model.isVertex(cell)) {
          vm.$emit('event:dblClick', graph, cell, e);
        }
      };
    },
    // 添加撤销监听器
    addUndoManager () {
      const { graph } = this;
      const undoManager = this.undoManager = new mx.mxUndoManager();
      const listener = function (sender, evt) {
        undoManager.undoableEditHappened(evt.getProperty('edit'));
      };
      graph.getModel().addListener(mx.mxEvent.UNDO, listener);
      graph.getView().addListener(mx.mxEvent.UNDO, listener);
      graph.getModel().addListener(mx.mxEvent.REDO, listener);
      graph.getView().addListener(mx.mxEvent.REDO, listener);
      this.undoManager = undoManager;
      window.undoManager = undoManager;
    },
    // 追加Graph
    addGraph (xml) {
      // 实例化图形
      const graph = this.graph;
      // 获取xml文档对象
      const xmlDocument = mx.mxUtils.parseXml(xml);
      // 获取解码器
      const decoder = new mx.mxCodec(xmlDocument);
      // 获取xml文档的mxCell节点
      const cells = xmlDocument.getElementsByTagName(XmlElementNamed_mxCell);
      graph.addCells(map(cell => decoder.decode(cell), cells));
    },
    // 加载Graph
    loadGraph (xml) {
      this.clearGraph();
      this.addGraph(xml);
    },
    // 清除所有图形
    clearGraph () {
      // 实例化图形
      const graph = this.graph;
      graph.removeCells(graph.getChildVertices(graph.getDefaultParent()));
    },
    // 获取模型对象
    getModel () {
      return this.graph.getModel();
    },
    getXml () {
      var enc = new mx.mxCodec(mx.mxUtils.createXmlDocument());
      var node = enc.encode(this.graph.getModel());
      return mx.mxUtils.getXml(node);
    },
    add (callback) {
      callback(this.graph);
    },
    // 删除选中
    handleRemoveSelected () {
      const { graph } = this;
      const selectedCells = graph.getSelectionCells();
      graph.removeCells(selectedCells);
    },
    // 撤销
    handleUndo () {
      const { undoManager } = this;
      if (undoManager) {
        undoManager.undo();
      }
    },
    handleRedo () {
      const { undoManager } = this;
      if (undoManager) {
        undoManager.redo();
      }
    }
  }
}
</script>

