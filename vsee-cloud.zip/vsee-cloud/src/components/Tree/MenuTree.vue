<template>
  <div>
    <a-input-search
      v-if="search"
      placeholder="请输入搜索内容"
      style="width: 100%; margin-bottom: 1rem"
      @search="handleSearch"
    />
    <a-menu
      class="menu-tree"
      mode="inline"
      :default-open-keys="defaultOpenKeys"
      @click="handleItemClick"
    >
      <keep-alive>
        <item-edit
          v-if="!shownOnly"
          ref="ModalForm"
          :title="formTitle"
          :visible="showEditModalForm"
          @ok="handleEditOk"
          @close="handleEditCancel"
        >
        </item-edit>
      </keep-alive>
    
      <a-sub-menu
        v-for="parent in dataSource"
        :key="parent.key"
      >
        <span slot="title">
          {{ parent.title }}
          <a-icon
            type="plus"
            class="action-add"
            v-if="!shownOnly"
            @click="(e) => handleAdd(e, parent)"
          />
        </span>
        <template v-if="parent.children && parent.children.length">
          <a-menu-item
            v-for="child in parent.children"
            :key="child.key"
          >
            {{ child.title }}
            <a-icon
              type="edit"
              class="action-edit"
              v-if="!shownOnly"
              @click="(e) => handleEdit(e, child)"
            />
            <a-icon
              type="delete"
              class="action-delete"
              v-if="!shownOnly"
              @click="(e) => handleDelete(e, child)"
            />
          </a-menu-item>
        </template>
      </a-sub-menu>
    </a-menu>
  </div>
</template>

<script>
export default {
  // 菜单树
  name: 'MenuTree',
  components: {
    // StdnodeModalForm
    ItemEdit: () => import('./MenuTreeItemEdit.vue')
  },
  props: {
    // 数据源
    dataSource: {
      type: Array,
      default: () => []
    },
    // 是否默认展开第一项
    defaultOpenFirst: {
      type: Boolean,
      default: true
    },
    // 是否启用搜索
    search: {
      type: Boolean,
      default: false
    },
    // 是否仅用于展示
    shownOnly: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      // 默认展开项
      defaultOpenKeys: [],
      // 表单标题
      formTitle: '',
      // 是否现实弹出表单
      showEditModalForm: false,
      // 是否加载表单数据
      confirmFormLoading: true,
    }
  },
  created () {
    // 设置默认展开项
    if (this.defaultOpenFirst && this.dataSource[0]) {
      this.$set(this, 'defaultOpenKeys', [this.dataSource[0].key]);
    }
  },
  methods: {
    handleSearch (text) {
      console.log('正在搜索', text);
    },
    // 点击确认后
    handleEditOk (data, next) {
      const emitEvent = data.id ? 'onEdit' : 'onAdd';
      this.$emit(emitEvent, data, success => {
        if (success !== false) {
          this.$message.success('保存成功！');
          this.showEditModalForm = false;
        } else {
          this.$message.error('保存失败！');
        }
      });
    },
    handleEditCancel () {
      this.$refs.ModalForm.load({});
      this.showEditModalForm = false;
    },
    /**
     * 编辑事件
     * @param {*} e 
     * @param {*} item 
     * @private
     */
    handleAdd (e, item) {
      e.stopPropagation();
      this.showEditModalForm = true;    // 显示弹窗
      this.formTitle  = '新增模型';      // 修改标题
      this.confirmFormLoading = false;  // 取消表单加载
      this.$refs.ModalForm.load(item);   // 表单加载数据
    },
    /**
     * 编辑事件
     * @param {*} e 
     * @param {*} item 
     * @private
     */
    handleEdit (e, item) {
      e.stopPropagation();
      this.showEditModalForm = true;    // 显示弹窗
      this.formTitle  = '编辑模型';      // 修改标题
      this.confirmFormLoading = false;  // 取消表单加载
      this.$refs.ModalForm.load(item);  // 表单加载数据
    },
    /**
     * 删除事件
     * @param {*} e 鼠标点击事件
     * @param {*} item 
     */
    handleDelete (e, item) {
      e.stopPropagation();
      // 触发上层组件`onDelete`方法，并传递item数据
      this.$emit('onDelete', item);
    },
    handleItemClick (record) {
      const list = this.dataSource.find(item => item.key === record.keyPath[1]).children;
      const data = list.find(item => item.key === record.key);
      this.$emit('onSelect', {...record, data});
    }
  },
  
}
</script>

<style lang="less" >
.menu-tree {
  min-width: 120px;
  .ant-menu-item {
    .action-edit, .action-delete {
      display: none;
    }
    &:hover {
      .action-edit, .action-delete {
        display: block;
      }
    }
  }
  .ant-menu-submenu-title {
    .action-add {
      display: none;
    }
    &:hover {
      .action-add {
        display: block;
      }
    }
  }
  .action-add, .action-edit, .action-delete {
    z-index: 1200;
    position: absolute;
    height: 40px;
    line-height: 40px;
    bottom: 0px;
    right: 30px;
    display: block;
    color: #1890ff
  }
  
   .action-delete {
    right: 6px;
  }
  
}
</style>


