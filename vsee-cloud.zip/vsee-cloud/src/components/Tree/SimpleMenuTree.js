import { Menu, Icon, Input } from 'ant-design-vue'

const { Item, SubMenu } = Menu
const { Search } = Input

export default {
  // 简单菜单树
  name: 'SimpleMenuTree',
  props: {
    // 数据源
    dataSource: {
      type: Array,
      default: () => []
    },
    // 默认展开项
    openKeys: {
      type: Array,
      default: () => []
    },
    // 是否启用搜索
    search: {
      type: Boolean,
      default: false
    }
  },
  created () {
    this.$set(this, 'data', this.dataSource);
    this.localOpenKeys = this.openKeys.slice(0);
  },
  data () {
    return {
      data: [],
      localOpenKeys: []
    }
  },
  methods: {
    /**
     * 渲染数据
     * @param {*} data - 数据源
     * @public
     */
    render (data) {
      this.$set(this, 'data', data);
    },
    /**
     * 渲染搜索框
     * @private
     */
    renderSearch () {
      return (
        <Search
          placeholder="input search text"
          style="width: 100%; margin-bottom: 1rem"
        />
      )
    },
    /**
     * 渲染图标
     * @param {*} icon - 图标类
     * @private
     */
    renderIcon (icon) {
      return icon && (<Icon type={icon} />) || null
    },
    /**
     * 渲染菜单项
     * @param {*} item 
     * @private
     */
    renderMenuItem (item) {
      return (
        <Item key={item.key}>
          { this.renderIcon(item.icon) }
          { item.title }
          <div class="btn-actions">
            <a class="btn-action" style="width: 20px;z-index:1300" {...{ on: { click: (e) => this.handleEdit(e, item) } }}><a-icon type="edit"/></a>
            <a class="btn-action" style="width: 20px;z-index:1300" {...{ on: { click: (e) => this.handleDelete(e, item) } }}><a-icon type="delete"/></a>
          </div>
        </Item>
      )
    },
    /**
     * 渲染项
     * @param {*} item 
     * @private
     */
    renderItem (item) {
      return item.children ? this.renderSubItem(item, item.key) : this.renderMenuItem(item, item.key)
    },
    /**
     * 渲染子项
     * @param {*} item 
     * @param {*} key 
     */
    renderSubItem (item, key) {
      const childrenItems = item.children && item.children.map(o => {
        return this.renderItem(o, o.key)
      })
      const title = (
        <span slot="title">
          { this.renderIcon(item.icon) }
          <span>{ item.title }</span>
          <a class="btn-action" style="width: 20px;z-index:1700" {...{ on: { click: (e) => this.handleEdit(e, item) } }}><a-icon type="plus"/></a>
        </span>
      )
      return (
        <SubMenu key={key}>
          { title }
          { childrenItems }
        </SubMenu>
      )
    },
    /**
     * 编辑事件
     * @param {*} e 
     * @param {*} item 
     * @private
     */
    handleEdit (e, item) {
      e.stopPropagation();
      this.$emit('edit', item);
      return false;
    },
    /**
     * 删除事件
     * @param {*} e 
     * @param {*} item 
     */
    handleDelete (e, item) {
      e.stopPropagation();
      this.$emit('delete', item);
      return false;
    },
  },
  render () {
    const { search } = this.$props;
    const list = this.data.map(item => {
      return this.renderItem(item);
    });
    return (
      <div class="tree-wrapper">
        { search ? this.renderSearch() : null }
        <Menu mode="inline" class="custom-tree" {...{ on: { click: item => this.$emit('click', item), 'update:openKeys': val => { this.localOpenKeys = val } } }} openKeys={this.localOpenKeys}>
          { list }
        </Menu>
      </div>
    )
  }
}