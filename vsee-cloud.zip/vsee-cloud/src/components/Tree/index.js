import { Menu, Icon, Input } from 'ant-design-vue'

const { Item, SubMenu } = Menu
const { Search } = Input

export default {
  name: 'Tree',
  props: {
    dataSource: {
      type: Array,
      required: true
    },
    openKeys: {
      type: Array,
      default: () => []
    },
    search: {
      type: Boolean,
      default: false
    }
  },
  created () {
    this.localOpenKeys = this.openKeys.slice(0)
  },
  data () {
    return {
      localOpenKeys: []
    }
  },
  methods: {
    handleEdit (e, item) {
      e.stopPropagation();
      this.$emit('edit', item);
      return false;
    },
    handleDelete (e, item) {
      e.stopPropagation();
      this.$emit('delete', item);
      return false;
    },
    renderSearch () {
      return (
        <Search
          placeholder="input search text"
          style="width: 100%; margin-bottom: 1rem"
        />
      )
    },
    renderIcon (icon) {
      return icon && (<Icon type={icon} />) || null
    },
    renderMenuItem (item) {
      return (
        <Item key={item.key}>
          { this.renderIcon(item.icon) }
          { item.title }
          <div class="btn-actions">
            <a class="btn-action" style="width: 20px;z-index:1300" {...{ on: { click: (e) => this.handleEdit(e, item) } }}><a-icon type="edit"/></a>
            <a class="btn-action" style="width: 20px;z-index:1300" {...{ on: { click: (e) => this.handleDelete(e, item) } }}><a-icon type="delete"/></a>
          </div>
        </Item>
      )
    },
    renderItem (item) {
      return item.children ? this.renderSubItem(item, item.key) : this.renderMenuItem(item, item.key)
    },
    renderSubItem (item, key) {
      const childrenItems = item.children && item.children.map(o => {
        return this.renderItem(o, o.key)
      })
      const title = (
        <span slot="title">
          { this.renderIcon(item.icon) }
          <span>{ item.title }</span>
          <a class="btn-action" style="width: 20px;z-index:1700" {...{ on: { click: (e) => this.handleEdit(e, item) } }}><a-icon type="plus"/></a>
        </span>
      )
      return (
        <SubMenu key={key}>
          { title }
          { childrenItems }
        </SubMenu>
      )
    }
  },
  render () {
    const { dataSource, search } = this.$props

    // this.localOpenKeys = openKeys.slice(0)
    const list = dataSource.map(item => {
      return this.renderItem(item)
    })

    return (
      <div class="tree-wrapper">
        { search ? this.renderSearch() : null }
        <Menu mode="inline" class="custom-tree" {...{ on: { click: item => this.$emit('click', item), 'update:openKeys': val => { this.localOpenKeys = val } } }} openKeys={this.localOpenKeys}>
          { list }
        </Menu>
      </div>
    )
  }
}