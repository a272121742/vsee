<template>
  <a-modal
    :title="title"
    :width="600"
    :visible="visible"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-spin :spinning="spinning">
      <a-form :form="form">
        <a-form-item
          label="类型"
        >
          <a-input
            v-decorator="['type', {}]"
            disabled
          />
        </a-form-item>

        <a-form-item
          label="名称"
        >
          <a-input v-decorator="['name', {}]" />
        </a-form-item>
      </a-form>
    </a-spin>
  </a-modal>
</template>

<script>
import { clone, merge } from 'ramda';
import { clearObserver } from '@lib/util';
/**
 * 菜单项编辑组件
 */
export default {
  name: 'MenuTreeItemEdit',
  props: {
    /**
     * 表单标题
     */
    title: {
      type: String,
      default: ''
    },
    /**
     * 弹出`Modal`是否可视
     */
    visible: {
      type: Boolean,
      default: false
    },
    /**
     * 表单是否现实加载动画
     */
    spinning: {
      type: Boolean,
      default: false
    },
    /**
     * 外层组件传入数据
     */
    record: {
      type: Object,
      default: () => ({
        type: '',
        name: ''
      })
    }
  },
  data () {
    return {
      /**
       * 表单组件的内层数据
       */
      data: {
        type: '',
        name: ''
      },
      form: null,
    }
  },
  created () {
    const vm = this;
    this.$set(this, 'data', clone(this.record));
    this.form = this.$form.createForm(this, {
      mapPropsToFields: () => {
        return {
          type: this.$form.createFormField({
            value: this.data.type,
          }),
          name: this.$form.createFormField({
            value: this.data.name,
          }),
        };
      },
      onValuesChange (_, values) {
        vm.$set(vm, 'data', merge(clearObserver(vm.data), values));
      },
    })
  },
  
  methods: {
    load (data) {
      this.$set(this, 'data', clearObserver(data));
      const { type, name } = data;
      this.$nextTick(() => {
        this.form.setFieldsValue({type, name});
      });
    },
    handleOk () {
      this.$emit('ok', clearObserver(this.data));
    },
    handleCancel () {
      this.$emit('close');
    },
  }
}
</script>
