<template>
  <div class="editor">
    <div class="top-container">
      <div
        class="toolbar"
        ref="toolbar"
      >
        <a-tooltip placement="bottom">
          <template #title>
            <span>撤销</span>
          </template>
          <i
            data-command="undo"
            class="command iconfont icon-undo"
          ></i>
        </a-tooltip>
        <a-tooltip placement="bottom">
          <template #title>
            <span>重做</span>
          </template>
          <i
            data-command="redo"
            class="command iconfont icon-redo disable"
          ></i>
        </a-tooltip>
        
        <a-divider type="vertical" />
        <a-tooltip placement="bottom">
          <template #title>
            <span>复制</span>
          </template>
          <i
            data-command="copy"
            class="command iconfont icon-copy-o"
          ></i>
        </a-tooltip>
        <a-tooltip placement="bottom">
          <template #title>
            <span>粘贴</span>
          </template>
          <i
            data-command="paste"
            class="command iconfont icon-paster-o disable"
          ></i>
        </a-tooltip>
        <a-tooltip placement="bottom">
          <template #title>
            <span>删除</span>
          </template>
          <i
            data-command="delete"
            class="command iconfont icon-delete-o"
          ></i>
        </a-tooltip>
        <a-divider type="vertical" />
        <a-tooltip placement="bottom">
          <template #title>
            <span>放大</span>
          </template>
          <i
            data-command="zoomIn"
            class="command iconfont icon-zoom-in-o"
          ></i>
        </a-tooltip>
        <a-tooltip placement="bottom">
          <template #title>
            <span>缩小</span>
          </template>
          <i
            data-command="zoomOut"
            class="command iconfont icon-zoom-out-o"
          ></i>
        </a-tooltip>
        <a-tooltip placement="bottom">
          <template #title>
            <span>适应画布</span>
          </template>
          <i
            data-command="autoZoom"
            class="command iconfont icon-fit"
          ></i>
        </a-tooltip>
        <a-tooltip placement="bottom">
          <template #title>
            <span>实际尺寸</span>
          </template>
          <i
            data-command="resetZoom"
            class="command iconfont icon-actual-size-o"
          ></i>
        </a-tooltip>
        <a-divider type="vertical" />
        <a-tooltip placement="bottom">
          <template #title>
            <span>层级后置</span>
          </template>
          <i
            data-command="toBack"
            class="command iconfont icon-to-back"
          ></i>
        </a-tooltip>
        <a-tooltip placement="bottom">
          <template #title>
            <span>层级前置</span>
          </template>
          <i
            data-command="toFront"
            class="command iconfont icon-to-front"
          ></i>
        </a-tooltip>
        <span class="separator"></span>
        <a-tooltip placement="bottom">
          <template #title>
            <span>多选</span>
          </template>
          <i
            data-command="multiSelect"
            class="command iconfont icon-select"
          ></i>
        </a-tooltip>
      </div>
      <div class="data-opt">
        <!-- <a-button
          size="small"
          type="primary"
          @click="download"
        >
          下载
        </a-button> -->
        <a-button
          size="small"
          type="primary"
          :disabled="disableSave"
          @click="save"
        >
          保存
        </a-button>
        <slot name="action">
        </slot>
      </div>
    </div>
    <div class="bottom-container">
      <div class="left-pannel">
        <div
          class="itempannel-container"
          ref="itempannel"
        >
          <!-- 通过attr的形式注入属性-->
          <a-collapse
            v-if="Object.keys(itemGroup).length"
            :active-key="activeKey"
            :bordered="false"
          >
            <a-collapse-panel
              v-for="(itemList, type) in itemGroup"
              :header="type"
              :key="type"
            >
              <template v-if="itemList && itemList.length">
                <a-popover
                  v-for="item in itemList"
                  :key="item.name"
                  placement="right"
                >
                  <template #content>
                    <slot :item="item"></slot>
                  </template>
                  <img
                    :src="item.src"
                    draggable="false"
                    data-type="node"
                    :data-shape="item.name"
                    data-size="102*102"
                    data-color="#FA8C16"
                    :data-label="item.name"
                    class="getItem"
                  />
                </a-popover>
              </template>
            </a-collapse-panel>
          </a-collapse>
        </div>
      </div>
      <div class="center-pannel">
        <div
          class="flow"
          ref="flow"
        ></div>
        <div
          class="contextmenu"
          ref="contextmenu"
          style="position: absolute; z-index: 2;"
        >
          <div
            data-status="node-selected"
            class="menu"
            style="display: none;"
          >
            <div
              data-command="copy"
              class="command iconfont icon-copy-o disable"
            >
              <span>复制</span>
            </div>
            <div
              data-command="delete"
              class="command iconfont icon-delete-o disable"
            >
              <span>删除</span>
            </div>
          </div>
          <div
            data-status="edge-selected"
            class="menu"
            style="display: none;"
          >
            <div
              data-command="delete"
              class="command iconfont icon-delete-o disable"
            >
              <span>删除</span>
            </div>
          </div>
          <div
            data-status="group-selected"
            class="menu"
            style="display: none;"
          >
            <div
              data-command="copy"
              class="command iconfont icon-copy-o disable"
            >
              <span>复制</span>
            </div>
            <div
              data-command="delete"
              class="command iconfont icon-delete-o disable"
            >
              <span>删除</span>
            </div>
          </div>
          <div
            data-status="canvas-selected"
            class="menu"
            style="display: block;"
          >
            <div
              data-command="undo"
              class="command iconfont icon-undo disable"
            >
              <span>撤销</span>
            </div>
            <div
              data-command="redo"
              class="command iconfont icon-redo disable"
            >
              <span>重做</span>
            </div>
            <div
              data-command="pasteHere"
              class="command iconfont icon-paster-o disable"
            >
              <span>粘贴</span>
            </div>
          </div>
          <div
            data-status="multi-selected"
            class="menu"
            style="display: none;"
          >
            <div
              data-command="copy"
              class="command iconfont icon-copy-o disable"
            >
              <span>复制</span>
            </div>
            <div
              data-command="paste"
              class="command iconfont icon-paster-o disable"
            >
              <span>粘贴</span>
            </div>
            <div
              data-command="delete"
              class="command iconfont icon-delete-o disable"
            >
              <span>删除</span>
            </div>
          </div>
        </div>
      </div>
      <div
        class="right-pannel"
      >
        <a-icon
          class="attr-editable-button"
          type="double-left"
          @click=" e => attrEditable = true"
        />
      </div>
      <a-drawer
        title="属性编辑"
        placement="right"
        get-container=".right-pannel"
        :mask-closable="false"
        :visible="attrEditable"
        @close="e => attrEditable = false"
      >
        <slot name="attr"></slot>
      </a-drawer>
    </div>
  </div>
</template>

<script>
import { groupBy, prop, find, propEq, concat, partialRight, contains } from 'ramda';
/**
 * 参考 http://antvis.github.io/g6/api/item.html
 *     https://www.yuque.com/antv/g6/graph
 * -G6Editor整体框架元素介绍：
 *  editor: {                 // 即`G6Editor`，编辑器的实例；
 *    graph: {                // 编辑器中图形模块，包含了左边`itempanel`，右边的`minimap`等，都是用`graph`绘制的；
 *      model:                // 图形模块的数据模型；
 *      page: {               // 图形模块中的当前页，即中间绘图部分；
 *        flow                // 流程图实例
 *      }
 *    },
 *    toolbar:                // 顶部工具栏
 *    contextmenu:            // page中的右键菜单
 *    itempanel:              // 左边的元素项目
 *    detailpanel:            // 右边的详情页
 *    commandcontroller:      // 命令控制器
 *  }
 */
import G6Editor from '@antv/g6-editor';
window.G6Editor = G6Editor;
/**
 * 线条高光
 */
const highlightEdge = shape => {
  shape.attr('stroke', '#1890ff');
  shape.attr('lineWidth', 2);
};
/**
 * 线条无光
 */
const unlightEdge = shape => {
  shape.attr('stroke', '#79838e');
  shape.attr('lineWidth', 1);
};



const Util = G6Editor.Util;
G6Editor.registerEdge('custom-flow-polyline-round', {
  afterDraw (edge) {
    const shape = edge.group.get('children')[0];
    console.log('拖拽线条后，可用于重绘线条',shape);
  }
  // getPathByPoints (t) {

  // }
}, 'flow-polyline-round');
// G6.registerEdge('customEdge', {
//   draw(cfg, group) {
//     const startPoint = cfg.startPoint;
//     const endPoint = cfg.endPoint;
//     const shape = group.addShape('path', {
//       attrs: {
//         path: [['M', startPoint.x, startPoint.y], ['L', endPoint.x, endPoint.y]],
//         stroke: cfg.color,
//         lineWidth: cfg.size
//       }
//     });
//     // 添加文本、更多图形
//     return shape;
//   }
// });

/**
 * 术语讲解：
 *  node: 节点，即拖拽到`graph`或`page`上的一个个的元素；
 *  edge: 边，即节点与节点之间的连线，`node`的外边框实际上也是`edge`；
 *  anchor: 锚点，挂载`edge`的实际上是锚点；
 */
export default {
  name: 'BaseFlow',
  components: {

  },
  props: {
    /**
     * 画板数据
     */
    data: {
      type: Object,
      default: () => ({})
    },
    /**
     * 流程图节点定义
     * 格式： Array<Node>
     * Node: 
     *   {
     *     name: '', // 名称
     *     anchor: [], // 锚点集,
     *     group: '', // 分组
     *   }
     */
    items: {
      type: Array,
      default: () => ([])
    },
    /**
     * 数据映射函数
     * 此函数用于分离图形编辑器的内部业务和外部的实际业务，避免耦合
     * @param {*} node - 图的节点对象
     * @param {*} item - 外部传入的业务对象 
     */
    dataMapping: {
      type: Function,
      default: () => {}
    }
  },
  data () {
    return {
      /**
       * `G6Editor`编辑器实例
       */
      editor: null,
      /**
       * 绘制图形区域的页面，本案例特指`getCurrentPage`当前页，
       * 未来可能会增加多页面、多图层的概念；
       */
      page: null,
      /**
       * 流程图实例
       */
      flow: null,
      /**
       * 图形模块的实例，内置数据绑定的模型`Mode`;
       */
      graph: null,
      /**
       * 节点唯一id
       * 节点不包含`edge`
       */
      nodeId: null,
      /**
       * 节点名称
       */
      nodeName: null,
      /**
       * 节点宽度
       */
      nodeWidth: null,
      /**
       * 节点高度
       */
      nodeHeight: null,
      /**
       * 节点颜色
       */
      nodeColor: null,
      /**
       * 组编号
       */
      groupId: null,
      /**
       * 组名称
       */
      groupName: null,
      /**
       * 组颜色
       */
      groupColor: null,
      /**
       * 边的唯一id
       */
      edgeId: null,
      /**
       * 边名称
       */
      edgeName: null,
      /**
       * 多选模式中，所选所有元素的id集合，包含`node`和`edge`；
       */
      multiId: [],
      /**
       * 多选模式下的color，仅以最后一个为代表颜色
       */
      multiColor: null,
      /**
       * 是否是多选模式
       */
      isMultiSelect: false,
      /**
       * 缩放百分比，实际值为`zoomRatio / 100`，是一个百分比的值
       */
      zoomRatio: 100,
      // -----------------------以下为拓展实际需求，是自己加的------------------------//
      /**
       * `itempanel`的分组数据，从外部传入
       */
      itemGroup: {'':[]},
      activeKey: '',
      /**
       * 是否允许保存，当发生历史性变化的时候，才允许保存
       */
      disableSave: true,
      /**
       * 属性编辑
       */
      attrEditable: true,
    }
  },
  watch: {
    nodeName (newValue) {
      this.flow.update(this.nodeId, {
        label: newValue
      })
    },
    nodeWidth (newValue) {
      this.flow.update(this.nodeId, {
        size: `${newValue}*${this.nodeHeight}`
      })
    },
    nodeHeight (newValue) {
      this.flow.update(this.nodeId, {
        size: `${this.nodeWidth}*${newValue}`
      })
    },
    multiColor (newValue) {
      this.multiId.forEach(id => {
        this.flow.update(id, {
          color: newValue
        })
      })
    },
    nodeColor (newValue, oldValue) {
      if (oldValue === null) return
      this.flow.update(this.nodeId, {
        color: newValue
      })
    },
    edgeName (newValue) {
      if (newValue === null) return
      this.flow.update(this.edgeId, {
        label: {
          text: newValue
        }
      })
    },
    groupName (newValue) {
      if (newValue === null) return
      this.flow.update(this.groupId, {
        label: newValue
      })
    },
    groupColor (newValue) {
      if (newValue === null) return
      this.flow.update(this.groupId, {
        color: newValue
      })
    },
    zoomRatio (newValue) {
      this.graph.zoom(newValue / 100)
    },
    /**
     * 当外部传入的`graph`所需要的数据发生变化时，重新绘制
     */
    data (newValue) {
      this.flow.read(this.data);
    },
    /**
     * 当外部传入的`itempanel`所需要的数据发生变化时，重新绘制
     */
    items (newValue) {
      this.initItems();
    },
    /**
     * 设置默认选中项目为第一项
     */
    itemGroup (value) {
      this.activeKey = Object.keys(value)[0] || '';
    }
  },
  created () {
    this.initItems();
    this.$nextTick(function () {
      this.attrEditable = false;
    })
    // 流图读取数据
    // this.data && this.flow.read(this.data);
  },
  mounted () {
    this.initEditor();
    window.vm = this;
    
  },
  // activated () {
  //   console.log('重新计划simulation editor');
  //   this.initItems();
  //   // 流图读取数据
  //   this.data && this.flow.read(this.data);
  // },
  methods: {
    /**
     * @description: 初始化编辑器
     */
    initEditor () {
      const editor = new G6Editor();
      this.editor = editor;
      // 关闭追踪反馈
      G6Editor.track(false);
      // 基础流程图
      this.flow = new G6Editor.Flow({
        graph: {
          container: this.$refs.flow,
          minZoom: 0.5,
          maxZoom: 2,
        },
        align: {
          grid: true // 网格对齐
        },
        // grid: {
        //   cell: 20 // 网孔尺寸
        // },
        shortcut: {
          zoomIn: true, // 开启放大快捷键
          zoomOut: true // 开启视口缩小快捷键
        },
        // 不显示没有终点的边
        noEndEdge: false
      });   
      // 流程图图类
      this.itempannel = new G6Editor.Itempannel({
        container: this.$refs.itempannel
      });
      // 命令工具
      this.toolbar = new G6Editor.Toolbar({
        container: this.$refs.toolbar
      });
      // 右键菜单
      this.contextmenu = new G6Editor.Contextmenu({
        container: this.$refs.contextmenu
      });
      
      // 通过editor添加关联
      editor.add(this.flow);
      editor.add(this.itempannel);
      editor.add(this.toolbar);
      editor.add(this.contextmenu);
      // 升级清晰度
      this.upClarity(1.5);
      // 流图读取数据
      this.data && this.flow.read(this.data);
      // 获取流图的graph示例
      this.graph = this.flow.getGraph();
      // 居中画布中的内容
      this.graph.setFitView('cc');
      
      // 获取当前页
      this.page = editor.getCurrentPage();
      // 默认关闭网格对齐
      this.page.hideGrid();
      // 设置已连线样式
      this.graph.edge({
        shape: 'custom-flow-polyline-round',
        style: {
          stroke: '#79838e'
        },
        labelRectStyle: {
          fill: '#ffffff'
        }
      });
      // 设置动态连接线样式（准备连时的样子）
      this.page.changeAddEdgeModel({
        shape: 'flow-polyline-round',
      });
      // 监听命令
      this.listenCommand();
      // 监听事件
      this.listenEvent();
      // 自适应画布
      editor.executeCommand('autoZoom');
    },
    /**
     * 初始化左边的`ItemPanel`
     */
    initItems () {
      const { dataMapping, items } = this;
      console.log('.........', items);
      items.forEach(item => {
        // 注册节点类型
        G6Editor.Flow.registerNode(item.name, {
        /**
         * 绘制函数
         * node - 拖拽进入`graph`的实例
         * this - 外部注册时构造的对象（注册节点），携带有自定义数据
         * 注意： this信息要复制给node
         */
          draw (node) {
            // 映射函数，将业务数据映射到图上
            dataMapping(node, item);
            // 获取组
            const group = node.getGraphicGroup();
            // 获取模型
            const model = node.getModel();
            // TODO:这里的大小数组后期要进行修订
            const width = 100;
            const height = 100;
            const x = - width / 2;
            const y = - height / 2;
            const keyShape = group.addShape('rect', {
              attrs: {
                x,y,width,height,
              // https://github.com/antvis/g6-editor/blob/master/demos/rc-components/ModelFlowEditor.jsx 这三个属性貌似没用
              // color: 'red',
              // fill: 'white',
              // stroke: '#CED4D9',
              },
            });
            group.addShape('image', {
              attrs: {
                x,y,width,height,
                img: item.src
              }
            });
            // 名称文本
            const label = model.label;
            group.addShape('text', {
              attrs: {
                text: label,
                x: 0,
                y: 64,
                textAlign: 'center',
                textBaseline: 'middle',
                fill: 'rgba(0, 0, 0, 0.85)',
              },
            });
            // 增加anchor的显示
            item.anchors.forEach(point => {
              const a = group.addShape('text', {
                attrs: {
                  type: 'anchor',
                  text: point[2].name,
                  x: point[0] ? width / 2 + 4 : width / -2 - 4,
                  y: point[1] > 0.5 ? (point[1] - 0.5) * height : (point[1] - 0.5) * height,
                  textAlign: point[0] ? 'left' : 'right',
                  textBaseline: 'middle',
                  fill: 'rgba(0, 0, 0, 0.85)',
                  opacity: 0
                }
              });
              console.log('已经添加anchor',a);
            });

            return keyShape;
          },
          anchor: item.anchors
        });
      });
      this.$set(this, 'itemGroup', groupBy(prop('group'), this.items));
    },
    /**
     * 监听命令
     */
    listenCommand () {
      let graphItems = [];
      this.editor.on('beforecommandexecute', ev => {
        graphItems = this.getItems();
      });
      this.editor.on('aftercommandexecute', ev => {
        const command = ev.command.name;
        if (command === 'multiSelect') {
          this.multiId = []; // 多选前清空上一个状态
          this.isMultiSelect = true;
        } else if (command === 'undo') {
          this.isMultiSelect = false;
        } 
      });
    },
    /**
     * 监听事件
     */
    listenEvent () {
      // 选中项后，`item`包含`node`、`edge`以及`group`;
      this.page.on('afteritemselected', ev => {
        // 判断数据类型
        switch (ev.item.type) {
        case 'node':
          if (!this.isMultiSelect) {
            this.nodeId = ev.item.model.id;
            this.nodeName = ev.item.model.label;
            [this.nodeWidth, this.nodeHeight] = ev.item.model.size.split('*')
            this.nodeColor = ev.item.model.color;
            // 将所有的anchor文本显示出来
            ev.item.group.get('children').forEach(c => {
              if(c._attrs.type === 'anchor') {
                c.attr({opacity: 1});
              }
            });
            console.log('选中节点', ev);
            this.$emit('node:selected', ev);
          } else {
            this.multiId.push(ev.item.model.id)
            this.multiColor = ev.item.model.color
          }
          break
        case 'edge':
          this.edgeId = ev.item.model.id;
          this.edgeName = ev.item.model.label
            ? ev.item.model.label.text
            : null;
          break
        case 'group':
          this.groupId = ev.item.model.id
          this.groupName = ev.item.model.label ? ev.item.model.label : null
          this.groupColor = ev.item.model.color
            ? ev.item.model.color
            : '#f2f4f5'
          break
        default:
          break
        }
      });
      // page事件监听 取消多选
      this.page.on('beforeitemunselected', (ev) => {
        this.isMultiSelect = false;
        switch (ev.item.type) {
        case 'node':
          ev.item.group.get('children').forEach(c => {
            if(c._attrs.type === 'anchor') {
              c.attr({opacity: 0});
            }
          })
        }
      });
      this.page.on('afteritemactived', ev => {
        switch (ev.item.type) {
        case 'node':
          ev.item.group.get('children').forEach(c => {
            if(c._attrs.type === 'anchor') {
              c.attr({opacity: 1});
            }
          });
        }
      });
      this.page.on('afteritemunactived', ev => {
        switch (ev.item.type) {
        case 'node':
          ev.item.group.get('children').forEach(c => {
            if(c._attrs.type === 'anchor') {
              c.attr({opacity: 0});
            }
          });
        }
      });
      // 节点双击后，向上层组件发出通知
      this.page.on('node:dblclick', e => {
        this.$emit('node:dbClick', e);
      });
      // 拖拽节点的时候，判断哪些点可以拖动
      this.page.on('dragedge:beforeshowanchor', e => {
        // 不允许自己拖动自己
        if (e.source === e.target) {
          e.cancel = true;
        }
        // 输入对输出
        if (e.sourceAnchor.type === e.targetAnchor.type) {
          e.cancel = true;
        }
        // 如果已经连接，不允许重复连接
        if (this.page.anchorHasBeenLinked(e.source, e.sourceAnchor) || this.page.anchorHasBeenLinked(e.target, e.targetAnchor)) {
          e.cancel = true;
        }
      });
      // 渲染完成时，向上层组件发出通知，可用于做业务数据和图形数据的绑定
      this.graph.on('afterrender', e => {
        this.$emit('render', this.getNodes());
      });
      // 当有修改痕迹时，才允许编辑
      this.graph.on('afterchange', e => {
        this.disableSave = false;
      });
      // 自动更新大小
      this.graph.on('afterchangesize', () => {
        this.graph.update()
      });
      // 监听画布大小变化
      this.graph.on('afterzoom', e => {
        this.zoomRatio = e.updateMatrix[0] * 100;
      });
      // 连线悬停时候高亮
      this.page.on('edge:mouseenter', e => {
        if (!e.item.isSelected) {
          highlightEdge(e.shape);
        }
      });
      // 连线取消悬停时还原
      this.page.on('edge:mouseleave', e => {
        if (!e.item.isSelected) {
          unlightEdge(e.shape)
        }
      });
    },
    /**
     * @description: 保存流图数据
     */
    save () {
      const graphData = this.flow.save();
      this.$emit('saved', graphData, {nodes: this.getNodes(), edges: this.getEdges()});
      this.disableSave = true;
    },
    getData () {
      return this.flow.save();
    },
    /**
     * 获取所有绘制元素（包含`node`和`edge`）
     */
    getItems () {
      return [...this.getNodes(), ...this.getEdges()];
    },
    /**
     * 获取所有`edge`实例
     */
    getEdges () {
      return this.graph.getEdges();
    },
    /**
     * 获取所有`node`实例
     */
    getNodes () {
      return this.graph.getNodes();
    },
    /**
     * 显示或隐藏网格
     */
    changeGridShowOrHide (e) {
      e.target.checked ? this.page.showGrid() : this.page.hideGrid();
    },
    /**
     * 改变缩放比例
     */
    changeZoomRatio (value) {
      // this.graph.zoom(value / 100);
      this.zoomRatio = value;
    },
    /**
     * @description: 下载流图
     */
    download () {
      this.page.hideGrid()
      this.graph.setFitView('cc')
      const canvas = this.$refs.flow.childNodes[0].childNodes[0]
      const imgData = canvas.toDataURL('image/png')
      // const pdf = new JsPDF({
      //   orientation: 'l', // 竖排
      //   unit: 'pt',
      //   format: 'a4'
      // })
      // // const width = 1190.55 // a3
      // const pdfWidth = 840.51 // a4
      // pdf.addImage(imgData, 'PNG', 0, 0,
      //   pdfWidth, pdfWidth / canvas.width * canvas.height, '', 'FAST')
      // pdf.save('download.pdf')
      const a = document.createElement('a');
      a.href = imgData;
      a.download = 'download.png';
      a.click();
      a.remove();
    },
    /**
     * @description: 格式化
     */
    formatTooltip (val) {
      return `缩放比${val}%`
    },
    /**
     * 升级清晰度
     */
    upClarity (value) {
      // 增强清晰度
      const canvas = this.$refs.flow.childNodes[0].childNodes[0];
      const clarity = Number(value) || 1.5; // 清晰度
      const dpr = window.devicePixelRatio && window.devicePixelRatio >= clarity
        ? window.devicePixelRatio : clarity;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      const ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);
    }
  }
}
</script>

<style lang="less" scoped>
/* icon-font */
@import 'assets/icon/g6_editor_font.css';

.editor {
  position: relative;
  width: 100%;
  height: 100% !important;
  border: 1px solid rgba(0, 0, 0, .15);//#dedbe2;
  // 顶部工具栏
  .top-container {
    position: absolute;
    padding: 4px 16px;
    width: 100%;
    border-bottom: 1px solid rgba(0, 0, 0, .15);//#e9e9e9;
    height: 41px;
    display: flex;
    // justify-content: space-between;
    align-items: center;
    background: #ffffff;
    box-shadow: 0px 8px 12px 0px rgba(0, 52, 107, 0.04);
    // 工具栏
    .toolbar {
      height: 100%;
      // 命令按钮
      .command {
        &:hover {
          border: 1px solid #d9d9d9;
        }
        color: #1890ff;
        border: 1px solid transparent;
        width: 32px;
        height: 32px;
        line-height: 32px;
        margin: 0px 4px;
        border-radius: 2px;
        padding-left: 6px;
        display: inline-block;
        // border: 1px solid rgba(2, 2, 2, 0);
      }
      .disable {
        color: rgba(0, 0, 0, 0.25);
      }
    }
    // 工具栏中靠右的部分
    .data-opt {
      // width: 20%;
      height: 100%;
      text-align: right;
      padding: 8px 0px;
      position: absolute;
      right: 16px;
    }
  }
  // 底部区域（左项目面板、中心画布、右属性面板）
  .bottom-container {
    padding-top: 41px;
    width: 100%;
    height: 100%;
    display: flex;
    background: #f7f9fb;
    justify-content: space-around;
    // 左边面板
    .left-pannel {
      width: 200px;
      min-width: 200px;
      height: 100%;
      padding: 0px;
      display: inline-flex;
      flex-direction: column;
      align-items: center;
      // 项目面板
      .itempannel-container {
        width: 200px;
        height: 192px;
        // 项目中的图
        img {
          width: 64px;
          height: 64px;
          padding: 4px;
          margin-left: 4px;
          margin-right: 4px;
          border-radius: 2px;
          border: 1px solid rgba(0, 0, 0, 0);
          vertical-align: middle;
          cursor: pointer;
        }
      }
    }
    // 中间画布
    .center-pannel {
      background: #ffffff;
      display: inline-block;
      width: calc(100% - 200px)!important;
      height: 100%;
      border-left: 1px solid rgba(0, 0, 0, .15);//#dedbe2;
      // 流程图
      .flow {
        width: 100%;
        height: 100%;
        // height: -webkit-fill-available;
        overflow: hidden;
      }
      // 右键菜单
      .contextmenu {
        margin: 0px;
        padding: 4px 0px;
        width: 120px;
        text-align: left;
        background: white;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        border-radius: 4px;
        background-clip: padding-box;
        color: #000;
        font-size: 12px;
        font-variant: tabular-nums;
        line-height: 1.5;
        display: none;
        // 命令
        .command {
          height: 22px;
          padding: 4px 12px;
          margin: 0;
          clear: both;
          font-size: 14px;
          font-weight: normal;
          color: rgba(0, 0, 0, 0.65);
          white-space: nowrap;
          cursor: pointer;
          transition: all 0.3s;
          line-height: 22px;
          box-sizing: content-box;
        }
        span {
          margin-left: 8px;
        }
        // 命令悬停
        .command:hover {
          cursor: pointer;
          background: #e6f7ff;
        }
        // 命令禁用
        .disable {
          color: rgba(0, 0, 0, 0.25);
        }
      }
    }

    // 右边属性框
    .right-pannel {
      width: 0px;
      height: 100%;
      .attr-editable-button {
        position: absolute; 
        width: 14px;
        height: calc(100% - 42px);
        right: 1px; 
        bottom: 1px; 
        background-color: #fafafa;
        &:hover {
          background-color: #f5f5f5;
          cursor: pointer;
        }
        svg {
          position: absolute;
          top: calc(50% - 7px);
          right: calc(50% - 7px);
        }
      }
      /deep/ .ant-drawer-content-wrapper {
        height: calc(100% - 184px);
        right: 25px;
        bottom: 25px;
        &[style*="transform"] {
          display: contents;
        }
      }
      /deep/ .ant-drawer-wrapper-body {
          overflow: hidden!important;
          .ant-drawer-body {
            height: calc(100% - 54px);
            overflow-y: scroll!important;
          }
        }
    }
  }
}

.ant-collapse {
  /deep/ .ant-collapse-header {
    // height: 32px;
    border-top: 1px solid #dce3e8;
    border-bottom: 1px solid #dce3e8;
    background: #ebeef2;
    color: #000;
    // line-height: 32px;
    // padding-left: 12px;
  }
}

</style>