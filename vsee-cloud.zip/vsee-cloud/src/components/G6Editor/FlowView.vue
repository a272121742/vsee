<template>
  <keep-alive>
    <div class="flow-view">
      <div class="top-container">
        <div
          class="toolbar"
          ref="toolbar"
        >
          <a-tooltip placement="bottom">
            <template #title>
              <span>放大</span>
            </template>
            <i
              data-command="zoomIn"
              class="command iconfont icon-zoom-in-o"
            ></i>
          </a-tooltip>
          <a-tooltip placement="bottom">
            <template #title>
              <span>缩小</span>
            </template>
            <i
              data-command="zoomOut"
              class="command iconfont icon-zoom-out-o"
            ></i>
          </a-tooltip>
          <a-tooltip placement="bottom">
            <template #title>
              <span>适应画布</span>
            </template>
            <i
              data-command="autoZoom"
              class="command iconfont icon-fit"
            ></i>
          </a-tooltip>
          <a-tooltip placement="bottom">
            <template #title>
              <span>实际尺寸</span>
            </template>
            <i
              data-command="resetZoom"
              class="command iconfont icon-actual-size-o"
            ></i>
          </a-tooltip>
        </div>
      </div>
      <div class="bottom-container">
        <div class="center-pannel">
          <div
            class="flow"
            ref="flow"
          ></div>
        </div>
      </div>
    </div>
  </keep-alive>
</template>

<script>
import G6Editor from '@antv/g6-editor';

export default {
  name: 'FlowView',
  props: {
    /**
     * 画板数据
     */
    data: {
      type: Object,
      default: () => ({})
    },
    dataMapping: {
      type: Function,
      default: () => {}
    }
  },
  data () {
    return {
      /**
       * 流程图实例
       */
      flow: null,
      /**
       * 图形模块的实例，内置数据绑定的模型`Mode`;
       */
      graph: null,
    }
  },
  watch: {
    /**
     * 当外部传入的`graph`所需要的数据发生变化时，重新绘制
     */
    data (newValue) {
      this.flow.read(this.data);
    },
  },
  created () {
    console.log('flowview 已经创建');
    window.vm2 = this;
  },
  mounted () {
    this.initEditor();
  },
  activated () {
    this.data && this.flow.read(this.data);
  },
  methods: {
    /**
     * @description: 初始化编辑器
     */
    initEditor () {
      // 基础流程图
      this.flow = new G6Editor.Flow({
        graph: {
          container: this.$refs.flow,
          fitView: 'cc',
          // 通过`this.graph.get('modes').default`查看可用的行为模式
          modes: {
            move: [
              // 画板展示
              'panCanvas', 
              'panItem',
              // 可缩放
              'keydownCmdWheelZoom', 
              'wheelChangeViewport', 
              'clickNodeSelected', 
              // 'clickCanvasSelected',
            ]
          },
          minZoom: 0.2,
          maxZoom: 2.5,
        },
        
        shortcut: {
          zoomIn: true, // 开启放大快捷键
          zoomOut: true // 开启视口缩小快捷键
        },
        // 不显示没有终点的边
        noEndEdge: true
      });
      G6Editor.track(false);
      // 命令工具
      this.toolbar = new G6Editor.Toolbar({
        container: this.$refs.toolbar
      });
      const editor = new G6Editor();
      // 通过editor添加关联
      editor.add(this.flow);
      editor.add(this.toolbar);
      // 设置为移动模式，即不可编辑
      this.flow.changeMode('move');
      // 升级清晰度
      // this.upClarity(1.5);
      // 流图读取数据
      this.data && this.flow.read(this.data);
      // 获取流图的graph示例
      this.graph = this.flow.getGraph();
      // 居中画布中的内容
      this.graph.zoom(0.5);
      // 设置已连线样式
      this.graph.edge({
        shape: 'custom-flow-polyline-round',
        style: {
          stroke: '#79838e'
        },
        labelRectStyle: {
          fill: '#ffffff'
        }
      });
      // 设置动态连接线样式（准备连时的样子）
      this.flow.changeAddEdgeModel({
        shape: 'flow-polyline-round',
      });
      // 监听事件
      this.listenEvent();
      editor.executeCommand('autoZoom');
    },
   
    /**
     * 监听事件
     */
    listenEvent () {
      // 单击节点后，向上层组件发出通知
      this.graph.on('node:click', e => {
        this.$emit('node:click', e);
      });
      
      // 渲染完成时，向上层组件发出通知，可用于做业务数据和图形数据的绑定
      this.graph.on('afterrender', e => {
        this.$emit('render', this.getNodes());
      });
      
      // 自动更新大小
      this.graph.on('afterchangesize', () => {
        this.graph.update()
      });
    },
    /**
     * 获取所有绘制元素（包含`node`和`edge`）
     */
    getItems () {
      return [...this.getNodes(), ...this.getEdges()];
    },
    /**
     * 获取所有`edge`实例
     */
    getEdges () {
      return this.graph.getEdges();
    },
    /**
     * 获取所有`node`实例
     */
    getNodes () {
      return this.graph.getNodes();
    },
    /**
     * 升级清晰度
     */
    upClarity (value) {
      // 增强清晰度
      const canvas = this.$refs.flow.childNodes[0].childNodes[0];
      const clarity = Number(value) || 1.5; // 清晰度
      const dpr = window.devicePixelRatio && window.devicePixelRatio >= clarity
        ? window.devicePixelRatio : clarity;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      const ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);
    }
  }
}
</script>

<style lang="less" scoped>
/* icon-font */
@import 'assets/icon/g6_editor_font.css';

.flow-view {
  position: relative;
  width: 100%!important;
  height: 100%!important;
  .top-container {
    position: absolute;
    top: 0px;
    left: 0px;
    z-index: 100;
    .toolbar {
      height: 100%;
      // 命令按钮
      .command {
        &:hover {
          border: 1px solid #d9d9d9;
        }
        color: #1890ff;
        border: 1px solid transparent;
        width: 32px;
        height: 32px;
        line-height: 32px;
        margin: 0px 4px;
        border-radius: 2px;
        padding-left: 6px;
        display: inline-block;
        // border: 1px solid rgba(2, 2, 2, 0);
      }
      .disable {
        color: rgba(0, 0, 0, 0.25);
      }
    }
  }
  // 底部区域（左项目面板、中心画布、右属性面板）
  .bottom-container {
    width: 100%;
    height: 100%;
    display: flex;
    background: #f7f9fb;
    justify-content: space-around;
    // 中间画布
    .center-pannel {
      background: #ffffff;
      display: inline-block;
      width: 100%;
      height: 100%;
      // border: 1px solid rgba(0, 0, 0, .15);
      // 流程图
      .flow {
        width: 100%;
        height: 100%;
        overflow: hidden;
      }
    }
  }
}
</style>