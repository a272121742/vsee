<template>
  <div
    :style="{position: 'relative', width: size + 'px', height: size + 'px'}"
  >
    <dot-line
      v-for="(dir, index) in dirs"
      ref="dotLine"
      :key="index"
      :title="dir"
      :style="'position: absolute; ' + dir + ': -4px;'"
      :editable="editable"
      :source-map="$data[dir]"
      :fixed="computeDirValue(dir)"
      :size="size"
      :vertical="computeDirVertical(dir)"
      @add="addPoint"
      @select="selectPoint"
    />
    <!-- <dot-line
      ref="dotLine"
      style="position: absolute; top: -4px;"
      :source-map="this.top"
      :fixed="0"
      :size="size"
      @add="addPoint"
      @select="selectPoint"
    ></dot-line>
    <dot-line
      ref="dotLine"
      style="position: absolute; left: -4px;"
      :source-map="this.left"
      :fixed="0"
      :size="size"
      :editable="editable"
      vertical
      @add="addPoint"
      @select="selectPoint"
    ></dot-line>
    <dot-line
      ref="dotLine"
      style="position: absolute; right: -4px;"
      :source-map="this.right"
      :fixed="1"
      :size="size"
      :editable="editable"
      vertical
      @add="addPoint"
      @select="selectPoint"
    ></dot-line>
    <dot-line
      ref="dotLine"
      style="position: absolute; bottom: -4px;"
      :source-map="this.bottom"
      :fixed="1"
      :size="size"
      :editable="editable"
      @add="addPoint"
      @select="selectPoint"
    ></dot-line> -->
    <img
      v-if="src"
      :style="{width: size + 'px', height: size + 'px', padding: '2px'}"
      src="/static/images/example.png"
    />
  </div>
</template>

<script>
import { groupWith } from 'ramda';

export default {
  components: {
    DotLine: () => import('./DotLine.vue')
  },
  props: {
    /**
     * 是否可编辑，默认false
     */
    editable: {
      type: Boolean,
      default: true
    },
    /**
     * 新的数据点集
     */
    sourceMap: {
      type: Object,
      default: () => ({})
    },
    /**
     * 图片地址
     */
    src: {
      type: String,
      default: null
    },
    /**
     * 大小（正方形）
     */
    size: {
      type: Number,
      default: 200,
    }
  },
  data () {
    return {
      dirs: ['top', 'left', 'right', 'bottom'],
      top: {},
      left: {},
      right: {},
      bottom: {}
    };
  },
  watch: {
    sourceMap () {
      this.refresh();
    }
  },
  created () {
    window.vm = this;
  },
  methods: {
    /**
     * 数据刷新，数据由上层组件字符串向下传递获得并对列表按照字段`order`进行排序
     */
    refresh () {
      const dirs = {
        top: {},
        left: {},
        right: {},
        bottom: {}
      };
      const keys = Object.keys(this.sourceMap);
      keys.forEach(key => {
        const point = this.sourceMap[key];
        if (point[0] === 0) {
          dirs.left[key] = point;
        }
        if (point[0] === 1) {
          dirs.right[key] = point;
        }
        if (point[1] === 0) {
          dirs.top[key] = point;
        }
        if (point[1] === 1) {
          dirs.bottom[key] = point;
        }
      });
      this.$set(this, 'top', dirs.top);
      this.$set(this, 'left', dirs.left);
      this.$set(this, 'right', dirs.right);
      this.$set(this, 'bottom', dirs.bottom);
    },
    /**
     * 计算方位值
     */
    computeDirValue (dir) {
      return  (dir === 'top' || dir === 'left') ? 0 : 1;
    },
    /**
     * 计算方位
     */
    computeDirVertical (dir) {
      return dir === 'left' || dir === 'right'; 
    },
    addPoint (point) {
      console.log(this.$refs);
      this.$refs.dotLine.forEach(dl => dl.clearEmptyNamePoint());
      this.$emit('add', point);
    },
    selectPoint (point) {
      this.$emit('select', point);
    }
  }
}
</script>

