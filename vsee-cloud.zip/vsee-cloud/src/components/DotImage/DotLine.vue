<template>
  <div class="dot-line-container">
    <div
      v-if="editable"
      :class="{'ant-slider': true, 'ant-slider-vertical': vertical, 'ant-slider-disabled': false}"
      :style="vertical ? {'height': size + 'px'} : {'width': size + 'px'}"
      ref="slider"
      @mousemove.prevent.self.stop="onSliderMousemove"
      @mouseenter.prevent.self.stop=" e => inSlider = true"
      @mouseleave.prevent.self.stop=" e => inSlider = false"
    >
      <!-- 横线 -->
      <div
        ref="rail"
        class="ant-slider-rail"
        @mousemove.prevent.self.stop="onSliderMousemove"
        @mouseenter.prevent.self.stop=" e => inRail = true"
        @mouseleave.prevent.self.stop=" e => inRail = false"
      ></div>

      <!-- 点位(虚点) -->
      <div
        v-show="inSlider && !isPointEnter"
        ref="vp"
        class="ant-slider-handle ant-slider-handle-virtual"
        :style="vertical ? {top: offset + 'px'} : {left: offset + 'px'}"
        @click.prevent.self.stop="addPoint"
      ></div>
      <!-- 点位(实点) -->
      <div
        v-for="(point, index) in points"
        :key="index"
        class="ant-slider-handle"
        :style="vertical ? {top: computeOffset(point) + 'px'} : {left: computeOffset(point) + 'px'}"
        @mousedown.prevent.self.stop="e => onPointMousedown(e, index)"
        @mouseenter.prevent.self.stop="e => isPointEnter = true"
        @mouseleave.prevent.self.stop="e => isPointEnter = false"
        @click.prevent.self.stop="e => selectPoint(e, point)"
      >
      </div>
    </div>
    <div
      v-else
      :class="{'ant-slider': true, 'ant-slider-vertical': vertical, 'ant-slider-disabled': true}"
      :style="vertical ? {'height': size + 'px'} : {'width': size + 'px'}"
      ref="slider"
    >
      <!-- 横线 -->
      <div
        ref="rail"
        class="ant-slider-rail"
      ></div>
      <!-- 点位(实点) -->
      <div
        v-for="(point, index) in points"
        :key="index"
        class="ant-slider-handle"
        :style="vertical ? {top: computeOffset(point) + 'px'} : {left: computeOffset(point) + 'px'}"
        @click.prevent.self.stop="e => selectPoint(e, point)"
      >
      </div>
    </div>
  </div>
</template>

<script>
import { map } from 'ramda';
export default {
  name: 'DotLine',
  props: {
    /**
     * 是否可编辑，默认false
     */
    editable: {
      type: Boolean,
      default: true
    },
    /**
     * sourceMap
     * {
     *   pointName1: [x1, y1],
     *   pointName2: [x2, y2],
     * }
     */
    sourceMap: {
      type: Object,
      default: () => ({})
    },
    /**
     * 方向
     */
    vertical: {
      type: Boolean,
      default: false
    },
    /**
     * 固定值
     * 如果是横轴，则生成二维值 [point, fixed];
     * 如果是纵轴，则生成二维值 [fixed, point];
     */
    fixed: {
      type: Number,
      default: 0
    },
    /**
     * 大小
     */
    size: {
      type: Number,
      default: 100
    }
  },
  data () {
    return {
      /**
       * 时否抓起
       */
      isDraged: false,
      /**
       * 是否进入点
       */
      isPointEnter: false,
      /**
       * 是否进入边
       */
      inSlider: false,
      /**
       * 点集
       * point 格式如下： [value, index] 或 [index, value];
       * point的value值取决于打点时获取的相对left数据
       */
      points: [],
      /**
       * 当前正在拖拽的元素
       */
      dragEl: null,
      /**
       * 虚拟点的偏移量（单位px）
       */
      offset: 0,

    }
  },
  computed: {
    /**
     * 线条元素
     */
    slider () {
      return this.$refs.line;
    },
    /**
     * 虚位点元素
     */
    vp () {
      return this.$refs.vp;
    },
    /**
     * 线条扶手
     */
    rail () {
      return this.$refs.rail;
    }
  },
  watch: {
    editable (value) {
      if (!value) {
        this.clearEmptyNamePoint();
      }
    },
    /**
     * 监听外部数据，如果外部数据发生变化，更新渲染数据
     */
    sourceMap () {
      const keys = Object.keys(this.sourceMap) || [];
      const points = [];
      keys.forEach(key => {
        const point = this.sourceMap[key];
        points.push([...point, key]);
      });
      this.$set(this, 'points', points);
    },
  },
  created () {
  },
  mounted () {
    const keys = Object.keys(this.sourceMap) || [];
    const points = [];
    keys.forEach(key => {
      const point = this.sourceMap[key];
      points.push([...point, key]);
    });
    this.$set(this, 'points', points);
    document.addEventListener('mousemove', e => {
      if (this.isDraged && this.dragEl) {
        // 获取移动空间的长度
        const length = this.vertical ?  this.rail.offsetHeight : this.rail.offsetWidth;
        // 获取鼠标的偏移量（垂直时获取Y）
        const mouseOffset = this.vertical ? e.clientY : e.clientX;
        // 父容器元素的盒模型
        const parentRect = this.dragEl.parentNode.getBoundingClientRect();
        // const parentNode = this.dragEl.parentNode; //this.dragEl.parentNode.offsetParent ? this.dragEl.parentNode.offsetParent : this.dragEl.parentNode;
        const parentOffset = this.vertical ? parentRect.top : parentRect.left;

        let offsetLength = mouseOffset - parentOffset;
        offsetLength = offsetLength < 0 ? 0 
          : offsetLength > length ? length 
            : offsetLength;
        console.log(length, mouseOffset, parentOffset, this.dragEl.parentNode);
        const point = this.vertical ? [this.fixed, offsetLength / length] : [offsetLength / length, this.fixed]
        this.$set(this.points, this.dragEl.index, point);
      }
    });
    document.addEventListener('mouseup', e => {
      this.isDraged = false;
    });
  },
  
  methods: {
    /**
     * 实体点位-鼠标点击事件
     */
    onPointMousedown (e, index) {
      this.isDraged = true;
      this.dragEl = e.target;
      this.dragEl.index = index;
      e.target.style.cursor = 'move';
    },
    /**
     * 滑块容器-鼠标移动事件
     */
    onSliderMousemove (e) {
      const offset = this.vertical ? (e.offsetY > 0 ? e.offsetY : 0) : (e.offsetX > 0 ? e.offsetX : 0);
      this.offset = offset;
    },
    /**
     * 增加点位
     */
    addPoint (e) {
      
      this.clearEmptyNamePoint();
      const offset = this.vertical ? (e.target.offsetTop < 0 ? 0 : e.target.offsetTop ) : (e.target.offsetLeft < 0 ? 0 : e.target.offsetLeft);
      const location = (offset + 4) / (this.vertical ?  this.rail.offsetHeight : this.rail.offsetWidth);
      const point = this.points.push(this.vertical ? [this.fixed, location] : [location, this.fixed]);
      console.log(this.vertical ? [this.fixed, location] : [location, this.fixed]);
      this.$emit('add', point);
    },
    /**
     * 根据点位计算偏移量
     */
    computeOffset (point) {
      // 获取点位中的动态项索引
      const index = this.vertical ? 1 : 0;
      // 获取移动空间的长度
      const length = this.vertical ?  this.rail.offsetHeight : this.rail.offsetWidth;
      return point[index] * length;
    },
    /**
     * 选择点位
     */
    selectPoint (e, point) {
      this.$emit('select', point);
    },
    /**
     * 清理没有命名的点位
     */
    clearEmptyNamePoint () {
      const points = this.points.filter(p => p[2] && p[2].length);
      this.$set(this, 'points', points);
    }
  }
}
</script>

<style lang="less" scoped>
  .dot-line-container {
    display: inline-block;
    .ant-slider-handle-virtual {
      border-color: rgba(0, 0, 0, 0.25) !important;
      background-color: #fff;
      box-shadow: none;
    }
    
    // /deep/ .ant-slider-rail {
    //   background-color: transparent;
    // }
    /deep/ .ant-slider {
      padding: 4px auto;
      margin: 0px;
      .ant-slider-handle {
        // rail高度为4px
        height: 8px;
        width: 8px;
        margin: auto -4px; // rail.width  / -2
        margin-top: -2px; // (rail.height - height) / 2
        &:hover {
          height: 14px;
          width: 14px;
          margin: auto -7px;
          margin-top: -5px;
        }
      }
    }
    /deep/ .ant-slider-vertical {
      padding: auto 4px!important;
      .ant-slider-handle {
        margin: -4px auto!important; // rail.width  / -2
        margin-left: -2px!important; // (rail.height - height) / 2
        &:hover {
          margin: -7px auto!important; // rail.width  / -2
          margin-left: -5px!important; // (rail.height - height) / 2
        }
      }
    }
    /deep/ .ant-slider-disabled {
      
    }
  }
  
</style>

