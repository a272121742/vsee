<template>
  <div
    style="margin: -24px -24px 0;"
    :class="wrapperClassName"
  >
    <slot name="top" />
    <PageHeader
      key="pageheader"
      :router-location="$route"
      :title="title"
      :tab-active-key="tabActiveKey"
      :tab-list="tabList"
      :on-tab-change="onTabChange"
      :get-menu-data="getMenuData"
      :router="router"
    >
      <template #logo>
        <slot name="logo" />
      </template>
      <template #extraContent>
        <slot name="extraContent" />
      </template>
      <template #content>
        <slot name="content" />
      </template>
      <template #action>
        <slot name="action" />
      </template>
    </PageHeader>
    <div class="content">
      <slot />
    </div>
  </div>
</template>

<script>
import PageHeader from '@/components/PageHeader';
import router from '@/router';
import { getMenuData } from '@/layouts/menu';
export default {
  name: 'PageHeaderLayout',
  components: {
    PageHeader
  },
  props: {
    wrapperClassName: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    tabActiveKey: {
      type: String,
      default: ''
    },
    tabList: {
      type: Array
    },
    onTabChange: {
      type: Function
    }
  },
  data () {
    return {
      router,
      getMenuData
    };
  }
};
</script>

<style lang="less" scoped>
@import "./PageHeaderLayout.less";
</style>
