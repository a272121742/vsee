import loginSerivce from '../api';

export default {
  toLogin: ({
    commit
  }, loginInfo) => {
    const email = loginInfo.name.trim();
    const password = loginInfo.password;
    return loginSerivce
      .login(email, password)
      .then((data) => {
        if (data.token) {
          commit('onSuccess', {...data.result, token: data.token});
          return Promise.resolve(data.result);
        }
        return Promise.reject(new Error('登陆失败：查找无此用户！'));
      })
      .catch(err => Promise.reject(err));
  },
  toLoginByToken: ({
    commit
  }, token) => loginSerivce
    .loginByToken(token)
    .then((data) => {
      if (data.token) {
        console.log('登陆成功', {...data.result, token: data.token});
        commit('onSuccess', {...data.result, token: data.token});
        return Promise.resolve(data.result);
      } else {
        return Promise.reject(new Error('登陆失败：查找无此用户！'));
      }
    })
    .catch(err => Promise.reject(err))
};