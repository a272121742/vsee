<template>
  <a-form
    id="components-form-demo-normal-login"
    :form="form"
    class="login-form"
    autocomplete="false"
    @submit="handleSubmit"
  >
    <a-form-item>
      <a-input
        v-decorator="[
          'name' ]"
        placeholder="Username"
      >
        <a-icon
          slot="prefix"
          type="user"
          style="color: rgba(0,0,0,.25)"
        />
      </a-input>
    </a-form-item>
    <a-form-item>
      <a-input
        autocomplete="false"
        v-decorator="[
          'password'
        ]"
        type="password"
        placeholder="Password"
      >
        <a-icon
          slot="prefix"
          type="lock"
          style="color: rgba(0,0,0,.25)"
        />
      </a-input>
    </a-form-item>
    <a-form-item>
      <a-button
        type="primary"
        html-type="submit"
        class="login-form-button"
      >
        Log in
      </a-button>
    </a-form-item>
  </a-form>
</template>


<script>

import { mapGetters, mapActions } from 'vuex';

const parse = vm => JSON.parse(JSON.stringify(vm));

export default {
  data () {
    const state = this.$store.state.login;
    return {
      loginForm: parse(state.loginForm),
    };
  },
  computed: {

    ...mapGetters('login', [

    ])
  },
  watch: {
    name: value => {
      this.form.setFieldsValue({ name: value });
    }
  },
  created () {
    this.form = this.$form.createForm(this, {
      onFieldsChange: (_, changedFields) => {
        this.$emit('change', changedFields);
      },
      mapPropsToFields: () => {
        return {
          name: this.$form.createFormField({
            value: this.loginForm.name,
          }),
          password: this.$form.createFormField({
            value: this.loginForm.password
          })
        };
      },
      onValuesChange: (_, values) => {
        console.log(values);
      },
    });
  },
  methods: {
    ...mapActions('login', [
      'toLogin'
    ]),
    handleSubmit (e) {
      e.preventDefault();
      // 拦截重定向URL
      const redirect = decodeURIComponent(this.$route.query.redirect || '/');
      this.form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          this.toLogin(this.loginForm).then((userInfo) => {
            this.$router.push({ path: redirect });
          })
        } else {
          return;
        }
      });
      return false;
    },
    // ...mapMutations('login', [
    //   // 'onSuccess',
    //   // 'saveUserInfo'
    // ]),
    // 登陆事件
    // handlerLogin (name) {
    //   // 拦截重定向URL
    //   const redirect = decodeURIComponent(this.$route.query.redirect || '/');
    //   // 验证登陆表单
    //   this.$refs[name].validate().then((valid) => {
    //     if (valid) {
    //       this.toLogin(this.loginForm).then((userInfo) => {
    //         this.$router.push({ path: redirect });
    //       }).catch((fail) => {
    //         this.$Message.error(fail.message);
    //         throw new Error(fail);
    //       });
    //     }
    //   });
    // }
  },
  
  
};
</script>

<style lang="less" scoped>
.user-layout-login {
  label {
    font-size: 14px;
  }
  .getCaptcha {
    display: block;
    width: 100%;
    height: 40px;
  }
  .forge-password {
    font-size: 14px;
  }
  button.login-button {
    padding: 0 15px;
    font-size: 16px;
    height: 40px;
    width: 100%;
  }
  .user-login-other {
    text-align: left;
    margin-top: 24px;
    line-height: 22px;
    .item-icon {
      font-size: 24px;
      color: rgba(0, 0, 0, 0.2);
      margin-left: 16px;
      vertical-align: middle;
      cursor: pointer;
      transition: color 0.3s;
      &:hover {
        color: #1890ff;
      }
    }
    .register {
      float: right;
    }
  }
}
</style>