import $ from '@/lib/ajax';
import Mock from '@/lib/mock';
import axios from 'axios';

// Mock.post('/api/login', data => {
//     console.log(data);
//     return {
//         data: {
//             token: true
//         }
//     }
// });
// axios.post('/api/login', {
//     data: {
//         email: 'qianlong@haocang.com',
//         password: '12345678'
//     }
// });

export default {
  login: (email, password) => {
    return $.post('/api/login', {
      email,
      password
    })

  },
  loginByToken: token => $.post('/api/loginbytoken', token)
};