<template>
  <a-layout id="components-layout-top-side">
    <a-layout-header class="header">
      <div class="logo" />
      <!-- <a-menu
        theme="dark"
        mode="horizontal"
        :default-selected-keys="['2']"
        :style="{ lineHeight: '64px' }"
      >
        <a-menu-item key="1">
          nav 1
        </a-menu-item>
        <a-menu-item key="2">
          nav 2
        </a-menu-item>
        <a-menu-item key="3">
          nav 3
        </a-menu-item>
      </a-menu> -->
    </a-layout-header>
    <a-layout>
      <a-layout-sider
        width="180"
        style="background: #fff"
        collapsible
        v-model="collapsed"
      >
        <a-menu
          mode="inline"
          theme="dark"
          :default-selected-keys="['1']"
          :style="{ height: '100%', borderRight: 0 }"
          @select="onSelect"
        >
          <template v-for="m in menus">
            <a-menu-item
              v-if="m.children.length == 1"
              :name="m.children[0].name"
              :key="m.children[0].name"
            >
              <a-icon
                :key="'menuicon' + m.children[0].name"
                type="desktop"
              ></a-icon>
              <span
                :key="'title' + m.children[0].name"
                class="layout-text"
              >{{ $t(m.children[0].name) }}</span>
            </a-menu-item>
            <a-sub-menu
              v-if="m.children.length > 1"
              :name="m.name"
              :key="m.name"
            >
              <template slot="title">
                <a-icon type="desktop"></a-icon>
                <span class="layout-text">{{ $t(m.name) }}</span>
              </template>
              <template v-for="c in m.children">
                <a-menu-item
                  :name="c.name"
                  :key="c.name"
                >
                  <a-icon
                    :key="'icon' + c.name"
                    type="desktop"
                  ></a-icon>
                  <span
                    :key="'title' + c.name"
                    class="layout-text"
                  >{{ $t(c.name) }}</span>
                </a-menu-item>
              </template>
            </a-sub-menu>
          </template>
        </a-menu>
      </a-layout-sider>
      <a-layout style="padding: 0 24px 24px">
        <Breadcrumb></Breadcrumb>
        <a-layout-content :style="{ padding: '0px', margin: 0, minHeight: '280px', height: '100%' }">
          <router-view />
        </a-layout-content>
        <!-- <a-layout-footer style="text-align: center">
          Ant Design ©2018 Created by Ant UED
        </a-layout-footer> -->
      </a-layout>
    </a-layout>
  </a-layout>
</template>

<script>
export default {
  components: {
    Breadcrumb: () => import('./Breadcrumb.vue')
  },
  data () {
    return {
      collapsed: false
    }
  },

  computed: {
    /**
     * 左侧菜单 :@TODO: 应该可变动
     */
    menus () {
      console.log('菜单列表', this.$store.state.menus);
      return this.$store.state.menus || [];
      // return [{name: 'a', children:[{name: 'a-1'}, { name: 'a-2' }]},{name: 'b', children: [{name: 'b-1'}]}];
    },
    // breadcrumbs () {
    //   return (this.$route && this.$route.matched) || [];
    // },
  },

  methods: {
    onSelect ({ key }) {
      this.$router.push({ name: key });
    }
  }

};
</script>

<style lang="less">
#components-layout-top-side {
  height: 100%;
  .logo {
    width: 120px;
    height: 31px;
    background: rgba(255, 255, 255, 0.2);
    margin: 16px 28px 16px 0;
    float: left;
  }
}
</style>