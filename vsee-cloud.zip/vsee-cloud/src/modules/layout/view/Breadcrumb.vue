<template>
  <a-breadcrumb class="breadcrumb">
    <template v-for="(item, index) in breadcrumbs">
      <a-breadcrumb-item
        v-if="!item.meta.children || !item.path"
        :key="index"
        :to="item"
      >
        {{ $t(item.meta.title || item.name) }}
      </a-breadcrumb-item>
    </template>
  </a-breadcrumb>
</template>


<script>
export default {
  name: 'Breadcrumb',
  computed: {
    // 面包屑菜单从路由中获取
    breadcrumbs () {
      return (this.$route && this.$route.matched) || [];
    },
  }
}
</script>

<style lang="less" scoped>
.breadcrumb {
  margin: 16px 0px;
}
</style>

