<template>
  <keep-alive>
    <a-modal
      title="变量表"
      v-model="showModal"
      :width="720"
      @ok="handleSaved"
      @cancel="() => showmodal = false"
    >
      <a-table
        :row-key="(r, i) => i"
        :columns="columns"
        :data-source="data"
        :pagination="false"
        :scroll="{y: 250}"
        
        size="small"
        bordered
      >
        <span
          slot="serial"
          slot-scope="text, record, index"
        >
          {{ index + 1 }}
        </span>
        <!-- 可编辑值 -->
        <a-input-number
          slot="defvalue"
          slot-scope="text, record"
          :value="text"
          :default-value="text"
          @change="(value) => record.defvalue = value"
        />
        <a-checkbox
          slot="saved"
          slot-scope="text, record"
          :checked="text === 1"
          @change="(e) => record.saved = e.target.checked + 0"
        >
        </a-checkbox>
      </a-table>
    </a-modal>
  </keep-alive>
</template>

<script>
import { pipe, partialRight } from 'ramda';
import { string2json, map2list, list2map } from '@lib/util';

export default {
  // 模型变量表格
  name: 'InoutVarsConfiguration',
  props: {
    // 源数据字符串
    dataString: {
      type: String,
      default: ''
    },
  },
  data () {
    return {
      showModal: false,
      columns: [{
        title: '#',
        scopedSlots: { customRender: 'serial' },
        width: 80,
      }, {
        title: '变量名称',
        dataIndex: 'name',
        key: 'name',
        width: 120,
      }, {
        title: '初始值',
        dataIndex: 'defvalue',
        key: 'defvalue',
        scopedSlots: { customRender: 'defvalue' },
        width: 180,
      }, {
        title: '描述',
        dataIndex: 'desc',
        key: 'desc',
        width: 180,
      }, {
        title: '是否保存',
        dataIndex: 'saved',
        key: 'saved',
        scopedSlots: { customRender: 'saved' },
        width: 120,
      }],
      customRow: (record, index) => ({
        on: {
          click: () => {
            console.log('双击');
            record.editable = true;
          }
        }
      }),
      data: [],
    }
  },
  watch: {
    // 当外部`dataString`更新时，重新更新内部数据；
    dataString () {
      this.init();
    }
  },
  created () {
    this.init();
  },
  methods: {
    init () {
      this.$set(this, 'data', this.convertInoutVars(this.dataString));
    },
    // 加载数据
    show (dataString) {
      this.$set(this, 'data', this.convertInoutVars(dataString));
      this.showModal = true;
    },
    // 转码 String -> Array<Object>
    convertInoutVars: pipe(string2json, map2list('name')),
    // // 转码 Array<Object> -> String
    reconvertInoutVars: pipe(list2map('name'), partialRight(JSON.stringify, [null, 2])),
    handleSaved () {
      this.$emit('change', this.reconvertInoutVars(this.data));
      this.showModal = false;
    },
  }
}
</script>
