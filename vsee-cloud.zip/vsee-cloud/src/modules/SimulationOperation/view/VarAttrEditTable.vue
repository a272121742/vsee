<template>
  <a-table
    :columns="outColumns"
    :data-source="dataGroupList"
    :show-header="false"
    :pagination="false"
    :default-expand-all-rows="true"
    :expand-row-by-click="true"
    :scroll="{y: 320}"
    size="small"
    row-key="category"
  >
    <a-table
      slot="expandedRowRender"
      slot-scope="{ list }"
      bordered
      :columns="innerColumns"
      :data-source="list"
      :pagination="false"
      size="small"
      row-key="name"
    >
      <!-- 数字标记 -->
      <template
        slot="serial"
        slot-scope="text, record, index"
      >
        {{ index + 1 }}
      </template>
      <!-- 可编辑值 -->
      <template
        slot="value"
        slot-scope="text, record"
      >
        <a-input-number
          size="small"
          :default-value="record.value"
          @change="value => updateDataSource(value, record)"
        />
      </template>
    </a-table>
  </a-table>
</template>

<script>
import {groupBy, prop, concat} from 'ramda';

export default {
  props: {
    /**
     * 数据源
     */
    dataSource: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      outColumns,
      innerColumns,
      dataGroup: {},
      dataGroupList: []
    }
  },
  watch: {
    dataSource () {
      console.log('初始化数据');
      this.initData();
    }
  },
  created () {
    this.initData();
  },
  methods: {
    initData () {
      // 按照细分类进行分组
      this.dataSource.forEach(item => {
        if (item.value === undefined || item.value === '') {
          item.value = item.defvalue;
        }
      });
      const dataGroup = this.dataGroup = groupBy(prop('category'), this.dataSource);
      const dataGroupList = Object.keys(dataGroup).map(group => {
        return {
          category: group,
          list: this.dataGroup[group],
        }
      });
      this.$set(this, 'dataGroupList', dataGroupList);
    },
    updateDataSource (value, record) {
      console.log('内容更新2', value, this.dataGroupList, record);
      record.value = value;
      const dataSource = this.dataGroupList.reduce(function (arr, item) {
        return arr.concat(item.list);
      }, []);
      console.log(dataSource);

      this.$emit('update', dataSource);
    }
    // aaa (e, r, t) {
    //   console.log(e, r.value, t);
    //   r.value = r.defvalue;
    // },
    // ccc (v, r, t) {
    //   console.log(v, r, t);
    //   r.value = v;
    //   t = v;
    // }
  }
};

const outColumns = [
  { title: '分类', dataIndex: 'category', key: 'category' },
];

const innerColumns = [{
  title: '#',
  dataIndex: 'serial',
  scopedSlots: { customRender: 'serial' },
  width: 24,
},{
  title: '名称',
  dataIndex: 'name',
  scopedSlots: { customRender: 'name' },
  width: 120,
}, {
  title: '分类',
  dataIndex: 'category',
  scopedSlots: { customRender: 'category' },
  width: 120,
},{
  title: '默认值',
  dataIndex: 'defvalue',
  scopedSlots: { customRender: 'defvalue' },
  width: 100,
}, {
  title: '设定值',
  dataIndex: 'value',
  key: 'value',
  scopedSlots: { customRender: 'value' },
  width: 180,
}, {
  title: '单位',
  dataIndex: 'unit',
  scopedSlots: { customRender: 'unit' },
  width: 160,
}, {
  title: '是否保存',
  dataIndex: 'saved',
  scopedSlots: { customRender: 'saved' },
  width: 80,
}, {
  title: '描述',
  dataIndex: 'desc',
  scopedSlots: { customRender: 'desc' },
}];
</script>

<style lang="less" scoped>
  .ant-table /deep/ .ant-table-body {
    margin: 0px;
    padding: 0px;
  }
</style>