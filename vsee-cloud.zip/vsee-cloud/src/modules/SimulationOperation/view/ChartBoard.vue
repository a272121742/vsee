<template>
  <card>
    <a-list
      size="small"
      :data-source="data"
    >
      <a-list-item
        slot="renderItem"
        slot-scope="item"
      >
        {{ item .title }}
        <a-icon
          slot="actions"
          type="edit"
        ></a-icon>
        <a-icon
          slot="actions"
          type="plus"
        ></a-icon>
      </a-list-item>
    </a-list>
  </card>
</template>

<script>

console.log('这个组件废弃掉');
export default {
  props: {
    data: {
      type: Array,
      default: () => ([{title: 't1'}, {title: 't2'}, {title: 't3'}])
    }
  }
}
</script>

<style lang="less" scoped>

</style>

