<template>
  <a-carousel
    arrows
  >
    <div
      slot="prevArrow"
      class="custom-slick-arrow"
      style="left: 0px; top: 192px; zIndex: 1"
    >
      <a-icon type="left-circle" />
    </div>
    <div
      slot="nextArrow"
      class="custom-slick-arrow"
      style="right: 24px; top: 192px; zIndex: 1"
    >
      <a-icon type="right-circle" />
    </div>
    <div
      style="padding: 0px 24px 12px"
      v-for="(page, p) in keyGroup"
      :key="p"
    >
      <a-row
        v-for="(row, r) in page"
        :key="r"
        :gutter="{ xs: 8, sm: 16, md: 24}"
      >
        <a-col
          v-for="(col, c) in row"
          :key="c"
          :span="8"
        >
          <v-chart
            :force-fit="true"
            :animate="true"
            :data="chartSet[keyGroup[p][r][c]]"
            :height="180"
            :padding="[12, 24, 24, 24]"
          >
            <!-- 提示信息 -->
            <v-tooltip />
            <!-- 坐标轴 -->
            <v-axis />
            <!-- 提示信息 -->
            <v-line position="year*value" />
            <v-point
              position="year*value"
              shape="circle"
            />
          </v-chart>
        </a-col>
      </a-row>
    </div>
  </a-carousel>
</template>

<script>
import { pipe, keys, splitEvery, length, lt, tap } from 'ramda';

export default {
  // 图表集合
  name: 'ChartSet',
  props: {
    chartSet: {
      type: Object,
      default: () => ({})
    }
  },
  data () {
    return {
      showPageArrow: false
    }
  },
  computed: {
    keyGroup () {
      return pipe(
        keys,
        // 列分组
        splitEvery(3),
        // 行分组
        splitEvery(2),
      )(this.chartSet);
    },
  },
  created () {
  },
  methods: {
    // 添加图集
   
  }
}
</script>

<style lang="less" scoped>
.ant-carousel {
  /deep/ .ant-row:not(:first-of-type) {
    padding-top: 24px;
  }
  /deep/ .custom-slick-arrow {
    width: 24px;
    height: 24px;
    font-size: 24px;
    color: #1890ff;
    opacity: 1;
    &:before {
      display: none;
    }
    &:hover {
      opacity: 0.5;
    }
  }
}
</style>

