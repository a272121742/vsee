<template>
  <div>
    <a-select
      placeholder="请选择需要查看的节点"
      style="width: 100%; margin-bottom: 1rem"
      @change="load"
    >
      <a-select-option
        v-for="node in nodeList"
        :key="node.id"
        :value="node.id"
      >
        {{ node.name }}
      </a-select-option>
    </a-select>
    <a-table
      :row-key="(r, i) => i"
      :columns="columns"
      :data-source="data"
      :pagination="false"
      :scroll="{y: 280}"
      :row-selection="{onSelect: handleRowSelect, onSelectAll: handleSelectAll, columnTitle: customTitle}"
    >
      '}"
      size="small"
      bordered
      >
    </a-table>
  </div>
</template>

<script>
import { createNamespacedHelpers } from 'vuex';
import { pipe, prop, partial, bind } from 'ramda';
import { string2json, map2list } from '@lib/util';

const { mapActions } = createNamespacedHelpers('SimulationOperation');

export default {
  // 变量表
  name: 'InoutVars',
  props: {
    // 源数据字符串
    nodeList: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      columns: [{
        title: '名称',
        dataIndex: 'name',
        key: 'name',
        width: 80,
      }, {
        title: '描述',
        dataIndex: 'desc',
        key: 'desc',
        width: 120
      }],
      data: [],
      customTitle: () => (
        // <a-icon type="step-forward" />
        <span></span>
      )
    }
  },
  mounted () {
    // 此处是禁用全选按钮，防止选择数据过多导致插入图片速度较慢
    // document.querySelector('.ant-checkbox-input').parentElement.parentElement.parentElement.remove();
  },
  methods: {
    ...mapActions([
      'getNode'
    ]),
    // 转码 String -> Array<Object>
    convertInoutVars: pipe(string2json, map2list('name')),
    // // 转码 Array<Object> -> String
    // reconvertInoutVars: pipe(list2map('name'), partialRight(JSON.stringify, [null, 2])),
    load (id) {
      this.getNode(id).then(res => {
        console.log('获取node', res);
        this.$set(this, 'data', this.convertInoutVars(res.result.inoutVars));
      });
    },
    // 行选择的时候，将数据抛向上层组件
    handleRowSelect (record, selected, selectedRows, nativeEvent) {
      selected ? this.$emit('selectOk', record.name) : this.$emit('selectCancel', record.name)
    },
    handleSelectAll (selected, selectedRows, changeRows) {
      const emit = bind(this.$emit, this);
      const event = selected ? 'selectOk' : 'selectCancel';
      changeRows.forEach(pipe(
        prop('name'),
        partial(emit, [event])
      ));
    }
  }
}
</script>
