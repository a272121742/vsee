

<template>
  <keep-alive>
    <a-modal
      :closable="false"
      :visible="visible"
      :width="720"
      @ok="handleOk"
      @cancel="() => visible = false"
    >
      <a-card
        ref="card"
        :tab-list="tabList"
        :active-tab-key="selectedTab"
        @tabChange="tabChange"
      >
        <!-- 标题计数器 -->
        <span
          slot="baseProps"
        >
          <a-icon type="usb" />基础配置
        </span>
        <span
          slot="inoutVars"
        >
          <a-icon type="profile" />变量配置
        </span>
      </a-card>
      <!-- 基础表单 -->
      <a-form
        v-show="selectedTab === 'baseProps'"
        layout="horizontal"
        :form="form"
      >
        <a-form-item
          label="节点模版"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-input
            disabled
            v-decorator="[
              'nodetypeID',
            ]"
            placeholder="请输入节点模版"
          >
          </a-input>
        </a-form-item>
        <a-form-item
          label="节点编号"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-input
            v-decorator="[
              'nodeID',
              {
                rules: [
                  { required: true, message: '节点编号不能为空'}
                ]
              }
            ]"
            placeholder="请输入节点编号"
          >
          </a-input>
        </a-form-item>
        <a-form-item
          label="节点名称"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-input
            v-decorator="[
              'name',
              {
                rules: [
                  { required: true, message: '节点名称不能为空'}
                ]
              }
            ]"
            placeholder="请输入节点名称"
          >
          </a-input>
        </a-form-item>
        <a-form-item
          label="优先级"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-slider
            v-decorator="[
              'priority',
            ]"
            placeholder="请输选择优先级，最小值0，最大值100"
          >
          </a-slider>
        </a-form-item>
        <a-form-item
          label="是否启用"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-checkbox
            v-decorator="[
              'enabled',
              { valuePropName: 'checked' }
            ]"
            placeholder="请输是否启用"
          >
          </a-checkbox>
        </a-form-item>
      </a-form>
      <a-table
        v-show="selectedTab === 'inoutVars'"
        :row-key="(r, i) => i"
        :columns="columns"
        :data-source="data"
        :pagination="false"
        :scroll="{y: 250}"
        size="small"
        bordered
      >
        <span
          slot="serial"
          slot-scope="text, row, index"
        >
          {{ index + 1 }}
        </span>
        <!-- 可编辑值 -->
        <a-input-number
          slot="defvalue"
          slot-scope="text, row"
          :value="text"
          :default-value="text"
          @change="(value) => row.defvalue = value"
        />
        <a-checkbox
          slot="saved"
          slot-scope="text, row"
          :checked="text === 1"
          @change="(e) => row.saved = e.target.checked + 0"
        >
        </a-checkbox>
      </a-table>
    </a-modal>
  </keep-alive>
</template>

<script>
import { pipe, partialRight } from 'ramda';
import { string2json, map2list, list2map } from '@lib/util';

export default {
  // 节点编辑
  name: 'NodeEdit',
  data () {
    return {
      visible: false,
      tabList: [{
        key: 'baseProps',
        name: '基础配置',
        scopedSlots: {tab: 'baseProps'}
      }, {
        key: 'inoutVars',
        name: '变量配置',
        scopedSlots: {tab: 'inoutVars'}
      }],
      selectedTab: 'baseProps',
      form: null,
      labelCol: {span: 4},
      wrapperCol: {span: 18},
      record: {},
      columns: [{
        title: '#',
        scopedSlots: { customRender: 'serial' },
        width: 80,
      }, {
        title: '变量名称',
        dataIndex: 'name',
        key: 'name',
        width: 120,
      }, {
        title: '初始值',
        dataIndex: 'defvalue',
        key: 'defvalue',
        scopedSlots: { customRender: 'defvalue' },
        width: 180,
      }, {
        title: '描述',
        dataIndex: 'desc',
        key: 'desc',
        width: 180,
      }, {
        title: '是否保存',
        dataIndex: 'saved',
        key: 'saved',
        scopedSlots: { customRender: 'saved' },
        width: 120,
      }],
      customRow: (record, index) => ({
        on: {
          click: () => {
            console.log('双击');
            record.editable = true;
          }
        }
      }),
      data: [],
    }
  },
  watch: {
    record () {
      this.form.updateFields({
        nodetypeID: this.$form.createFormField({value: this.record.nodetypeID}),
        nodeID: this.$form.createFormField({value: this.record.nodeID}),
        name: this.$form.createFormField({value: this.record.name}),
        priority: this.$form.createFormField({value: this.record.priority}),
        enabled: this.$form.createFormField({value: this.record.enabled}),
      });
      this.$set(this, 'data', this.convertInoutVars(this.record.inoutVars));
      this.selectedTab = 'baseProps';
    }
  },
  created () {
    this.form = this.$form.createForm(this, {
      mapPropsToFields: () => ({
        nodetypeID: this.$form.createFormField({value: this.record.nodetypeID}),
        nodeID: this.$form.createFormField({value: this.record.nodeID}),
        name: this.$form.createFormField({value: this.record.name}),
        priority: this.$form.createFormField({value: this.record.priority}),
        enabled: this.$form.createFormField({value: this.record.enabled}),
      })
    });
    this.$set(this, 'data', this.convertInoutVars(this.record.inoutVars));
  },
  methods: {
    load (data) {
      this.visible = true;
      this.$set(this, 'record', {...data});
    },
    // // 加载数据
    // show (dataString) {
    //   this.$set(this, 'data', this.convertInoutVars(dataString));
    //   this.visible = true;
    // },
    // 转码 String -> Array<Object>
    convertInoutVars: pipe(string2json, map2list('name')),
    // // 转码 Array<Object> -> String
    reconvertInoutVars: pipe(list2map('name'), partialRight(JSON.stringify, [null, 2])),
    handleOk () {
      this.form.validateFieldsAndScroll(err => {
        if (!err) {
          const inoutVars = this.reconvertInoutVars(this.data);
          const node = this.form.getFieldsValue();
          this.visible = false;
          this.$emit('change', {...this.record, ...node, inoutVars});
          this.clear();
        } else {
          this.selectedTab = 'baseProps';
        }
      });
    },
    tabChange (key) {
      this.selectedTab = key;
    },
    clear () {
      this.$nextTick(() => {
        this.$set(this, 'record', {});
      })
    },
  }
}
</script>

<style lang="less" scoped>
  

  .ant-card {
    border: none;
    margin: -16px -24px 0 -24px;
    padding-bottom: 24px;
    /deep/ .ant-card-head {
      min-height: 32px;
      padding: 0px 8px;
      .ant-card-head-title {
        padding: 12px 8px;
      }
    }
    // /deep/ .ant-card-body {
    //   padding: 0px;
    //   border-top: 1px solid #e8e8e8;
    // }
    // /deep/ .ant-table {
    //   border: none;
    //   .ant-table-content {
    //     border-right: 0px;
    //   }
    // }
    // /deep/ .ant-card-extra {
    //   padding: 0px;
    // }
    /deep/ .ant-tabs-tab {
      padding-top: 12px;
      padding-bottom: 12px;
      font-weight: 500;
    }
  }
</style>
