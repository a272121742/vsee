<template>
  <a-form
    :form="form"
  >
    <a-form-item
      label="节点模版"
    >
      <a-input
        disabled
        v-decorator="[
          'nodetypeID',
        ]"
        placeholder="请输入节点模版"
      >
      </a-input>
    </a-form-item>
    <a-form-item
      label="节点编号"
    >
      <a-input
        v-decorator="[
          'nodeID',
          {
            rules: [
              { required: true, message: '节点编号不能为空'}
            ]
          }
        ]"
        placeholder="请输入节点编号"
      >
      </a-input>
    </a-form-item>
    <a-form-item
      label="节点名称"
    >
      <a-input
        v-decorator="[
          'name',
          {
            rules: [
              { required: true, message: '节点名称不能为空'}
            ]
          }
        ]"
        placeholder="请输入节点名称"
      >
      </a-input>
    </a-form-item>
    <a-form-item
      label="优先级"
    >
      <a-slider
        v-decorator="[
          'priority',
        ]"
        placeholder="请输选择优先级，最小值0，最大值100"
      >
      </a-slider>
    </a-form-item>
    <a-form-item
      label="是否启用"
    >
      <a-checkbox
        v-decorator="[
          'enabled',
          { valuePropName: 'checked' }
        ]"
        placeholder="请输是否启用"
      >
      </a-checkbox>
    </a-form-item>
  </a-form>
</template>

<script>
export default {
  props: {
    data: {
      type: Object,
      default: () => ({})
    }
  },
  data () {
    return {
      form: null,
      record: {},
    }
  },
  watch: {
    record () {
      console.log('数据更新');
      this.form.updateFields({
        nodetypeID: this.$form.createFormField({value: this.record.nodetypeID}),
        nodeID: this.$form.createFormField({value: this.record.nodeID}),
        name: this.$form.createFormField({value: this.record.name}),
        priority: this.$form.createFormField({value: this.record.priority}),
        enabled: this.$form.createFormField({value: this.record.enabled}),
      });
    }
  },
  created () {
    this.form = this.$form.createForm(this, {
      onFieldsChange: (vm, changedFields) => {
        this.$emit('change', this.form.getFieldsValue());
      },
      mapPropsToFields: () => ({
        nodetypeID: this.$form.createFormField({value: this.record.nodetypeID}),
        nodeID: this.$form.createFormField({value: this.record.nodeID}),
        name: this.$form.createFormField({value: this.record.name}),
        priority: this.$form.createFormField({value: this.record.priority}),
        enabled: this.$form.createFormField({value: this.record.enabled}),
      })
    });
  },
  methods: {
    load (data) {
      this.$set(this, 'record', {...data});
    },
  }
}
</script>