import $ from '@/lib/ajax';
import { API_PREFIX } from '@/config';


export default {
  getAllProject: () => $.get(API_PREFIX + '/simulation_project')
};
