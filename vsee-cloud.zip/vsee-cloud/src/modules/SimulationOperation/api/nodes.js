import $ from '@/lib/ajax';
import { API_PREFIX } from '@/config';

export default {
  addNode: nodes => $.post(`${API_PREFIX}/node`, nodes),
  addNodeRS: nodesRS => $.post(`${API_PREFIX}/noders`, nodesRS),
  getNode: id => $.get(`${API_PREFIX}/node/${id}`),
  getNodes: projectID => $.get(`${API_PREFIX}/nodes/${projectID}`),
  removeAllNode: projectID => $.delete(`${API_PREFIX}/item_project/${projectID}`),
};

/**
 * @example config参数参看 https://www.npmjs.com/package/axios#request-config
   $.request(config);
   $.get(url, config);
   $.delete(url, config);
   $.head(url, config);
   $.post(url, data, config);
   $.put(url, data, config);
   $.patch(url, data, config)
 */
