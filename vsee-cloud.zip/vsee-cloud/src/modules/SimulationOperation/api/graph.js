import $ from '@/lib/ajax';
import { API_PREFIX } from '@/config';

export default {
  load: projectID => $.get(`${API_PREFIX}/graph/${projectID}`),
  save: graph => $.post(`${API_PREFIX}/graph`, graph),
};