<template>
  <div>
    <a-table
      :row-key="record => record.id"
      :columns="columns"
      :data-source="data"
    >
      <span
        slot="serial"
        slot-scope="text, record, index"
      >
        {{ index + 1 }}
      </span>

      <template
        slot="haveRun"
        slot-scope="haveRun"
      >
        <a-icon
          type="play-circle"
          v-if="haveRun"
        />
        <a-icon
          type="pause-circle"
          v-else
        />
      </template>
      <span
        slot="operation"
        slot-scope="text, record"
      >
        <a-icon
          type="edit"
          @click="() => handleEnter(record.id)"
        />
      </span>
    </a-table>
  </div>
</template>

<script>
import { createNamespacedHelpers } from 'vuex';

const { mapActions } = createNamespacedHelpers('SimulationOperation');

export default {
  // 仿真项目管理
  name: 'SimulationProjectManagement',
  data () {
    return {
      columns: [{
        title: '#',
        scopedSlots: { customRender: 'serial' },
        width: 32,
      }, {
        title: '项目名称',
        dataIndex: 'name',
        scopedSlots: {customRender: 'name'}
      }, {
        title: '创建者',
        dataIndex: 'author',
        scopedSlots: {customRender: 'author'}
      }, {
        title: '创建时间',
        dataIndex: 'createDate',
        scopedSlots: {customRender: 'createDate'}
      }, {
        title: '运行状态',
        dataIndex: 'haveRun',
        scopedSlots: {customRender: 'haveRun'}
      }, {
        title: '操作',
        scopedSlots: { customRender: 'operation' },
      }],
      data: []
    }
  },
  created () {
    this.getAllProject().then(res => {
      this.$set(this, 'data', res.result);
    });
  },
  methods: {
    ...mapActions([
      'getAllProject',
    ]),
    handleEnter (id) {
      this.$router.push({name: 'SimulationDataAnalysis', params: {projectID: String(id)}});
    }
  }
}
</script>
