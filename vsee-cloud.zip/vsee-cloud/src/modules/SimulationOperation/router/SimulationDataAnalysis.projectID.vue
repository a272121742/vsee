<template>
  <div
    class="g6-editor-container"
  >
    <!-- 表单
    <a-form
      style="padding-left: 16px;"
      layout="inline"
      :form="form"
    >
      <a-form-item
        label="仿真起止时间"
      >
        <a-slider
          style="width: 280px;"
          auto-focus
          range
          v-decorator="['startStopTime', {initialValue: [1, 7]}]"
        />
      </a-form-item>
      <a-form-item>
        <a-button
          type="primary"
          @click="startSimulation"
        >
          启动
        </a-button>
      </a-form-item>
      <a-form-item>
        <a-button @click="stopSimulation">
          停止
        </a-button>
      </a-form-item>
      <a-form-item>
        <a-button @click="viewSimulation">
          查看
        </a-button>
      </a-form-item>
    </a-form> -->
    <!-- 节点属性编辑框 -->
    <!-- <keep-alive>
      <node-edit-modal
        ref="inoutVarsTable"
        @change="nodeMetaDataChange"
      />
    </keep-alive> -->
    
    <!-- 流程图编辑器 -->
    <keep-alive>
      <simulation-editor
        ref="flow"
        :items="items"
        :data="data"
        :data-mapping="dataMapping"
        @render="graphRended"
        @node:dbClick="nodeDbClick"
        @node:selected="nodeSelected"
        @saved="graphSaved"
      >
        <template
          v-slot="{item: { __businessData__ : stdnode}}"
        >
          <a-card
            hoverable
          >
            <template #cover>
              <img
                :alt="stdnode.name"
                :src="stdnode.iconpath"
              />
            </template>
            <a-card-meta
              :title="stdnode.name"
            >
              <template #description>
                {{ stdnode.desc }}
              </template>
            </a-card-meta>
          </a-card>
        </template>
        <template #action>
          <a-button
            size="small"
            type="primary"
            @click="validateGraph"
          >
            校验
          </a-button>
        </template>
        <!-- 属性编辑 -->
        <template #attr>
          <BaseAttrEditForm
            ref="attrEditForm"
            @change="attrUpdate"
          ></BaseAttrEditForm>
        </template>
      </simulation-editor>
    </keep-alive>
    <!-- 节点属性修改地方，后期改为收缩框 -->
    <a-drawer
      placement="bottom"
      get-container="#attr-drawer"
      style="width: 50%;"
      :mask-closable="false"
      :mask="false"
      :visible="showNodeAttr"
      :height="360"
      @close="() => showNodeAttr = false"
    >
      <a-tabs
        v-if="selectedNode"
        :default-active-key="selectedTab"
        size="small"
      >
        <!-- <a-tab-pane
          key="1"
        >
          <span slot="tab">
            <a-icon type="setting" />
            基础配置
          </span>
          <base-attr-edit></base-attr-edit>
        </a-tab-pane> -->
        <a-tab-pane
          v-for="group in varsGroupList"
          :key="group.title"
        >
          <span slot="tab">
            <!-- <a-icon type="setting" /> -->
            {{ group.title }}
          </span>
          <var-attr-edit-table
            :data-source="group.dataSource"
            @update="ds => groupUpdate(group.title, ds)"
          ></var-attr-edit-table>
        </a-tab-pane>
      </a-tabs>
    </a-drawer>
    <!-- 图表弹出抽屉（底部） -->
    <a-drawer
      placement="bottom"
      height="400"
      :get-container="'#attr-drawer'"
      :visible="showChartSet"
      @close="() => this.showChartSet = false"
    >
      <template slot="handle">
        <a-row
          :gutter="16"
        >
          <a-col :span="6">
            <!-- 属性表格 -->
            <inout-vars-table
              :node-list="dragedNodeList"
              @selectOk="selectOk"
              @selectCancel="selectCancel"
            />
          </a-col>
          <a-col :span="18">
            <!-- 图表集 -->
            <chart-set :chart-set="chartSet"></chart-set>
          </a-col>
        </a-row>
      </template>
    </a-drawer>
    <affix-buttons :top="200">
      <a-button
        type="primary"
        icon="setting"
      >
        画布
      </a-button>
    </affix-buttons>
    <affix-buttons :top="240">
      <a-button
        type="primary"
        icon="setting"
        @click="$router.push({name: 'SimulationConfiguration', params: {projectID: String(projectID)}})"
      >
        仿真
      </a-button>
    </affix-buttons>
    <div
      id="attr-drawer"
    >
    </div>
  </div>
</template>

<script>
import { clone, countBy, prop, propEq, forEach, filter, pipe, sortBy, groupBy, reverse, pick, partialRight, map, addIndex, unnest, indexBy, empty } from 'ramda';
import { createNamespacedHelpers } from 'vuex';
import { string2json, map2list, list2map, clearObserver } from '@lib/util';
import graph from '../api/graph';
const { mapActions } = createNamespacedHelpers('SimulationOperation');
const businessDataName = '__businessData__';
const EXAMPLE_DATA = [
  { year: '1995', value: 4.9 },
  { year: '1996', value: 6 },
  { year: '1997', value: 7 },
  { year: '1998', value: 9 },
  { year: '1999', value: 13 },
];
export default {
  name: 'SimulationDataAnalysis',
  components: {
    SimulationEditor: () => import('@comp/G6Editor/SimulationEditor'),
    AffixButtons: () => import('@comp/AffixButtons'),
    // NodeEditModal: () => import('../view/NodeEdit'),
    BaseAttrEditForm: () => import('../view/BaseAttrEdit'),
    InoutVarsTable: () => import('../view/InoutVars.vue'),
    ChartSet: () => import('../view/CarouselChartSet.vue'),
    // BaseAttrEdit: () => import('../view/BaseAttrEdit.vue'),
    VarAttrEditTable: () => import('../view/VarAttrEditTable.vue'),
  },
  props: {
    projectID: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      // 表单
      form: null,
      /**
       * 画板的渲染数据，从数据库中获取
       */
      data: {},
      /**
       * 画板左侧`ItemPanel`中的项目清单
       * 每一项的格式： {anchors, businessDataName}
       */
      items: [],
      /**
       * 当前双击选择的node，用于编辑数据
       */
      selectedNode: {},
      /**
       * 页面上已经拖拽出来的node集合
       */
      dragedNodeList: [],
      /**
       * 
       */
      showNodeAttr: false,
      /**
       * 
       */
      varsGroupList: [],
      /**
       * 
       */
      selectedTab: '',
      /**
       * 是否显示图表矩阵
       */
      showChartSet: false,
      /**
       * 图表矩阵
       */
      chartSet: {},
    }
  },
  computed: {
    flow () {
      return this.$refs.flow;
    }
  },
  watch: {
    selectedNode (e) {
      const nodeCopy = clone(e.item[businessDataName]);
      console.log('选中节点数据更新');
      // setFieldsValue updateFields
      this.form.updateFields({
        nodetypeID: this.$form.createFormField({value: nodeCopy.nodetypeID}),
        nodeID: this.$form.createFormField({value: nodeCopy.nodeID}),
        name: this.$form.createFormField({value: nodeCopy.name}),
        priority: this.$form.createFormField({value: nodeCopy.priority}),
        enabled: this.$form.createFormField({value: nodeCopy.enabled}),
      });
    }
  },
  created () {
    window.vm3 = this;
    console.log('SimulationDataAnalysis created');
    const projectID = Number(this.projectID || '0');
    if (projectID) {
      this.loadGraph(projectID).then(res => {
        if (res.result && res.result.data) {
          this.$set(this, 'data', JSON.parse(res.result.data || '{}'));
        }
      });
    }
    this.form = this.$form.createForm(this, {
      mapPropsToFields: () => ({
        nodetypeID: this.$form.createFormField({value: 'null'}),
        nodeID: this.$form.createFormField({value: 'null'}),
        name: this.$form.createFormField({value: 'null'}),
        priority: this.$form.createFormField({value: 40}),
        enabled: this.$form.createFormField({value: false}),
      })
    });
    this.initItems();
  },
  mounted () {
    // // 触发text的数值变化后，更新图的数据
    // const input = this.$el.querySelector('.p.name .ant-input');
    // // console.log(input);
    // function oninputCallback () {
    //   console.log('oninput event ');
    // }
    // function onchangeCallback () {
    //   console.log('onchange event');
    // }
    // input.addEventListener('oninput', oninputCallback, false);
    // input.addEventListener('onchange', onchangeCallback, false);
    // Object.defineProperty(input, '_value', {
    //   configurable: true,
    //   set: function (value) {
    //     this.value = value;
    //     oninputCallback();
    //     onchangeCallback();
    //   },
    //   get: function () {
    //     return this.value;
    //   }
    // });
  },
  // activated () {
  //   console.log('this page activated');
  //   const projectID = Number(this.projectID || '0');
  //   if (projectID) {
  //     this.loadGraph(projectID).then(res => {
  //       this.$set(this, 'data', res.result.data || {});
  //       this.initItems();
  //     });
  //   }
  // },
  methods: {
    ...mapActions([
      'getStdnodes',
      'removeAllNode',
      'addNode',
      'addNodeRS',
      'getNodes',
      'saveGraph',
      'loadGraph',
    ]),
    // 转换`portDefine`属性，转码 String -> Array<Object>
    convertPortDefine: pipe(string2json, map2list('port')),
    // 转换`inoutVars`属性，转码 String -> Array<Object>
    convertInoutVars: pipe(string2json, map2list('name')),
    // 反转`inoutVars`属性，转码 Array<Object> -> String
    reconvertInoutVars: pipe(list2map('name'), partialRight(JSON.stringify, [null, 2])), // [null, 2]用于格式化，实际使用时替换为[]
    /**
     * 初始化`ItemPanel`中的Items项，加载业务数据
     */
    initItems () {
      /**
     * 流程说明，组件创建完成之后，向后台发起数据请求，获得所有的模型库；
     * 接着按照`G6-editor`的`item`所需要的格式进行拼装。
     * 这里将`businessDataName`保留的是业务数据
     */
      this.getStdnodes().then(res => {
        const result = res.result;
        const items = result.map((stdnode) => {
          const item = {};
          item.name = stdnode.name;
          item.src = stdnode.iconpath;
          item.group = stdnode.type;
          // 获取所有的端口列表
          // 端口分组
          const portGroup = pipe(this.convertPortDefine, groupBy(prop('type')))(stdnode.portDefine);
          const portsIn = sortBy(prop('order'), portGroup.in || []);
          const portsOut = sortBy(prop('order'), portGroup.out || []);
          const ports = [...portsIn, ...portsOut];
          // 依据类型进行分组，转换成如下格式： `{in: 3, out: 2}`
          const types = {in: portsIn.length, out: portsOut.length};
          // 类型字典的拷贝，用于计算分子
          const t = clone(types);
          const anchors = map(port => [
            // 锚点的x轴，如果是`in`取`0`，反之为`out`取`1`;
            port.type === 'in' ? 0 : 1,
            // 锚点的y轴，因为已经排好顺序，按照如下规则即可算出
            (t[port.type]--) / (types[port.type] + 1),
            // 将业务中`port`信息注入锚点中
            {...port}
          ])(ports);
          // 挂载端口信息，避免后期重复计算
          item.anchors = anchors;
          item[businessDataName] = clone(pick(['nodeID', 'name', 'inoutVars'], stdnode));
          item[businessDataName].projectID = Number(this.projectID);
          item[businessDataName].priority = 0;
          item[businessDataName].enabled = true;
          item[businessDataName].nodetypeID = stdnode.nodeID;
          item[businessDataName].iconpath = stdnode.iconpath;
          return item;
        });
        this.$set(this, 'items', items);
      });
    },
    /**
     * `graph`渲染完成后，回调函数中返回所有的节点，以便注入业务数据。
     */
    graphRended (nodes) {
      this.getNodes(this.projectID).then(res => {
        const nodeMap = indexBy(prop('graphID'), unnest([res.result]));
        nodes.forEach(node => {
          this.$set(node, businessDataName, nodeMap[node.id]);
        });
      });
    },
    /**
     * 节点选中后，渲染数据到右侧表单
     */
    nodeSelected (e) {
      
      const nodeCopy = clone(e.item[businessDataName]);
      // nodeCopy.name = e.item.model.label;
      this.$set(this, 'selectedNode', e);
      console.log('选中了节点，更新表单', nodeCopy.name);
      this.$refs.attrEditForm.load(nodeCopy);
      // this.form.setFieldsValue({
      //   nodetypeID: this.$form.createFormField({value: nodeCopy.nodetypeID}),
      //   nodeID: this.$form.createFormField({value: nodeCopy.nodeID}),
      //   name: this.$form.createFormField({value: nodeCopy.name}),
      //   priority: this.$form.createFormField({value: nodeCopy.priority}),
      //   enabled: this.$form.createFormField({value: nodeCopy.enabled}),
      // });
    },
    /**
     * 节点双击时，编辑业务数据
     */
    nodeDbClick (e) {
      const nodeCopy = clone(e.item[businessDataName]);
      // nodeCopy.name = e.item.model.label;
      this.$set(this, 'selectedNode', e);
      console.log(nodeCopy);
      // 将字符串转换为对象
      const inoutVars = this.convertInoutVars(nodeCopy.inoutVars).filter(item => item.type === 0);
      const inoutVarsGroups = groupBy(prop('group') ,inoutVars);
      const varsGroupList = Object.keys(inoutVarsGroups).map(title => {
        return {
          title,
          dataSource: inoutVarsGroups[title]
        }
      });
      this.$set(this, 'varsGroupList', varsGroupList);
      this.selectedTab = varsGroupList[0] ? varsGroupList[0].title : '';
      console.log(varsGroupList);
      // this.$refs.inoutVarsTable.load(nodeCopy);
      // 双击时展开属性配置菜单
      this.showNodeAttr = true;
    },
    /** 保存图片数据 */
    async graphSaved (graphData, itemData) {
      if (itemData.nodes && itemData.nodes.length) {
        // 删除所有元素
        await this.removeAllNode(this.projectID);
        // 新增节点
        const res = await this.addNode(itemData.nodes.map(prop(businessDataName)));
        this.$set(this, 'dragedNodeList', unnest([res.result]));
        // 构建连线
        const nodeMap = indexBy(prop('graphID'), unnest([res.result]));
        
        const nodeRSs = itemData.edges.map(edge => ({
          rsID: edge.id,
          soursID: nodeMap[edge.model.source].id,
          destID: nodeMap[edge.model.target].id,
          soursPort: edge.source.getAnchorPoints(edge.model.sourceAnchor).port,
          destPort: edge.target.getAnchorPoints(edge.model.targetAnchor).port,
        }));
        
        // 添加连线
        await this.addNodeRS(nodeRSs);
        // 保存图
        this.saveGraph({projectID: Number(this.projectID), data: JSON.stringify(graphData)}).then(res => {
          this.$message.success('保存成功');
        });
      }
    },
    validateGraph () {
      console.log('验证模型', this.$refs.flow.getData());
      const graphData = this.$refs.flow.getData();
      graphData.nodes = graphData.nodes || [];
      graphData.edges = graphData.edges || [];
      if (graphData.edges.length < graphData.nodes.length - 1) {
        return this.$message.warn('所有模型未完全连接，请连接完所有的模型');
      }
      let emptyEdgeCount = 0;
      let singleEdgeCount = 0;
      const nodes = clone(graphData.nodes);
      for(var i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        const edges = graphData.edges.filter(edge => (edge.source === node.id) || (edge.target === node.id)
        );
        switch (edges.length) {
        case 0: ++emptyEdgeCount; break;
        case 1: ++singleEdgeCount; break;
        default: break;
        }
        if (emptyEdgeCount > 0 || singleEdgeCount > 2) {
          break;
        } 
      }
      // 只有起点和终点只连接了一根，其他的都应该是至少连接2个的
      if (emptyEdgeCount > 0 || singleEdgeCount > 2) {
        return this.$message.warn('所有模型未完全连接，请连接完所有的模型');
      }
      return this.$message.success('验证通过');
    },
    /**
     * 编辑节点业务数据后，进行存储
     */
    nodeMetaDataChange (node) {
      const label = this.$el.querySelector('.p.name .ant-input');
      // // 触发text的数值变化后，更新图的数据
      // const input = this.$el.querySelector('.p.name .ant-input');
      // // console.log(input);
      // function oninputCallback () {
      //   console.log('oninput event ');
      // }
      // function onchangeCallback () {
      //   console.log('onchange event');
      // }
      // input.addEventListener('oninput', oninputCallback, false);
      // input.addEventListener('onchange', onchangeCallback, false);
      // Object.defineProperty(input, '_value', {
      //   configurable: true,
      //   set: function (value) {
      //     this.value = value;
      //     oninputCallback();
      //     onchangeCallback();
      //   },
      //   get: function () {
      //     return this.value;
      //   }
      // });
      label._value = node.name;
      // this.selectedNode.item.model.label = node.name;
      // 存储到数据库?
      this.$set(this.selectedNode.item, businessDataName, node);
    },
    groupUpdate (title, dataSource) {
      console.log('分组数据更新', this.varsGroupList , title, dataSource);
      const index = this.varsGroupList.findIndex(group => group.title === title);
      this.$set(this.varsGroupList, index, {title, dataSource});
      const inoutVars = this.varsGroupList.reduce(function (arr, group) {
        return arr.concat(group.dataSource);
      }, []);
      this.$set(this.selectedNode.item[businessDataName], 'inoutVars', this.reconvertInoutVars(inoutVars));
    },
    attrUpdate (baseAttr) {
      if (this.selectedNode && this.selectedNode.item) {
        const item = this.selectedNode.item;
        const attr = item[businessDataName];
        this.$set(item, businessDataName, {...attr, ...baseAttr});
        console.log(this.selectedNode.item[businessDataName]);
        item.graph.update(item.id, {label: baseAttr.name});
      }
      
    },
    /**
     * 启动仿真运行
     */
    startSimulation () {
      this.showChartSet = true;
      this.flow.save();
    },
    /**
     * 停止仿真运行
     */
    stopSimulation () {
      this.showChartSet = false;
    },
    /**
     * 查看仿真运行结果
     */
    viewSimulation () {
      this.showChartSet = true;
    },
    selectOk (name) {
      this.$set(this.chartSet, name, EXAMPLE_DATA);
    },
    selectCancel (name) {
      this.$delete(this.chartSet, name, EXAMPLE_DATA);
    },
    dataMapping (node, item) {
      console.log('12313123',node, item);
      node[businessDataName] = {...item[businessDataName], graphID: node.id};
    }
  }
}
</script>

<style lang="less" scoped>
  .g6-editor-container {
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB",
      "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
    height: 100%;
    box-shadow: 0 2px 8px rgba(0,0,0,.15);
  }
  
  #attr-drawer {
    /deep/ .ant-drawer-content-wrapper {
      width: calc(100% - 228px);
    }
    /deep/ .ant-drawer-body {
      padding: 0px;
      padding-top: 4px;
    }
    /deep/ .ant-drawer-close-x {
      line-height: 42px;
    }
    /deep/ .ant-tabs-bar {
      margin: 0px;
    }
    /deep/ .ant-table-small {
      border-bottom: none;
    }
  }
</style>

