<template>
  <div class="sim-container">
    <!-- 表单 -->
    <a-row style="margin-bottom: 12px">
      <a-col
        :span="24"
        class="block"
      >
        <a-form
          style="padding-left: 16px; box-shadow: 0 2px 8px rgba(0,0,0,.15);"
          layout="inline"
          :form="form"
        >
          <a-form-item label="仿真起始时间">
            <a-input-number
              :precision="0"
              size="small"
              auto-focus
              :value="1"
              v-decorator="['startTime', {initialValue: 1}]"
            />
          </a-form-item>
          <a-form-item label="仿真终止时间">
            <a-input-number
              :precision="0"
              size="small"
              :value="10"
              v-decorator="['stopTime', {initialValue: 7}]"
            />
          </a-form-item>
          <a-form-item>
            <a-button
              v-if="simStatus === 'stop' || simStatus === 'pause'"
              type="primary"
              size="small"
              @click="showSimChart"
            >
              开始
            </a-button>
            <a-button
              v-if="simStatus === 'start'"
              type="primary"
              size="small"
              @click=" e => simStatus = 'pause'"
            >
              暂停
            </a-button>
          </a-form-item>
          <a-form-item>
            <a-progress
              :percent="50"
              size="small"
              status="active"
              style="width:200px;"
            />
          </a-form-item>
          <a-form-item>
            <a-button
              v-if="simStatus === 'start'"
              type="primary"
              size="small"
              @click=" e => simStatus = 'stop'"
            >
              终止
            </a-button>
          </a-form-item>
        </a-form>
      </a-col>
    </a-row>
    
    <a-row
      style="height: calc(100% - 43px);"
      :gutter="12"
    >
      <a-col
        :span="12"
        style="height: 100%;"
      >
        <div style="height: calc(100% - 312px); margin-bottom: 12px; box-shadow: 0 2px 8px rgba(0,0,0,.15); background: #FFF;">
          <a-tabs
            v-if="selectedNode"
            style="height: 100%;"
            :default-active-key="selectedTab"
            size="small"
          >
            <a-tab-pane
              class="inner-table-pane"
              style="height: 100%; overflow-y: scroll;"
              v-for="group in varsGroupList"
              :key="group.title"
            >
              <span slot="tab">
                <!-- <a-icon type="setting" /> -->
                {{ group.title }}
              </span>
              <a-collapse
                :bordered="false"
                active-key="0"
              >
                <template v-if="group.dataSource && group.dataSource.length">
                  <a-collapse-panel
                    v-for="(ds, index) in group.dataSource"
                    :header="ds.category || '默认分组'"
                    :key="index"
                  >
                    <a-table
                      v-sortable="{el: '.ant-table-wrapper .ant-table-body table .ant-table-tbody', sort: false, handle: '.anticon-drag', group: {name: 'shared', pull: 'clone', put: false}, onStart: tableRowDragStart, onEnd: tableRowDragEnd}"
                      bordered
                      :columns="innerColumns"
                      :data-source="ds.list"
                      :pagination="false"
                      size="small"
                      row-key="name"
                    >
                      <!-- 数字标记 -->
                      <template
                        slot="serial"
                        slot-scope="text, record, i"
                      >
                        {{ i + 1 }}
                      </template>
                      <template
                        slot="value"
                        slot-scope="value, record"
                      >
                        <a-input 
                          size="small"
                          :default-value="record.defvalue || 0"
                          @change="e => updateDataSource(e.target.value, record)"
                        ></a-input>
                      </template>
                      <!-- 拖拽区域 -->
                      <template slot="drag">
                        <!-- <a
                      class="delete-icon"
                      @click="removeDragedItem"
                    ><a-icon
                      type="delete"
                    /></a> -->
                        <a
                          v-if="simStatus === 'stop'"
                          style="cursor:move;"
                        ><a-icon type="drag" /></a>
                      </template>
                    </a-table>
                  </a-collapse-panel>
                </template>
              </a-collapse>
              <!-- <a-table
                style="display: none;"
                :columns="outColumns"
                :data-source="group.dataSource"
                :show-header="false"
                :pagination="false"
                :default-expand-all-rows="true"
                :expand-row-by-click="true"
                size="small"
                row-key="category"
              >
                <a-table
                  v-sortable="{el: '.ant-table-wrapper .ant-table-body table .ant-table-tbody', sort: false, handle: '.anticon-drag', group: {name: 'shared', pull: 'clone', put: false}, onStart: tableRowDragStart, onEnd: tableRowDragEnd}"
                  slot="expandedRowRender"
                  slot-scope="{list}"
                  bordered
                  :columns="innerColumns"
                  :data-source="list"
                  :pagination="false"
                  size="small"
                  row-key="name"
                >
                  <template
                    slot="serial"
                    slot-scope="text, record, index"
                  >
                    {{ index + 1 }}
                  </template>
                  <template
                    slot="value"
                    slot-scope="value, record"
                  >
                    <a-input 
                      size="small"
                      :default-value="record.defvalue || 0"
                      @change="e => updateDataSource(e.target.value, record)"
                    ></a-input>
                  </template>
                  <template slot="drag">
                    <a
                      style="cursor:move;"
                    ><a-icon type="drag" /></a>
                  </template>
                </a-table>
              </a-table> -->
            </a-tab-pane>
          </a-tabs>
        </div>
        <div style="height: 300px; box-shadow: 0 2px 8px rgba(0,0,0,.15);">
          <flow-view
            :data="data"
            @render="graphRended"
            @node:click="nodeClick"
          ></flow-view>
        </div>
      </a-col>
      <a-col
        :span="12"
        style="height: 100%; "
      >
        <a-tabs
          default-active-key="1"
          size="small"
          style="background: #FFF; height: 100%; box-shadow: 0 2px 8px rgba(0,0,0,.15);"
        >
          <a-tab-pane
            key="1"
            tab="图表"
            style=""
          >
            <!-- <div
              v-sortable="{group: {name: 'trash', pull: false, put: 'shared'}}"
              class="item-trash"
            > -->
            <div
              class="item-trash-container"
            >
              <div
                v-show="itemDraged"
                v-sortable="{group: {name: 'trash', pull: false, put: 'shared'}}"
                class="item-trash-content"
              >
                <div>
                  <a-icon type="delete"></a-icon>
                  拖拽到此移除
                </div>
              </div>
            </div>
            <!-- <div id="dragSource">
              <div class="grid-square">
              </div>
            </div> -->
            <!-- <template
              v-for="(item, index) in chartBoards"
            >
              <div
                v-show="index !== chartBoards.length - 1 || attrCloned"
                v-sortable="{group: {name: 'shared'}, disabled: false,dragoverBubble: false}"
                :key="index"
                class="grid-square"
              >
              </div>
            </template> -->
            
            <!--  v-sortable="{ghostClass: 'grid-square', group: {name: 'shared'}, disabled: false, onChoose: handleChoose, onUnchoose: handleUnchoose, onStart: handleStart, onEnd: handleEnd, onAdd: handleAdd, onUpdate: handleUpdate, onSort: handleSort, onRemove: handleRemove, onFilter: handleFilter, onMove: handleMove, onClone: handleClone, onChange: handleChange}" -->
            <grid-layout
              ref="grid"
              :layout.sync="testLayout"
              :col-num="6"
              :row-height="48"
              :is-draggable="simStatus === 'stop'"
              :is-resizable="simStatus === 'stop'"
              :is-mirrored="false"
              :vertical-compact="true"
              :margin="[10, 10]"
              :use-css-transforms="true"
            >
              <!-- v-show="index !== testLayout.length - 1 || attrCloned" -->
              <!-- v-sortable="{group: {name: 'shared'}, disabled: false,dragoverBubble: false}" -->
              <!-- :class="index !== testLayout.length - 1 || attrCloned ? 'cunzai' : 'nocunzai'" -->
              <!-- v-if="!showChart && index !== testLayout.length - 1 || attrCloned" -->
              <template v-for="(item, index) in testLayout">
                <grid-item
                  v-if="!showChart && index !== testLayout.length - 1 || attrCloned"
                  :class="{ 'wait-drop-area' : index === testLayout.length - 1 && attrCloned }"
                  :key="item.i"
                  :x="item.x"
                  :y="item.y"
                  :w="item.w"
                  :h="item.h"
                  :i="item.i"
                  drag-ignore-from="a, button, .chartBoard-content"
                >
                  <div
                    ref="chartContainer"
                    class="chartBoard"
                  >
                    <!-- <a-icon
                      class="item-extra"
                      type="setting"
                      @click="configItem"
                    ></a-icon> -->
                    <a-radio-group
                      class="item-extra"
                      style="position: absolute; right: calc(50% - 52px); "
                      size="small"
                      button-style="solid"
                      default-value="sy"
                      :value="item.chartConf.type"
                      @change="e => changeYaxisType(e, item.chartConf)"
                    >
                      <a-radio-button value="sy">
                        单Y轴
                      </a-radio-button>
                      <a-radio-button value="my">
                        多Y轴
                      </a-radio-button>
                    </a-radio-group>
                    <div
                      v-sortable="{group: {name: 'shared'}, disabled: false, handle: '.anticon-drag', onStart: chartBoardItemDragStart, onEnd: chartBoardItemDragEnd}"
                      class="chartBoard-content"
                    >
                      <div
                        v-for="(conf, index2) in (item.chartConf.confs)"
                        class="chartBoard-content-item"
                        :key="index2"
                      >
                        <div style="display: none;">
                          {{ conf }}
                        </div>
                        <div style="width: calc(100% - 88px); float:left; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                          {{ conf.name }}
                        </div> 
                        <a-radio-group
                          style=""
                          size="small"
                          button-style="solid"
                          default-value="line"
                          :value="conf.type"
                          @change="e => changeChartType(e, conf)"
                        >
                          <a-radio-button value="line">
                            <a-icon type="line-chart"></a-icon>
                          </a-radio-button>
                          <a-radio-button
                            value="bar"
                            :disabled="item.chartConf.type === 'my'"
                          >
                            <a-icon type="bar-chart"></a-icon>
                          </a-radio-button>
                        </a-radio-group>
                        <a-icon
                          type="drag"
                          style="line-height: 2; color: rgba(0, 0, 0, 0.65); cursor: drag;"
                        />
                      </div>
                    </div>
                  </div>
                </grid-item>
              </template>
              <!-- <template v-for="num in 6">
                <div
                  ref="chartContainer"
                  :key="num"
                  style="float: left; width: 256px; height: 140px; border: 1px solid blue; margin-right: 12px; margin-bottom: 12px;"
                ></div>
              </template> -->
            </grid-layout>
          </a-tab-pane>
        </a-tabs>
      </a-col>
    </a-row>
    <affix-buttons :top="200">
      <a-button
        type="primary"
        icon="setting"
        @click="$router.push({name: 'SimulationDataAnalysis', params: {projectID: String(projectID)}})"
      >
        画布
      </a-button>
    </affix-buttons>
    <affix-buttons :top="240">
      <a-button
        type="primary"
        icon="setting"
      >
        仿真
      </a-button>
    </affix-buttons>
  </div>
</template>

<script>
import {indexBy, groupBy, prop, unnest, clone, pipe} from 'ramda';
import { createNamespacedHelpers } from 'vuex';
import VueGridLayout from 'vue-grid-layout';
import { map2list, string2json } from '@lib/util';
import Echarts from 'echarts';

const { mapActions } = createNamespacedHelpers('SimulationOperation');
const businessDataName = '__businessData__';

// console.log('获得模块',import('vue-grid-layout').then(m => m.GridLayout));
export default {
  name: 'SimulationConfiguration',
  components: {
    FlowView: () => import('@comp/G6Editor/FlowView'),
    AffixButtons: () => import('@comp/AffixButtons'),
    // function () {
    //   return import('vue-grid-layout');
    // }
    // GridLayout: VueGridLayout.GridLayout,
    // GridItem: VueGridLayout.GridItem
  },
  props: {
    projectID: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      /**
       * 画板的渲染数据，从数据库中获取
       */
      data: {},
      form: null,
      outColumns,
      innerColumns,
      testLayout: [
        {x: 0, y: 0, w: 3, h: 3, minW: 2, i: Date.now(), chartConf: {type: 'sy', confs: []}},
        // {x: 3, y: 0, w: 3, h: 3, minW: 2, i: 1, data: []},
        // {x: 0, y: 3, w: 3, h: 3, minW: 2, i: 2},
        // {x: 3, y: 3, w: 3, h: 3, minW: 2, i: 3},
        // {x: 0, y: 6, w: 3, h: 3, minW: 2, i: 2},
        // {x: 3, y: 6, w: 3, h: 3, minW: 2, i: 3},
      ],

      attrCloned: false,
      itemDraged: false,
      chartBoards: [{}],
      varsGroupList: [],
      selectedTab: '',
      selectedNode: null,
      showChart: false,
      simStatus: 'stop',
      cstr
    }
  },
  watch: {
    // waitDropFlag () {
    //   return index !== testLayout.length - 1 || attrCloned;
    // }
  },
  created () {
    console.log('重新created SimulationConfiguration2');
    const projectID = Number(this.projectID || '0');
    if (projectID) {
      this.loadGraph(projectID).then(res => {
        if (res.result && res.result.data) {
          this.$set(this, 'data', JSON.parse(res.result.data || '{}'));
        }
      });
    }
  },
  methods: {
    ...mapActions([
      'loadGraph',
      'getNodes',
      'getWsData',
    ]),
    // 转换`inoutVars`属性，转码 String -> Array<Object>
    convertInoutVars: pipe(string2json, map2list('name')),
    graphRended (nodes) {
      this.getNodes(this.projectID).then(res => {
        const nodeMap = indexBy(prop('graphID'), unnest([res.result]));
        nodes.forEach(node => {
          this.$set(node, businessDataName, nodeMap[node.id]);
        });
      });
    },
    nodeClick (e) {
      console.log('节点点击1', e);
      const nodeCopy = clone(e.item[businessDataName]);
      this.$set(this, 'selectedNode', e);
      console.log(nodeCopy);
      // 将字符串转换为对象
      const inoutVars = this.convertInoutVars(nodeCopy.inoutVars).filter(item => item.type === 1);
      const inoutVarsGroups = groupBy(prop('group') ,inoutVars);
      const varsGroupList = Object.keys(inoutVarsGroups).map(title => {
        const dataGroup = groupBy(prop('category'), inoutVarsGroups[title]);
        const dataGroupList = Object.keys(dataGroup).map(group => ({
          category: group,
          list: dataGroup[group],
        }));
        return {
          title,
          dataSource: dataGroupList
        }
      });
      console.log(varsGroupList);
      this.selectedTab = varsGroupList[0] ? varsGroupList[0].title : '';
      this.$set(this, 'varsGroupList', varsGroupList);
      // this.$refs.inoutVarsTable.load(nodeCopy);
    },
    // 表格行拖拽开始
    tableRowDragStart (e) {
      console.log('tableRowDragStart', e);
      this.attrCloned = true;
    },
    // 表格行拖拽结束
    tableRowDragEnd (e) {
      console.log('tableRowDragEnd', e);
      this.attrCloned = false;
      const name = e.item.childNodes[1].textContent;
      const parentNode = e.item.parentNode;
      let itemIndex = -1;
      parentNode.childNodes.forEach((el, i) => {
        if (el === e.item) {
          itemIndex = i
        }
      });
      // 如果拖拽到其他地方
      if (e.to !== e.from) {
        e.item.remove();
        if (e.to.childElementCount === 0) {
          // e.to._added = true;
          const len = this.testLayout.length + 1;
          // 生成可用于追加的元素配置
          const appendBoardConfig = {
            x: (len - 1) % 2 * 3, 
            y: Math.floor((len - 0.0000001) / 2) * 3,
            w: 3,
            h: 3,
            minW: 2,
            i: Date.now(),
            chartConf: {
              type: 'sy',
              confs: []
            }
          };
          this.testLayout.push(appendBoardConfig);
        } 
        const i = e.to.parentNode.parentNode.__vue__.i;
        const boardIndex = this.testLayout.findIndex(item => item.i === i);
        this.testLayout[boardIndex].chartConf.confs.splice(itemIndex, 0, {name, type: 'line'});
      }
      
      // e.item.className = 'grid-square';
    },
    /**
     * 图表面板的项拖拽开始时，创建空面板
     */
    chartBoardItemDragStart (e) {
      console.log('chartBoardItemDragStart', e.from.parentNode.parentNode.__vue__.i, e);
      this.attrCloned = true;
      this.itemDraged = true;
    },
    /**
     * 图表面板的项拖拽结束时，如果内部元素为空，则清理该面板
     */
    chartBoardItemDragEnd (e) {
      console.log('chartBoardItemDragEnd', e.from.parentNode.parentNode.__vue__.i, e);
      this.attrCloned = false;
      this.itemDraged = false;
      // if (e.from === e.to && !e.pullMode && e.newDraggableIndex === undefined) {
      //   e.item.remove();
      //   e.clone.remove();
      // }
      // 如果源头不再包含任何元素了，需要将此元素删除掉
      if (!e.from.childElementCount) {
        console.log('原来的已经空了，移除');
        const i = e.from.parentNode.parentNode.__vue__.i;
        const removeIndex = this.testLayout.findIndex(item => item.i === i);
        this.testLayout.splice(removeIndex, 1);
      }
      // 如果目标元素包含一个子元素，说明之前是空的，此时需要补充一个空的；
      if (e.from !== e.to && e.to.childElementCount === 1) {
        console.log('额外补充一个空的');
        this.testLayout.push({
          w: 3, 
          h: 3, 
          i: Date.now(),
          chartConf: {
            type: 'sy',
            confs: []
          }});
      }
      // 重新计算位置
      const conf = JSON.parse(e.item.childNodes[0].textContent);
      const parentNode = e.item.parentNode;
      let itemIndex = -1;
      parentNode.childNodes.forEach((el, i) => {
        if (el === e.item) {
          itemIndex = i
        }
      });
      e.item.remove();
      const i = e.to.parentNode.parentNode.__vue__.i;
      const boardIndex = this.testLayout.findIndex(item => item.i === i);
      this.testLayout[boardIndex].chartConf.confs.splice(itemIndex, 0, conf);
      const len = this.testLayout.length;
      this.testLayout.forEach((item, index) => {
        item.x = index % 2 * 3;
        item.y = Math.floor((index + 1 - 0.0000001) / 2) * 3;
        console.log(item);
      });
    },
    configItem (e) {
      console.log('config item', e);
    },
    changeYaxisType (e, chartConf) {
      console.log(e.target.value);
      chartConf.type = e.target.value;
      if (e.target.value === 'my') {
        chartConf.confs.forEach(conf => {
          conf.type = 'line';
        })
      }
    },
    changeChartType (e, conf) {
      console.log(e.target.value);
      conf.type = e.target.value;
    },
    updateDataSource (value, record) {
      console.log(value, record);
      record.value = value;
      // const dataSource = this.dataGroupList.reduce(function (arr, item) {
      //   return arr.concat(item.list);
      // }, []);
      console.log(this.varsGroupList);
    },
    showSimChart () {
      const vm = this;
      this.simStatus = 'start';
      const containers = this.$refs.chartContainer || [];
      const keys = Object.keys(cstr);
      const kk = 10;
      console.log(Math.pow(2, kk) * 201 * containers.length, '条数据测试');
      // TODO: 通过socket获取数据，动态渲染图表
      this.getWsData({data: 10, callback: function (data) {
        console.log('获取到websocket数据',data);
      }});
      const charts = containers.map((c, i) => {
        const index = i % 5;
        c.style.background = 'none';
        const chart = Echarts.init(c);
        let data = cstr[keys[index]].map((item, i) => [i, item]);
        // 200 ^ 10
        for(var k = 0; k < kk; k++) {
          data.push(...data);
        }
        const option = {
          color: ['#60acfc','#32d3eb', '#5bc49f', '#feb64d', '#ff7c7c','#9287e7'],
          grid: {
            top: 8,
            bottom: 28,
            left: 48,
            right: 20
          },
          tooltip: {
            axisPointer : {
              show : true,
              type : 'cross'
            }
          },
          xAxis: {
            type: 'value',
            show: true,
          },
          yAxis: {
            // min: 2000,
            // max: 3000,
            splitNumber: 4
          },
          series: [{
            type: 'line',
            data: data,
            symbolSize: 1,
          }]
        };
        chart.setOption(option);

        setInterval(function () {
          if (vm.simStatus === 'start'){
            const first = data.shift();
            data.push(first);
            let newdata = data.map((item, i) => [i, item[1]]);
            chart.setOption({
              series: [{
                data: newdata
              }]
            });
          }
          
        }, 1000);
        return chart;
      });
      Echarts.connect(charts);

    }
  }
};
const outColumns = [
  { title: '分类', dataIndex: 'category', key: 'category' },
];

const innerColumns = [{
  title: '#',
  dataIndex: 'serial',
  scopedSlots: { customRender: 'serial' },
  width: 24,
},{
  title: '变量名',
  dataIndex: 'name',
  scopedSlots: { customRender: 'name' },
  width: 100,
}, {
  title: '中文释义',
  dataIndex: 'desc',
  scopedSlots: { customRender: 'desc' },
  width: 160,
}, {
  title: '单位',
  dataIndex: 'unit',
  scopedSlots: { customRender: 'unit' },
  width: 80,
}, {
  title: '值',
  dataIndex: 'value',
  scopedSlots: { customRender: 'value' },
  width: 80,
},{
  title: '',
  slots: { title: 'drag' },
  scopedSlots: { customRender: 'drag' },
  width: 40
}];
const cstr = {
  so:[2,2.6244435,1.9236022,1.924385,1.9321845,1.9060545,1.8776356,1.836746,1.9503956,1.9422028,2.0147781,1.9926267,2.0263247,1.954637,2.012823,2.0477676,2.060637,1.9935967,1.9561955,1.9543189,1.9818257,2.0504823,2.0378954,2.0539777,2.049572,2.0262992,1.9869112,1.9530159,2.001703,1.9551077,1.995833,1.8986511,1.9269595,1.9488604,1.9862642,1.9687097,1.9702841,1.9689918,1.9936148,2.0776896,2.0819438,2.0018473,2.1313765,1.9736195,1.9962362,1.998888,1.974586,1.9950991,2.0537584,2.1476836,2.0426958,2.029438,1.9131825,1.9275982,1.9473256,1.980578,1.96273,1.9644911,1.9680278,1.9941173,2.0656283,2.0626032,2.0332487,1.9837871,1.9970745,1.9951344,1.9723164,1.9943608,1.9967847,2.0795934,2.0095508,2.0252075,1.9380993,1.971623,1.9883004,1.9764982,1.9180167,1.9147112,1.9268626,1.9626819,2.0326283,2.0365653,2.202223,2.074839,2.0078292,2.012311,1.9344214,1.9462802,1.9770007,2.044783,2.0396402,2.0844843,2.0350933,2.0382645,2.0357635,2.0011148,1.9615084,1.9037917,1.9268352,1.9426204,1.9902948,2.1243439,1.9961683,2.0115814,2.011181,2.0341876,1.949417,1.9518772,1.9714776,2.0410712,2.0237122,2.0002341,2.0366566,2.0280828,2.0424807,1.9850498,1.946985,1.9876084,2.0120218,2.0517602,2.0186872,2.0990686,2.0354147,2.0210712,1.9732066,1.9850848,1.9310058,1.9444585,1.9693849,2.0055366,1.9761285,1.9921163,1.9351274,1.989554,2.041252,2.0330603,2.000982,1.9633054,1.9957061,1.9762691,1.985667,2.1527653,2.0234349,2.032792,1.998755,1.9918141,1.9377326,1.9632072,1.9738538,2.0322292,2.0095444,1.9945167,2.0232842,2.0002413,2.033975,1.9922128,1.9530206,1.996129,2.022434,2.0619543,2.0299416,2.0312588,2.009085,1.9496715,1.9639813,1.9845064,1.9280589,1.9214346,1.9159992,1.9496853,2.0317912,2.027133,1.9609392,2.013861,2.0278354,2.0581484,2.039648,1.983959,1.9652851,1.9799379,1.9913119,2.2273898,2.0745153,1.9966582,2.0147548,1.9912606,1.891499,1.9035126,1.9335105,1.9760239,2.0422504,2.0278065,1.9691736,2.0185082,2.0242062,2.0192094,1.9812778,1.9616611,1.975557,2.004365,2.010378],
  snh:[2,0.14649212,0.2756235,0.4823011,0.67398643,0.82770544,0.8259144,0.7932157,0.6720967,0.69755524,0.6381467,0.6674572,0.6395332,0.73820525,0.7192745,0.66766024,0.6090209,0.64464736,0.70489573,0.763943,0.78652215,0.70458174,0.69801563,0.6718491,0.65142924,0.6576198,0.671432,0.7224536,0.6699666,0.7252349,0.71157855,0.88928515,0.98702085,1.0528227,1.0770309,1.196966,1.2947054,1.3773496,1.3853872,1.1826109,1.0419937,1.087266,0.8149102,0.92735165,0.952584,0.9743612,1.0392778,1.034253,0.93655616,0.6870657,0.6536975,0.6061483,0.7179488,0.77344406,0.81266826,0.82544285,0.90646076,0.9710952,1.0278881,1.0365078,0.90515965,0.819147,0.81390774,0.91525066,0.9644402,1.0115038,1.0994452,1.0934064,1.0757374,0.88441473,0.87243545,0.8205702,0.95140517,0.9749617,0.9615755,0.98780733,1.1947138,1.4319266,1.6566385,1.7650448,1.6281254,1.5492041,1.0523762,1.0066373,1.0578083,1.0495021,1.2232137,1.3237714,1.3395673,1.201985,1.1309589,0.9698378,0.9253415,0.84558666,0.77566785,0.7782714,0.82339424,0.9763785,1.091935,1.2137146,1.2266779,0.93662995,1.0089817,1.005007,1.0135473,0.9657106,1.1063391,1.2078881,1.2696052,1.1542529,1.1208822,1.141529,1.0516597,0.9957462,0.90833926,0.97149616,1.1289107,1.1591442,1.1197505,0.9862253,0.9378863,0.73690015,0.69085056,0.6609037,0.7171378,0.76511973,0.9338607,1.0644488,1.139331,1.1105227,1.1687006,1.1712296,1.3660233,1.3877388,1.2713686,1.1957064,1.1871887,1.2859347,1.2872043,1.3552414,1.378817,0.9782666,0.9845853,0.9373424,0.9667658,1.009268,1.2006555,1.2744498,1.3009368,1.1704935,1.134204,1.1556008,1.0979115,1.1016258,1.0130749,1.0456328,1.1742827,1.170572,1.1107382,0.96434927,0.8980123,0.83346343,0.8137004,0.9066445,0.9657522,0.99409103,1.1902527,1.4290632,1.6946161,1.8169365,1.6395037,1.5548223,1.7507561,1.6989073,1.6096776,1.4690163,1.4420148,1.5820203,1.7365016,1.7902694,1.8054683,1.0979741,0.9889641,1.0292135,0.99700636,1.0109673,1.2745882,1.5155027,1.7036421,1.7558835,1.5769207,1.5143162,1.6611571,1.5664482,1.477548,1.41635,1.5062459,1.6489707,1.7174991,1.673511,1.6299531],
  sno:[20,19.042776,15.997042,12.717303,10.079507,8.210327,7.2707577,7.017218,7.419834,7.9469204,8.543857,8.961273,9.309976,9.502105,9.712517,9.818484,9.806911,9.669284,9.618151,9.69233,9.814064,9.954137,9.919171,9.848063,9.723731,9.474439,9.189908,8.978366,8.945588,8.903383,8.979171,9.045948,9.419137,9.926271,10.498597,10.932063,11.331705,11.723558,12.065837,12.39929,12.475516,12.326503,12.574107,12.534594,12.6446085,12.72916,12.651399,12.482161,12.121313,11.560702,10.712428,10.01255,9.366176,9.11565,9.129764,9.324116,9.477681,9.618599,9.753647,9.867407,9.988545,9.944994,9.81344,9.747502,9.907531,10.112191,10.231446,10.285805,10.170157,10.0779295,9.720711,9.478797,9.167968,9.116827,9.143824,9.264959,9.466256,9.85199,10.355912,10.861529,11.428869,11.8578005,12.50497,12.581549,12.500881,12.495445,12.364499,12.368311,12.43514,12.55856,12.476456,12.298065,11.663255,11.023308,10.477961,10.004807,9.686989,9.573105,9.741614,9.969404,10.224738,10.653165,10.688757,10.757432,10.757665,10.720135,10.494508,10.440573,10.553813,10.812946,10.882444,10.800419,10.687092,10.463506,10.34237,10.276248,10.258952,10.3516865,10.4007225,10.424128,10.225504,10.104541,9.719547,9.31661,8.940865,8.8368,8.830619,9.052146,9.407984,9.837673,10.167856,10.505249,10.643587,10.901702,11.170451,11.217177,11.159217,11.081936,11.098189,11.054535,11.079879,11.43282,11.231492,11.016403,10.773102,10.694527,10.595414,10.645002,10.735085,10.899932,10.854803,10.677712,10.54128,10.400071,10.410849,10.376287,10.278944,10.228238,10.137442,10.046546,9.749836,9.411924,9.061814,8.7614975,8.69754,8.734577,8.697961,8.907212,9.251696,9.6484585,10.152409,10.436903,10.423035,10.550267,10.585877,10.629963,10.642564,10.677329,10.821727,11.029974,11.185285,11.800719,11.618868,11.273153,11.006224,10.762605,10.52203,10.5803585,10.766664,11.030499,11.435973,11.683517,11.637635,11.671765,11.596922,11.549334,11.555577,11.592007,11.649797,11.708005,11.683658],
  mlss:[2991.1892,2986.952,2969.8164,2958.0315,2950.0574,2944.828,2941.6118,2940.2886,2940.37,2942.1729,2944.1848,2946.8928,2948.5964,2950.7996,2952.7324,2954.823,2956.5469,2958.239,2959.7031,2961.5757,2963.671,2965.6099,2967.2563,2966.4556,2964.4487,2962.2073,2960.7148,2960.8857,2961.978,2964.3518,2965.8364,2966.9702,2967.4907,2969.1455,2971.0913,2972.565,2972.941,2973.5042,2974.8584,2976.457,2978.4368,2980.063,2979.9617,2981.1802,2981.1558,2980.7998,2981.207,2982.51,2984.7046,2987.0488,2990.0718,2992.005,2994.3914,2996.5537,2998.9546,3001.001,3002.9917,3004.709,3006.8591,3009.2314,3011.4646,3013.9126,3015.2114,3013.9634,3011.2822,3008.5552,3006.0435,3004.4087,3004.4028,3005.364,3007.5264,3008.7314,3009.4573,3009.52,3010.76,3012.3086,3013.3438,3013.2751,3013.4482,3014.4705,3015.871,3017.7449,3018.3262,3019.475,3019.5361,3018.7126,3018.3008,3018.4182,3019.4424,3020.7773,3022.15,3023.2444,3025.065,3026.3398,3027.5474,3028.5664,3029.4106,3030.7502,3032.0076,3033.3865,3034.4187,3034.9177,3036.751,3037.5918,3037.884,3037.6157,3037.5251,3037.1082,3036.7615,3036.7725,3037.4585,3038.0283,3038.4033,3039.0571,3039.2615,3038.9727,3037.7837,3035.8413,3034.6729,3034.5469,3035.9402,3037.0889,3039.0117,3040.1602,3040.19,3038.0981,3035.1875,3031.6667,3028.6257,3026.5747,3025.8447,3025.4917,3025.539,3024.4902,3023.7593,3023.9966,3024.5493,3025.3586,3025.582,3025.8638,3026.292,3026.586,3028.7068,3029.479,3029.1162,3027.5728,3025.524,3023.2002,3022.465,3022.9473,3024.6426,3025.9878,3026.1387,3026.4834,3026.8154,3027.4866,3027.9363,3027.809,3027.715,3028.1646,3029.8657,3031.4263,3032.4585,3033.258,3033.3972,3033.5835,3033.2266,3031.4683,3030.8862,3032.0073,3033.9993,3036.7969,3039.055,3039.7756,3040.8647,3041.2356,3039.8052,3037.3818,3034.894,3033.3372,3032.42,3031.8203,3033.8662,3035.06,3034.9258,3034.5615,3034.5796,3034.662,3034.9377,3035.3242,3036.0205,3037.3862,3038.5889,3039.1829,3040.228,3041.2512,3042.032,3042.6335,3043.3027,3044.0654,3045.0269],
  qair:[13359.433,9232.457,9768.177,10365.878,10893.295,11535.336,12415.469,13795.709,14402.962,14877.097,14569.391,14703.142,14365.543,14938.278,14889.121,14483.528,13894.579,13976.426,14329.999,14771.511,14990.993,14491.671,14284.208,13908.274,13634.375,13640.083,13676.779,14102.605,13816.998,14194.183,14128.054,14976.015,15525.46,15836.523,15920.961,16274.354,16560.465,16853.184,16984.174,16402.363,15685.957,15610.853,14202.849,14357.954,14445.74,14534.808,14886.594,15039.071,14938.431,13612.878,13189.005,12768.999,13478.269,13999.448,14321.218,14419.3955,14829.022,15169.397,15493.3545,15618.457,15050.703,14464.544,14178.4,14349.384,14404.881,14507.616,14875.075,15031.265,15137.16,14438.435,14283.861,14007.679,14564.176,14800.416,14804.468,14811.928,15472.173,16172.046,16805.61,17180.291,16908.31,16566.838,14839.774,14100.34,14062.877,13968.183,14543.388,15039.927,15259.93,14947.477,14637.969,14083.007,13936.256,13613.332,13206.295,13153.872,13318.212,14037.559,14641.397,15213.555,15362.04,14165.059,14163.408,14106.501,14112.272,13881.82,14365.846,14790.88,15036.398,14704.247,14500.076,14585.208,14341.485,14103.431,13568.096,13613.789,14174.582,14391.081,14327.077,13861.818,13668.905,12705.238,12367.582,12185.259,12438.292,12566.19,13243.845,13746.361,14017.183,13879.821,14025.506,14046.776,14661.343,14827.223,14529.407,14263.603,14155.859,14479.896,14569.418,14771.579,14892.809,13573.8125,13345.031,13114.785,13101.839,13150.928,13798.853,14147.085,14353.503,14073.764,13968.462,14119.257,13929.998,13883.2705,13496.711,13502.697,14000.914,14164.174,14022.417,13491.098,13211.885,12963.155,12827.885,13225.377,13521.335,13700.108,14341.556,14958.609,15650.807,16093.62,15851.365,15582.071,15951.213,15932.295,15737.016,15314.164,14955.119,15032.539,15309.239,15488.765,15602.727,13869.937,13006.636,13050.267,12964.664,12949.749,13775.481,14606.104,15230.185,15483.427,15121.166,14856.039,15161.158,15095.971,14912.731,14656.776,14745.4795,15072.056,15338.286,15353.017,15309.718],
  qirs:[3579.347,3582.5427,3747.1287,3755.1184,3835.0144,3835.0144,4218.516,4218.516,4346.3496,4010.786,4074.703,3914.9106,4234.495,4196.145,4074.703,3918.1064,4074.703,4202.5366,4298.412,4336.762,4074.703,4121.842,4130.6304,4218.516,4499.7505,4640.3677,4780.985,4411.8647,4482.1733,4306.402,4657.945,4615.7593,4482.1733,4309.917,4482.1733,4622.7905,4728.2534,4770.4385,4482.1733,4323.979,4473.385,3672.1062,3840.807,3848.9963,3930.89,4192.949,4323.979,4455.0083,4111.0557,4176.5703,4012.7834,4340.3574,4301.049,4176.5703,4016.059,4176.5703,4307.6,4405.8726,4445.181,4176.5703,4029.162,4030.3606,4215.52,4224.5083,4314.391,4602.0176,4745.8306,4889.6436,4512.1343,4584.0405,4404.2744,4763.807,4720.663,4584.0405,4407.8696,4584.0405,4727.854,4835.7134,4878.8574,4584.0405,4422.251,3543.5535,3546.7173,3717.5671,3717.5671,4049.7754,4176.3306,4176.3306,3970.678,3970.678,3875.7615,4192.1504,4192.1504,4033.9558,4033.9558,4033.9558,4160.511,4160.511,4293.3945,4293.3945,3618.3682,3784.6,3784.6,3873.3645,3873.3645,4260.701,4389.813,4389.813,4115.4497,4115.4497,4276.8403,4238.1064,4238.1064,3957.2876,3957.2876,4244.562,4341.396,4341.396,4115.4497,4115.4497,3633.037,3636.2808,3636.2808,3811.445,3811.445,4152.0425,4281.7935,4281.7935,4070.9478,4070.9478,3973.6343,4298.0127,4298.0127,4135.823,4135.823,4135.823,4265.5747,4265.5747,4401.8135,4401.8135,3582.5427,3747.1287,3747.1287,3835.0144,3835.0144,4218.516,4346.3496,4346.3496,4074.703,4074.703,4234.495,4196.145,4196.145,3918.1064,3918.1064,4202.5366,4298.412,4298.412,4074.703,4074.703,4026.7651,4030.3606,4215.52,4215.52,4224.5083,4602.0176,4745.8306,4889.6436,4889.6436,4512.1343,4404.2744,4763.807,4720.663,4720.663,4584.0405,4584.0405,4727.854,4835.7134,4835.7134,4878.8574,3695.6755,3698.9753,3868.9104,3868.9104,3877.1597,4223.6294,4355.6177,4487.606,4487.606,4141.1367,4042.1453,4372.116,4332.5195,4332.5195,4207.131,4207.131,4339.119,4438.1104,4438.1104,4477.707,4058.6438]
};
</script>

<style>
/* .col {
  padding-right: 0;
  margin-right: 15px;
} */
.grid-square {
  width: 46%;
  float: left;
  height: 100px;
  display: block;
  background-color: #fff;
  border: solid 1px rgb(0,0,0,0.2);
  padding: 10px;
  margin: 12px;
}

</style>

<style lang="less" scoped>
  .inner-table-pane {
    /deep/ .ant-collapse-header {
      background-color: #fafafa;
      line-height: 12px;
    }
    /deep/ .ant-collapse-content-box {
      padding: 0px;
    }
    /deep/ .ant-collapse-content {
      .ant-collapse-content-box {
        padding-top: 0px;
      }
    }
    /deep/ .ant-table-small {
      border-radius: 0px;
      border-bottom: none;
      border-left: none;
      .ant-table-content {
        border-right: none;
      }
    }
  }
  .sim-container {
    height: 100%;
    background: transparent;
    /deep/ .ant-tabs-bar {
      margin: 0px;
    }
  }
  // 回收站容器
  .item-trash-container {
    display: table;
    height: 24px;
    width: calc(100% - 20px);
    margin: -8px 10px -4px;
    .item-trash-content {
      border: 1px solid #ffa39e;
      border-radius: 2px;
      background: #fff1f0;
      color: #f5222d;
      line-height: 1.5;
      display: table-cell; 
      vertical-align: 
      middle; text-align: center;
    }
    /deep/ tr {
      display: none;
    }
    /deep/ .chartBoard-content-item {
      display: none;
    }
  }
  .item-extra {
    position: absolute;
    right: 8px;
    top: 8px;
      cursor: pointer!important;
  }
  .block {
    background: #FFF;
  }
  /deep/ .ant-table-body {
    margin: 0px;
    /deep/ .ant-table-body {
      margin: 0px;
      table {
        width: 100%; /*必须设置，否则还是会拉长单元格*/
        table-layout: fixed;/*只有定义表格的算法为fixed,th才有效果*/
        word-wrap:break-all;
      }
      th > div, td {
        overflow:hidden;/*超出长度的文字隐藏*/
        text-overflow:ellipsis;/*文字隐藏以后添加省略号*/
        white-space:nowrap;/*强制不换行*/
        word-break:keep-all;/*文字不换行*/
      }
    }
  }
// 图表面板
.chartBoard {
  border: 1px solid #91d5ff;
  border-radius: 2px;
  background-color: #e6f7ff;
  padding-top: 32px;
  height: 100%; 
  width: 100%; 
  
  /deep/ tr {
    display: block;
    font-family: "Chinese Quote", -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Helvetica Neue", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
    font-size: 14px;
    font-variant: tabular-nums;
    box-sizing: border-box;
    margin: 4px 8px;
    padding: 0 12px;
    list-style: none;
    line-height: 20px;
    height: 22px;
    border-radius: 4px;
    border: 1px solid #d9d9d9;
    font-size: 12px;
    transition: all 0.3s cubic-bezier(0.215, 0.61, 0.355, 1);
    opacity: 1;
    margin-right: 8px;
    white-space: nowrap;
    color: #fff;
    background-color: rgb(16, 142, 233);
    border-color: transparent;
    &::before{
      text-align: center;
      content: '添加到此'
    }
  }
  /deep/ td {
    font-size: 14px;
    display: none;
  }
  /deep/ .anticon-drag {
    color: #fff;
    margin-left: 8px;
  }
  // /deep/ td:nth-child(1) {
  //   display: none;
  // }
  // /deep/ td:nth-child(4) {
  //   display: none;
  // }
  .chartBoard-content {
    height: calc(100% - 12px);
    width: calc(100% - 4px);
    margin-top: 4px;
    margin-left: 4px;
    overflow-y: overlay;
    .chartBoard-content-item {
      height: 26px; 
      line-height: 22px;
      width: calc(100% - 24px);
      margin: 4px 4px;
      padding: 0px 8px;
      border: 1px solid transparent;
      border-radius: 2px;
      &:hover {
        background-color: #91d5ff;
        color: #FFF;
      }
    }
  }
  // /deep/ td:nth-child(5) {
  //   display: none;
  // }
}
// 待放区域
.wait-drop-area {
  /deep/ .chartBoard {
    background: #f6ffed;
    border-color: #b7eb8f;
    display: table;
    &:before {
      display: table-cell;
      vertical-align: middle; 
      text-align: center;
      font-weight:bold;
      color: #52c41a;
    }
  }
}
.ant-tabs {
  /deep/ .ant-tabs-content {
    height: 100%;
  }
}
</style>


