import stdnodeServer from '../../ModelManagement/api/stdnode';
import simulationProjectServer  from '../api/simulationProject';
import nodeServer from '../api/nodes';
import graphServer from '../api/graph';
import socket from '@lib/socket.js';

export default {
  getAllProject: () => simulationProjectServer.getAllProject(),
  getAllStdnode: () => stdnodeServer.getAllStdnode(),
  getStdnodes: () => stdnodeServer.getStdnodes(),
  getStdnode: (store, id) => stdnodeServer.getStdnode(id),
  addNode: (store, nodes) =>  nodeServer.addNode(nodes),
  addNodeRS: (store, nodeRSs) => nodeServer.addNodeRS(nodeRSs),
  getNodes: (store, projectID) => nodeServer.getNodes(projectID),
  getNode: (store, id) => nodeServer.getNode(id),
  removeAllNode: (store, projectID) => nodeServer.removeAllNode(projectID),
  saveGraph: (store, graph) => graphServer.save(graph),
  loadGraph: (store, projectID) =>  graphServer.load(projectID),
  // 获取websocket数据
  getWsData: (store, {data, callback}) => {
    socket.connect(() => {}, client => {
      const subscription = client.subscribe('/get_ws_data', res => {
        if (res.body) {
          callback(res.body);
        } else {
          subscription.unsubscribe();
        }
      }, data);
    });
  },
  sendWsMessage: (store, message) => {
    socket.connect(() => {}, client => {
      client.send('/send_ws_message', {}, message);
    })
  }
};