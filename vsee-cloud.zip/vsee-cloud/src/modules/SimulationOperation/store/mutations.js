export default {
  setData (state, data) {
    state.users = data;
  }
};