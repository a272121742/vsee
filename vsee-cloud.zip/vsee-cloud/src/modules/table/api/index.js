import $ from '@/lib/ajax';

export default {
  loadData (parameter) {
    return $.get('/api/loaddata', parameter);
  },
  getData (id) {
    return $.get('/api/getdata', id);
  },
  updateData (data) {
    return $.patch('/api/updateData', data);
  },
  newData (data) {
    return $.post('/api/newData', data);
  }
};