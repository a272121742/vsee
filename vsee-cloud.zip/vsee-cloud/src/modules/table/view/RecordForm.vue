<template>
  <div>
    <a-form
      :form="form"
      @submit="handleSubmit"
    >
      <a-form-item
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
        label="规则编号"
        has-feedback
      >
        <a-input
          placeholder="规则编号"
          v-decorator="[
            'no',
            {rules: [{ required: false, message: '请输入规则编号' }]}
          ]"
          :disabled="true"
        ></a-input>
      </a-form-item>

      <a-form-item
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
        label="服务调用次数"
        has-feedback
      >
        <a-input-number
          :min="1"
          style="width: 100%"
          v-decorator="['callNo', {rules: [{ required: true }]}]"
        />
      </a-form-item>

      <a-form-item
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
        label="状态"
        has-feedback
      >
        <a-select v-decorator="['status', {rules: [{ required: true, message: '请选择状态' }], initialValue: '1'}]">
          <a-select-option value="1">
            1
          </a-select-option>
          <a-select-option value="2">
            2
          </a-select-option>
          <a-select-option value="3">
            3
          </a-select-option>
        </a-select>
      </a-form-item>

      <a-form-item
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
        label="描述"
        has-feedback
        help="请填写一段描述"
      >
        <a-textarea
          :rows="5"
          placeholder="..."
          v-decorator="['description', {rules: [{ required: true }]}]"
        />
      </a-form-item>

      <a-form-item
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
        label="更新时间"
        has-feedback
      >
        <a-date-picker
          style="width: 100%"
          show-time
          format="YYYY-MM-DD HH:mm:ss"
          placeholder="Select Time"
          v-decorator="['updatedAt', {rules: [{ type: 'object', required: true, message: '请选择时间' }]}]"
        />
      </a-form-item>

      <a-form-item
        v-bind="buttonCol"
      >
        <a-row>
          <a-col span="6">
            <a-button
              type="primary"
              html-type="submit"
              :loading="submitLoading"
            >
              提交
            </a-button>
          </a-col>
          <a-col span="10">
            <a-button @click="handleGoBack">
              返回
            </a-button>
          </a-col>
          <a-col span="8"></a-col>
        </a-row>
      </a-form-item>
    </a-form>
  </div>
</template>

<script>
import moment from 'moment';
import util from '@lib/util';

export default {
  name: 'RecordForm',
  props: {
    // 回退事件
    handleGoBack: {
      type: Function,
      default () {},
    },
    record: {
      type: Object,
      default: (record = {}) => {
        record.updatedAt = record.updatedAt && moment(record.updatedAt);
        return record;
      }
    }
  },
  data () {
    return {
      submitLoading: false,
      labelCol: {
        xs: { span: 24 },
        sm: { span: 5 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 }
      },
      buttonCol: {
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 12, offset: 5 }
        }
      },
    }
  },
  watch: {
    'record' (record) {
      this.form.setFieldsValue({
        no: record.no,
        callNo: record.callNo,
        status: record.status,
        description: record.description,
        updatedAt: record.updatedAt && moment(record.updatedAt)
      });
    }
  },
  created () {
    this.$set(this.record, 'updatedAt', (this.record.updatedAt && moment(this.record.updatedAt)));
    this.form = this.$form.createForm(this, {
      // 初始化数据
      mapPropsToFields: () => {
        return util.createFormFieldsMapFrom(this, ['no', 'callNo', 'status', 'description', 'updatedAt'],  'record');
        // return {
        //   no: this.$form.createFormField({
        //     value: this.record.no,
        //   }),
        //   callNo: this.$form.createFormField({
        //     value: this.record.callNo
        //   }),
        //   status: this.$form.createFormField({
        //     value: this.record.status
        //   }),
        //   description: this.$form.createFormField({
        //     value: this.record.description
        //   }),
        //   updatedAt: this.$form.createFormField({
        //     value: this.record.updatedAt && moment(this.record.updatedAt)
        //   })
        // };
      },
    });
  },
  methods: {
    handleSubmit (e) {
      e.preventDefault();
      const { form: { validateFields } } = this
      validateFields((err, values) => {
        if (!err) {
          this.submitLoading = true;
          this.$store.dispatch('table/setData', {...this.record, ...values}).then(res => {
            if (res.result.id) {
              this.submitLoading = false;
              this.$router.push({name: 'RecordList'})
            }
          });
        }
        return false;
      })
    },
  }
}
</script>