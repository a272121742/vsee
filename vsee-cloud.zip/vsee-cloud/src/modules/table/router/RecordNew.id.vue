<template>
  <keep-alive>
    <RecordForm :handle-go-back="handleGoBack"></RecordForm>
  </keep-alive>
</template>

<script>

export default {
  components: {
    RecordForm: () => import('../view/RecordForm')
  },
  props: {
    id: {
      type: String,
      default: ''
    }
  },
  methods: {
    handleGoBack () {
      console.log('back');
      this.$router.go(-1);
    },
  }
}
</script>
