<template>
  <keep-alive>
    <RecordForm 
      :record="record"
      :handle-go-back="handleGoBack"
    >
    </RecordForm>
  </keep-alive>
</template>

<script>

export default {
  name: 'RecordEdit',
  components: {
    RecordForm: () => import('../view/RecordForm')
  },
  props: {
    id: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      record: {}
    }
  },
  created () {
    this.$store.dispatch('table/getData', this.id).then(res => {
      this.$set(this, 'record', res.result);
    });
  },
  methods: {
    handleGoBack () {
      this.$router.go(-1);
    },
  },
}
</script>
