import api from '../api';

export default {
  /**
   * 测试： 加载列表数据
   */
  loadData: ({ commit }, parameter) => {
    return api.loadData(parameter);
  },
  /**
   * 测试： 获取单个数据
   */
  getData: (store, id) => {
    return api.getData(id);
  },
  setData: (store, data) => {
    return data.id ? api.updateData(data) : api.newData(data);
  }
};