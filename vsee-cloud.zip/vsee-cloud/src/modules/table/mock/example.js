import Mock from '@/lib/mock';
import cdb from '@/lib/cdb';
import moment from 'moment';

const mockData = Mock.mock({
  'datas|105': [{
    'key|+1': 0,
    'no|+1': 1,
    editable: false,
    description: '这是一段描述',
    'callNo|0-999': 0,
    'status|1-3': 0,
    updatedAt: '@datetime',
    action: '详情'
  }]
});

const Data = cdb.link('data', mockData.datas);

Mock.get('/api/loaddata', (parameter) => {
  const datas = Data.find() || [];
  const pageNo = parameter.pageNo;
  const pageSize = parameter.pageSize;
  const totalCount = datas.length;
  const totalPage = totalCount % parameter.pageSize + 1;
  const start = pageSize * (pageNo - 1);
  const end = start + pageSize;
  return Mock.restpl({
    datas: datas.slice(start, end),
    pageNo,
    pageSize,
    totalCount,
    totalPage
  });
}, {timeout: 0});

Mock.get('/api/getdata', id => {
  return Mock.restpl({
    result: Data.findById(id),
    token: sessionStorage.getItem('login_token')
  });
});

Mock.patch('/api/updateData', data => {
  return Mock.restpl({
    result: Data.update(data.id, data),
    token: sessionStorage.getItem('login_token')
  });
});

Mock.post('/api/newData', data => {
  const insertData = Data.insert(data);
  insertData.no = insertData.id;
  insertData.key = insertData.id;
  return Mock.restpl({
    result: Data.update(insertData.id, insertData),
    token: sessionStorage.getItem('login_token')
  });
})