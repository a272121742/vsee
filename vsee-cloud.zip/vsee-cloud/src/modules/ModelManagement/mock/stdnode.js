import Mock from '@/lib/mock';
import cdb from '@/lib/cdb';
import { list2treeGroup } from '@lib/util';

// 模拟所有的stdnodes
const stdnodes = Mock.mock({
  'data|5': [{
    'id|+1': 1,
    'nodeID': /\w{2}-\d{3}/,
    name: /[A-Z]{4,6}/,
    codestr: 'print("斐波那契数列:")',
    'portNum': 3,
    desc: '@csentence',
    'type|1': ['污水流', '悬浮介质处理'],
    iconpath: null
  }]
}).data;
stdnodes.map(node => {
  node.inoutVars = '{"Length":{"group":"构筑物参数","category":"","type":0,"defvalue":100,"unit":"m","desc":"反应池长度","saved":0},"Width":{"group":"构筑物参数","category":"","type":0,"defvalue":50,"unit":"m","desc":"反应池宽度","saved":0},"Level":{"group":"构筑物参数","category":"","type":0,"defvalue":5,"unit":"m","desc":"有效深度","saved":0},"Volume":{"group":"构筑物参数","category":"","type":0,"defvalue":5000,"unit":"m","desc":"反应池容积","saved":0},"icv":{"group":"化学计量学系数","category":"有机物","type":0,"defvalue":1.48,"unit":"","desc":"XCOD/VSS的比率","saved":0},"fbod":{"group":"化学计量学系数","category":"有机物","type":0,"defvalue":0.66,"unit":"","desc":"BOD5/最终BOD比率","saved":0},"yh":{"group":"化学计量学系数","category":"异养菌","type":0,"defvalue":0.625,"unit":"g(COD)/g(COD)","desc":"异养菌产率系数","saved":0},"yaut":{"group":"化学计量学系数","category":"自养菌","type":0,"defvalue":0.24,"unit":"g(COD)/g(N)","desc":"自养菌产率系数","saved":0},"ypao":{"group":"化学计量学系数","category":"聚磷菌","type":0,"defvalue":0.625,"unit":"g(COD)/g(COD)","desc":"聚磷菌产率系数（生物量/PHA）","saved":0},"ypo4":{"group":"化学计量学系数","category":"聚磷菌","type":0,"defvalue":0.4,"unit":"g(P)/g(COD)","desc":"贮存PHA所需要的多磷（PO4的释放）","saved":0},"ypha":{"group":"化学计量学系数","category":"聚磷菌","type":0,"defvalue":0.2,"unit":"g(COD)/g(COD)","desc":"贮存多磷所需的PHA","saved":0},"chooseDOcontrol":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":1,"unit":"","desc":"是否选择溶解氧控制模式","saved":0},"EA":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":27,"unit":"%","desc":"曝气装置氧转移效率","saved":0},"alphaFine":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":0.6,"unit":"","desc":"校正系数alpha","saved":0},"beta":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":0.95,"unit":"","desc":"校正系数beta","saved":0},"aerator_depth":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":4.5,"unit":"m","desc":"曝气头浸没深度","saved":0},"qair_x":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":2000,"unit":"m3/h","desc":"曝气流量（这个向量要在后期重点设计）","saved":0},"so":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgO2/L","desc":"溶解氧","saved":0},"sf":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgCOD/L","desc":"易降解基质","saved":0},"sa":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgCOD/L","desc":"发酵产物","saved":0},"snh":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"氨氮","saved":0},"sno":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"硝态氮","saved":0}}';
  node.portDefine = '{"port1":{"type":"in","name":"进口","vars":"Qin","location":[0,0.5],"order":1},"port2":{"type":"out","name":"溢流口","vars":"Qout","location":[1,0.33],"order":2},"port3":{"type":"out","name":"回流口","vars":"Qpump","location":[1,0.66],"order":3}}';
  node.codestr = '#二层池模块-------------------------------------------------------------\r\n\r\nQout = Qin - Qr - Qw  # 出口3：二沉池出水流量，外排\r\nQu = Qr + Qw\r\n\r\n\r\nVolume = Aset * Depth  # 二沉池容积\r\n\r\nvup = Qout / Aset  # 二沉池向上流量\r\nvdn = Qu / Aset  # 二沉池向下流量\r\n\r\nTotal_Layer = 10  # 二沉池总分层数，默认是10\r\nfeedLayer = 7  # 进料层，默认是第7层\r\nz = Depth / Total_Layer  # 每层高度\r\n\r\n# Takacs沉降动力学参数\r\nvbdn = 274.\r\nvmax = 410.\r\nrh = 0.0004\r\nrp = 0.0025\r\nfns = 0.001\r\nXminmax = 20\r\nXt = 3000\r\n\r\n# 这里要用输出的变量作为下一次的函数输入！！！！！！！！！\r\ns0 = (so, sf, sa, snh, sno, spo, si, salk, snn)\r\n\r\nnumvar = len(s0)\r\nqin = np.array([Qin] * numvar)\r\nqpump = np.array([Qu] * numvar)\r\nqout = np.array([Qout] * numvar)\r\n\r\n# 这里要用输出的变量作为下一次的函数输入！！！！！！！！！\r\nTSS0 = (Layer1TSS, Layer2TSS, Layer3TSS, Layer4TSS, Layer5TSS, Layer6TSS, Layer7TSS,\r\n        Layer8TSS, Layer9TSS, Layer10TSS)\r\n\r\n# 入口, 二沉池进水组分浓度, mg/L, 可接受前端生化池出水\r\n\r\ns_Influent = (soin, sfin, sain, snhin, snoin, spoin, siin, salkin, snnin)\r\nX_Influent = (xiin, xsin, xhin, xpaoin, xppin, xphain, xautin, xmeohin, xmepin, xiiin)\r\n\r\n# TSS = 1/icv * xi + 1/icv * xs + 1/icv * xh + 1/icv * xpao + 3*xpp + 1/icv * xpha + 1/icv * xaut + xmeoh + xmep + xii\r\n\r\n# icv = 2.2  # COD—TSS 转换系数\r\nicv = 1.48  # COD—TSS 转换系数\r\n\r\n# 颗粒性模型组分转化成总悬浮固体\r\nTSSin = 1 / icv * xiin + 1 / icv * xsin + 1 / icv * xhin + 1 / icv * xpaoin + 3*xppin + 1 / icv * xphain + 1 / icv * xautin + xmeohin + xmepin + xiiin\r\n\r\n# 进水中各项颗粒性组分占总悬浮固体的比例\r\nxi_ratio = xiin / TSSin\r\nxs_ratio = xsin / TSSin\r\nxh_ratio = xhin / TSSin\r\nxpao_ratio = xpaoin / TSSin\r\nxpp_ratio = xppin / TSSin\r\nxpha_ratio = xphain / TSSin\r\nxaut_ratio = xautin / TSSin\r\nxmeoh_ratio = xmeohin / TSSin\r\nxmep_ratio = xmepin / TSSin\r\nxii_ratio = xiiin / TSSin\r\n\r\n# 二沉池进水9种溶解性组分，1种悬浮固体\r\ny_Influent = (soin, sfin, sain, snhin, snoin, spoin, siin, salkin, snnin, TSSin)\r\n\r\n\r\n#公共函数定义----------------------------\r\n\r\nvs = np.zeros(Total_Layer)\r\nJ = np.zeros(Total_Layer)\r\nJ_clar = np.zeros(Total_Layer)\r\ndXq = np.zeros(Total_Layer)\r\ndXr = np.zeros(Total_Layer)\r\ndX = np.zeros(Total_Layer)\r\n\r\ndef Sedim(X, t):\r\n\r\n    for Layer in range(1, Total_Layer + 1, 1):  # Layer = 1-10\r\n\r\n        Xmin = min(TSSin * fns, Xminmax)\r\n        vs[Layer - 1] = max(0, min(vbdn, vmax * (\r\n                    math.exp(-rh * (X[Layer - 1] - Xmin)) - math.exp(-rp * (X[Layer - 1] - Xmin)))))\r\n        J[Layer - 1] = vs[Layer - 1] * X[Layer - 1]\r\n        # print(J)\r\n\r\n    for Layer in range(1, feedLayer + 1, 1):  # 进料层以上才需要考虑J_clar\r\n\r\n        if X[Layer] >= Xt:\r\n            J_clar[Layer - 1] = min(J[Layer], J[Layer - 1])\r\n        else:\r\n            J_clar[Layer - 1] = J[Layer - 1]\r\n\r\n    for Layer in range(1, Total_Layer + 1, 1):  # Layer = 1-10\r\n\r\n        if Layer < feedLayer:  # 进料层以上  Layer = 1-6\r\n            dXq[Layer - 1] = vup * (X[Layer] - X[Layer - 1]) / z  # dXq_Layer1 = vup * ( X2 - X1)\r\n        elif Layer == feedLayer:  # 进料层  Layer = 7\r\n            dXq[Layer - 1] = (Qin * TSSin / Aset - (vdn + vup) * X[Layer - 1]) / z\r\n        else:  # 进料层以下, Layer = 8-10\r\n            dXq[Layer - 1] = vdn * (X[Layer - 2] - X[Layer - 1]) / z  # dXq_Layer10 = vup * ( X9 - X10) X[8] - X[9]\r\n\r\n        if Layer == 1:  # 顶层 Layer = 1\r\n            dXr[Layer - 1] = -J_clar[Layer - 1] / z\r\n        elif Layer > 1 and Layer < feedLayer:  # 顶层和进料层之间, Layer = 2-6\r\n            dXr[Layer - 1] = (J_clar[Layer - 2] - J_clar[Layer - 1]) / z\r\n        elif Layer == feedLayer:  # 进料层, Layer = 7\r\n            dXr[Layer - 1] = (J_clar[Layer - 2] - min(J[Layer - 1], J[Layer])) / z\r\n        elif Layer > feedLayer and Layer < Total_Layer:  # 进料层和底层之间 Layer = 8-9\r\n            dXr[Layer - 1] = (min(J[Layer - 2], J[Layer - 1]) - min(J[Layer - 1], J[Layer])) / z\r\n        else:  # 底层 Layer = 10\r\n            dXr[Layer - 1] = min(J[Layer - 2], J[Layer - 1]) / z  # dX10 = min(J9, J10)  dx[9] = min(J[8], J[9])\r\n\r\n        # print(dXr)\r\n\r\n        dX = dXq + dXr\r\n\r\n    return np.array(dX)\r\n\r\ndef Lquid(s, t):\r\n    ds = (qin * s_Influent - qpump * s - qout * s) / Volume\r\n    return np.array(ds)\r\n\r\n#结束----------------------------\r\n\r\n#nn = 2  # 每个小区间分割点数\r\ndtstart = dtn\r\ndtend = dtn + H\r\n#dtspan = np.linspace(dtstart, dtend, nn)\r\ndtspan = [dtstart, dtend]\r\nSoubledt = odeint(Lquid, s0, dtspan)\r\nSouble = Soubledt[len(Soubledt) - 1, :]\r\n\r\nSoliddt = odeint(Sedim, TSS0, dtspan)\r\nSolid = Soliddt[len(Soliddt) - 1, :]\r\n\r\ndtn = dtend\r\n\r\n# 一下是结果输出--------------------------------------------------\r\n\r\n# 溶解性组分\r\nso = Souble[0]\r\nsf = Souble[1]\r\nsa = Souble[2]\r\nsnh = Souble[3]\r\nsno = Souble[4]\r\nspo = Souble[5]\r\nsi = Souble[6]\r\nsalk = Souble[7]\r\nsnn = Souble[8]\r\n\r\n# 各层总悬浮固体\r\nLayer1TSS = Solid[0]\r\nLayer2TSS = Solid[1]\r\nLayer3TSS = Solid[2]\r\nLayer4TSS = Solid[3]\r\nLayer5TSS = Solid[4]\r\nLayer6TSS = Solid[5]\r\nLayer7TSS = Solid[6]\r\nLayer8TSS = Solid[7]\r\nLayer9TSS = Solid[8]\r\nLayer10TSS = Solid[9]\r\n\r\nxi_top = Layer1TSS * xi_ratio\r\nxs_top = Layer1TSS * xs_ratio\r\nxh_top = Layer1TSS * xh_ratio\r\nxpao_top = Layer1TSS * xpao_ratio\r\nxpp_top = Layer1TSS * xpp_ratio\r\nxpha_top = Layer1TSS * xpha_ratio\r\nxaut_top = Layer1TSS * xaut_ratio\r\nxmeoh_top = Layer1TSS * xmeoh_ratio\r\nxmep_top = Layer1TSS * xmep_ratio\r\nxii_top = Layer1TSS * xii_ratio\r\n\r\nxi_Bottom = Layer10TSS * xi_ratio\r\nxs_Bottom = Layer10TSS * xs_ratio\r\nxh_Bottom = Layer10TSS * xh_ratio\r\nxpao_Bottom = Layer10TSS * xpao_ratio\r\nxpp_Bottom = Layer10TSS * xpp_ratio\r\nxpha_Bottom = Layer10TSS * xpha_ratio\r\nxaut_Bottom = Layer10TSS * xaut_ratio\r\nxmeoh_Bottom = Layer10TSS * xmeoh_ratio\r\nxmep_Bottom = Layer10TSS * xmep_ratio\r\nxii_Bottom = Layer10TSS * xii_ratio\r\n\r\n#回流和排泥的so强制归零\r\nso_reset = 0';
});

// 进水流
stdnodes[0].name = '进水流';
stdnodes[0].type = '进水流';
stdnodes[0].iconpath = '/static/images/进水流.png';
stdnodes[0].portNum = 1;
stdnodes[0].portDefine = '{"inf":{"type":"out","name":"流入","vars":"","order":1}}';
stdnodes[0].inoutVars = '{"NhMode":{"group":"进水水质","category":"","type":0,"defvalue":1,"unit":"","desc":"选择氨氮/凯氏氮","saved":0},"PhMode":{"group":"进水水质","category":"","type":0,"defvalue":1,"unit":"","desc":"选择磷酸盐/总磷","saved":0},"icv":{"group":"进水组分","category":"污水各组分","type":0,"defvalue":2.2,"unit":"gCOD/gVSS","desc":"XCOD/VSS比率","saved":0},"fbod":{"group":"进水组分","category":"污水各组分","type":0,"defvalue":0.66,"unit":"","desc":"BOD5/最终BOD比率","saved":0},"ivt":{"group":"进水组分","category":"COD组分模型系数","type":0,"defvalue":0.6,"unit":"gVSS/gTSS","desc":"VSS/TSS比率","saved":0},"frscod":{"group":"进水组分","category":"COD组分模型系数","type":0,"defvalue":0.35,"unit":"","desc":"总COD中的溶解性比例","saved":0},"frsi":{"group":"进水组分","category":"有机组份","type":0,"defvalue":0.35,"unit":"","desc":"溶解性COD中的惰性比例","saved":0},"frslf":{"group":"进水组分","category":"有机组份","type":0,"defvalue":0,"unit":"","desc":"溶解性COD中的VFA比例","saved":0},"frxs":{"group":"进水组分","category":"有机组份","type":0,"defvalue":0.75,"unit":"","desc":"颗粒性COD中的可降解比例","saved":0},"frxbh":{"group":"进水组分","category":"有机组份","type":0,"defvalue":0,"unit":"","desc":"颗粒性COD中的异养菌比例","saved":0},"q":{"group":"进水流量","category":"","type":1,"defvalue":0,"unit":"m3/h","desc":"进水流量","saved":0},"spo":{"group":"进水水质","category":"模型组分-溶解性组分","type":1,"defvalue":0,"unit":"mgP/L","desc":"磷酸盐","saved":0},"snh":{"group":"进水水质","category":"模型组分-溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"氨氮","saved":0},"COD":{"group":"进水水质","category":"复合指标-磷指标","type":1,"defvalue":0,"unit":"mgCOD/L","desc":"化学需氧量","saved":0},"TP":{"group":"进水水质","category":"复合指标-有机物","type":1,"defvalue":0,"unit":"mgP/L","desc":"总磷","saved":1},"TN":{"group":"进水水质","category":"复合指标-氮指标","type":1,"defvalue":0,"unit":"mgN/L","desc":"总氮","saved":0}}';

// 反应池
stdnodes[1].name = '反应池';
stdnodes[1].type = '悬浮介质处理工艺';
stdnodes[1].iconpath = '/static/images/反应池.png';
stdnodes[1].portNum = 3;
stdnodes[1].portDefine = '{"port1":{"type":"in","name":"进口","vars":"Qin","location":[0,0.5],"order":1},"port2":{"type":"out","name":"溢流口","vars":"Qout","location":[1,0.33],"order":2},"port3":{"type":"out","name":"回流口","vars":"Qpump","location":[1,0.66],"order":3}}';
stdnodes[1].inoutVars = '{"Length":{"group":"构筑物参数","category":"","type":0,"defvalue":100,"unit":"m","desc":"反应池长度","saved":0},"Width":{"group":"构筑物参数","category":"","type":0,"defvalue":50,"unit":"m","desc":"反应池宽度","saved":0},"Level":{"group":"构筑物参数","category":"","type":0,"defvalue":5,"unit":"m","desc":"有效深度","saved":0},"Volume":{"group":"构筑物参数","category":"","type":0,"defvalue":5000,"unit":"m","desc":"反应池容积","saved":0},"icv":{"group":"化学计量学系数","category":"有机物","type":0,"defvalue":1.48,"unit":"","desc":"XCOD/VSS的比率","saved":0},"fbod":{"group":"化学计量学系数","category":"有机物","type":0,"defvalue":0.66,"unit":"","desc":"BOD5/最终BOD比率","saved":0},"yh":{"group":"化学计量学系数","category":"异养菌","type":0,"defvalue":0.625,"unit":"g(COD)/g(COD)","desc":"异养菌产率系数","saved":0},"yaut":{"group":"化学计量学系数","category":"自养菌","type":0,"defvalue":0.24,"unit":"g(COD)/g(N)","desc":"自养菌产率系数","saved":0},"ypao":{"group":"化学计量学系数","category":"聚磷菌","type":0,"defvalue":0.625,"unit":"g(COD)/g(COD)","desc":"聚磷菌产率系数（生物量/PHA）","saved":0},"ypo4":{"group":"化学计量学系数","category":"聚磷菌","type":0,"defvalue":0.4,"unit":"g(P)/g(COD)","desc":"贮存PHA所需要的多磷（PO4的释放）","saved":0},"ypha":{"group":"化学计量学系数","category":"聚磷菌","type":0,"defvalue":0.2,"unit":"g(COD)/g(COD)","desc":"贮存多磷所需的PHA","saved":0},"chooseDOcontrol":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":1,"unit":"","desc":"是否选择溶解氧控制模式","saved":0},"EA":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":27,"unit":"%","desc":"曝气装置氧转移效率","saved":0},"alphaFine":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":0.6,"unit":"","desc":"校正系数alpha","saved":0},"beta":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":0.95,"unit":"","desc":"校正系数beta","saved":0},"aerator_depth":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":4.5,"unit":"m","desc":"曝气头浸没深度","saved":0},"qair_x":{"group":"工艺运行参数","category":"曝气配置","type":0,"defvalue":2000,"unit":"m3/h","desc":"曝气流量（这个向量要在后期重点设计）","saved":0},"so":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgO2/L","desc":"溶解氧","saved":0},"sf":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgCOD/L","desc":"易降解基质","saved":0},"sa":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgCOD/L","desc":"发酵产物","saved":0},"snh":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"氨氮","saved":0},"sno":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"硝态氮","saved":0}}'

// 二沉池
stdnodes[2].name = '二沉池';
stdnodes[2].type = '澄清沉淀工艺';
stdnodes[2].iconpath = '/static/images/二沉池.gif';
stdnodes[2].portNum = 4;
stdnodes[2].portDefine = '{"in":{"type":"in","name":"输入","vars":"","order":1},"out":{"type":"out","name":"溢流","vars":"","order":2},"was":{"type":"out","name":"排泥","vars":"","order":3},"ras":{"type":"out","name":"回流","vars":"","order":4}}';
stdnodes[2].inoutVars = '{"Diameter":{"group":"构筑物参数","category":"","type":0,"defvalue":25,"unit":"m","desc":"沉淀池直径","saved":0},"Length":{"group":"构筑物参数","category":"","type":0,"defvalue":50,"unit":"m","desc":"沉淀池长度","saved":0},"Width":{"group":"构筑物参数","category":"","type":0,"defvalue":30,"unit":"m","desc":"沉淀池宽度","saved":0},"Aset":{"group":"构筑物参数","category":"","type":0,"defvalue":2500,"unit":"m²","desc":"沉淀池表面积","saved":0},"Level":{"group":"构筑物参数","category":"","type":0,"defvalue":5,"unit":"m","desc":"沉淀池有效水深","saved":0},"xt":{"group":"沉淀动力学参数","category":"","type":0,"defvalue":3410,"unit":"gTSS/m3","desc":"临界悬浮固体浓度","saved":0},"xmax":{"group":"沉淀动力学参数","category":"","type":0,"defvalue":410,"unit":"m/d","desc":"最大理论沉降速度","saved":0},"snh":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"氨氮","saved":0},"sno":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"硝态氮","saved":0},"spo":{"group":"模型组分","category":"溶解性组分","type":1,"defvalue":0,"unit":"mgP/L","desc":"磷酸盐","saved":0},"CODTop":{"group":"复合指标","category":"有机物-顶层出水","type":1,"defvalue":0,"unit":"mgCOD/L","desc":"化学需氧量","saved":0},"TNTop":{"group":"复合指标","category":"氮指标-顶层出水","type":1,"defvalue":0,"unit":"mgN/L","desc":"总氮","saved":0},"TSSTop":{"group":"复合指标","category":"有机物-顶层出水","type":1,"defvalue":0,"unit":"mg/L","desc":"总悬浮固体","saved":0},"Qras":{"group":"水力和运行变量","category":"","type":1,"defvalue":0,"unit":"m3/h","desc":"污泥回流量","saved":0},"Qwas":{"group":"水力和运行变量","category":"","type":1,"defvalue":0,"unit":"m3/h","desc":"剩余污泥排放流量","saved":0},"Qout":{"group":"水力和运行变量","category":"","type":1,"defvalue":0,"unit":"m3/h","desc":"沉淀池出水流量","saved":0},"HRT":{"group":"水力和运行变量","category":"","type":1,"defvalue":0,"unit":"hour","desc":"沉淀池停留时间","saved":0}}';

// 汇流器
stdnodes[3].name = '汇流器';
stdnodes[3].type = '水流汇合器和水流分离器';
stdnodes[3].iconpath = '/static/images/汇流器.gif';
stdnodes[3].portNum = 3;
stdnodes[3].portDefine = '{"in1":{"type":"in","name":"输入#1","vars":"","order":1},"in2":{"type":"in","name":"输入#2","vars":"","order":2},"out":{"type":"out","name":"输出","vars":"","order":3}}';
stdnodes[3].inoutVars = '{"so":{"group":"模型组分","category":"溶解性组分","type":0,"defvalue":0,"unit":"mgO2/L","desc":"溶解氧","saved":0},"sf":{"group":"模型组分","category":"溶解性组分","type":0,"defvalue":0,"unit":"mgCOD/L","desc":"易降解基质","saved":0},"sa":{"group":"模型组分","category":"溶解性组分","type":0,"defvalue":0,"unit":"mgCOD/L","desc":"发酵产物","saved":0},"xi":{"group":"模型组分","category":"颗粒性组分","type":0,"defvalue":0,"unit":"mgCOD/L","desc":"颗粒性惰性有机物","saved":0},"xs":{"group":"模型组分","category":"颗粒性组分","type":0,"defvalue":0,"unit":"mgCOD/L","desc":"慢速可降解有机物","saved":0},"xh":{"group":"模型组分","category":"颗粒性组分","type":0,"defvalue":0,"unit":"mgCOD/L","desc":"异养菌","saved":0}}';

// 出水流
stdnodes[4].name = '出水流';
stdnodes[4].type = '水流汇合器和水流分离器';
stdnodes[4].iconpath = '/static/images/出水流.bmp';
stdnodes[4].portNum = 1;
stdnodes[4].portDefine = '{"outf":{"type":"in","name":"流出","vars":"","order":1}}';
stdnodes[4].inoutVars = '{"NhMode":{"group":"出水水质","category":"","type":0,"defvalue":1,"unit":"","desc":"选择氨氮/凯氏氮","saved":0},"PhMode":{"group":"出水水质","category":"","type":0,"defvalue":1,"unit":"","desc":"选择磷酸盐/总磷","saved":0},"icv":{"group":"出水组分","category":"污水各组分","type":0,"defvalue":2.2,"unit":"gCOD/gVSS","desc":"XCOD/VSS比率","saved":0},"fbod":{"group":"出水组分","category":"污水各组分","type":0,"defvalue":0.66,"unit":"","desc":"BOD5/最终BOD比率","saved":0},"ivt":{"group":"出水组分","category":"COD组分模型系数","type":0,"defvalue":0.6,"unit":"gVSS/gTSS","desc":"VSS/TSS比率","saved":0},"frscod":{"group":"出水组分","category":"COD组分模型系数","type":0,"defvalue":0.35,"unit":"","desc":"总COD中的溶解性比例","saved":0},"frsi":{"group":"出水组分","category":"有机组份","type":0,"defvalue":0.35,"unit":"","desc":"溶解性COD中的惰性比例","saved":0},"frslf":{"group":"出水组分","category":"有机组份","type":0,"defvalue":0,"unit":"","desc":"溶解性COD中的VFA比例","saved":0},"frxs":{"group":"出水组分","category":"有机组份","type":0,"defvalue":0.75,"unit":"","desc":"颗粒性COD中的可降解比例","saved":0},"frxbh":{"group":"出水组分","category":"有机组份","type":0,"defvalue":0,"unit":"","desc":"颗粒性COD中的异养菌比例","saved":0},"q":{"group":"出水流量","category":"","type":1,"defvalue":0,"unit":"m3/h","desc":"出水流量","saved":0},"spo":{"group":"出水水质","category":"模型组分-溶解性组分","type":1,"defvalue":0,"unit":"mgP/L","desc":"磷酸盐","saved":0},"snh":{"group":"出水水质","category":"模型组分-溶解性组分","type":1,"defvalue":0,"unit":"mgN/L","desc":"氨氮","saved":0},"COD":{"group":"出水水质","category":"复合指标-磷指标","type":1,"defvalue":0,"unit":"mgCOD/L","desc":"化学需氧量","saved":0},"TP":{"group":"出水水质","category":"复合指标-有机物","type":1,"defvalue":0,"unit":"mgP/L","desc":"总磷","saved":1},"TN":{"group":"出水水质","category":"复合指标-氮指标","type":1,"defvalue":0,"unit":"mgN/L","desc":"总氮","saved":0}}';

// 初始化数据库
const Stdnode = cdb.link('stdnode', stdnodes);

/**
 * 获取所有的`stdnode`
 */
Mock.get('/api/all_stdnode', () => {
  const list = Stdnode.find({});
  const result = list2treeGroup('type')(list);
  return Mock.restpl({
    result,
    token: sessionStorage.getItem('login_token')
  })
});
Mock.get('/api/stdnode', () => {
  const list = Stdnode.find({});
  return Mock.restpl({
    result: list,
    token: sessionStorage.getItem('login_token')
  })
});

/**
 * 获取单个的`stdnode`
 */
Mock.get('/api/stdnode/:id', (id) => {
  return Mock.restpl({
    result: Stdnode.findById(id),
    token: sessionStorage.getItem('login_token')
  });
});

/**
 * 新增`stdnode`
 */
Mock.post('/api/stdnode', (std) => {
  const {type, name} = std;
  return Mock.restpl({
    result: Stdnode.insert({type, name}),
    token: sessionStorage.getItem('login_token')
  });
});

/**
 * 更新`stdnode`
 */
Mock.patch('/api/stdnode', (std) => {
  const id = std.id;
  delete std.id;
  return Mock.restpl({
    result: Stdnode.update(id, std),
    token: sessionStorage.getItem('login_token')
  });
});

/**
 * 删除`stdnode`
 */
Mock.delete('/api/stdnode/:id', id => {
  return Mock.restpl({
    result: Stdnode.remove(id),
    token: sessionStorage.getItem('login_token')
  });
})

