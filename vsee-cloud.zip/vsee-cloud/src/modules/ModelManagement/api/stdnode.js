import $ from '@/lib/ajax';
import { API_PREFIX } from '@/config';

export default {
  getAllStdnode: () => $.get(API_PREFIX + '/all_stdnode'),
  getStdnodes: () => $.get(API_PREFIX + '/stdnode'),
  getStdnode: (id) => $.get(API_PREFIX + '/stdnode/' + id),
  addStdnode: (stdnode) => $.post(API_PREFIX + '/stdnode', stdnode),
  updateStdnode: (stdnode) => $.patch(API_PREFIX + '/stdnode', stdnode),
  removeStdnode: (stdnode) => $.delete(API_PREFIX + '/stdnode/' + stdnode.id),
  // getUsers () {
  //   return $.get('/api/users');
  // },
  // deleteUser (id) {
  //   return $.delete('/api/user/' + id);
  // },
  // getTreeData () {
  //   return $.get('/api/treedata');
  // },
  // getNode (id) {
  //   return $.get('/api/node', id);
  // },
  // getStdnode (id) {
  //   return $.get('/api/stdnode', id);
  // },
  // updateStdNode (stdnode) {
  //   return $.patch('/api/stdnode', stdnode)
  // }
};
