<template>
  <a-modal
    :width="600"
    :title="editMode ? '编辑变量' : '新增变量'"
    :visible="visible"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-form
      :form="form"
    >
      <a-row :gutter="24">
        <a-col :span="12">
          <a-form-item
            label="变量名"
          >
            <a-input
              v-decorator="[
                'name', 
                {
                  validateFirst: true,
                  rules: [
                    { required: true, message: '请输入变量名称'}, 
                    { validator: varsUniquedValidator, message: '变量名称重复' },
                    { pattern: /^[A-Za-z]+$/, message: '变量名称请遵循规范命名' },
                  ]
                }
              ]"
              placeholder="请输入变量名称"
            />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item
            label="所属分类"
          >
            <a-auto-complete
              :data-source="existCategories"
              v-decorator="[
                'category', 
              ]"
              placeholder="请选择或输入新分类"
            />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="24">
        <a-col :span="12">
          <a-form-item
            label="默认值"
          >
            <a-input-number
              style="width: 100%;"
              v-decorator="[
                'defvalue',
                {rules: [{ required: true, message: '请输入默认值'}]}
              ]"
              placeholder="请输入默认值"
            >
            </a-input-number>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item
            label="单位"
          >
            <a-input
              v-decorator="[
                'unit',
              ]"
              placeholder="请输入单位"
            />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="24">
        <a-col :span="12">
          <a-form-item
            label="类型"
          >
            <a-radio-group
              v-decorator="[
                'type',
                { initialValue: 0}
              ]"
            >
              <a-radio-button :value="0">
                设计型
              </a-radio-button>
              <a-radio-button :value="1">
                运行型
              </a-radio-button>
            </a-radio-group>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item
            label="是否保存"
          >
            <a-checkbox 
              v-decorator="[
                'saved',
                { valuePropName: 'checked' }
              ]"
            >
            </a-checkbox>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="24">
        <a-col :span="24">
          <a-form-item
            label="变量描述"
          >
            <a-textarea
              autosize
              v-decorator="[
                'desc', 
              ]"
              placeholder="请输入变量描述"
            />
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script>
import { split2array } from '@/lib/util';

/**
 * 构建表单字段映射
 */
function getRecordFields (vm) {
  return {
    name: vm.$form.createFormField({value: vm.record.name}),
    category: vm.$form.createFormField({value: vm.record.category}),
    defvalue: vm.$form.createFormField({value: vm.record.defvalue}),
    unit: vm.$form.createFormField({value: vm.record.unit}),
    type: vm.$form.createFormField({value: vm.record.type || 0}),
    desc: vm.$form.createFormField({value: vm.record.desc}),
    saved: vm.$form.createFormField({value: !!vm.record.saved}),
  }
}
export default {
  /**
   * 模型变量的编辑窗口
   */
  name: 'InoutVarsEdit',
  props: {
    /**
     * 已有变量集合
     */
    existVars: {
      type: Array,
      default: () => ([])
    },
    /**
     * 已有分类集合
     */
    existCategories: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      /**
       * 表单数据
       */
      record: {},
      /**
       * 弹出窗是否可见，默认`false`
       */
      visible: false,
    }
  },
  computed: {
    /**
     * 动态标题，若传入数据为空，则表示**新增**，反之表示**编辑**
     */
    editMode () {
      return this.record.hasOwnProperty('name');
    }
  },
  watch: {
    record () {
      this.form.updateFields(getRecordFields(this));
    }
  },
  created () {
    this.form = this.$form.createForm(this, {
      mapPropsToFields: () => getRecordFields(this)
    });
  },
  
  methods: {
    /**
     * 确认
     */
    handleOk () {
      this.form.validateFields(err => {
        if (!err) {
          const data = this.form.getFieldsValue();
          // 如果增加了新的分类，通知上层元素
          if (!~this.existCategories.indexOf(data.category)) {
            this.$emit('addCategory', data.category);
          }
          this.visible = false;
          this.$emit('update', {...this.record, ...data});
          this.clear();
        }
      });
    },
    /**
     * 取消
     */
    handleCancel () {
      this.visible = false;
      this.clear();
    },
    /**
     * 验证端口唯一性，不允许重复，且必须为英文
     */
    varsUniquedValidator (rule, value, callback) {
      // 新增端口，发现重名，则提出错误信息
      if (~this.existVars.indexOf(value) && value !== this.record.name) {
        callback(new Error());
      }
      callback();
    },
    /**
     * 动态加载外部数据
     */
    load (data) {
      this.$set(this, 'record', {...data})
      this.visible = true;
    },
    /**
     * 清除表单数据
     */
    clear () {
      this.$nextTick(() => {
        this.$set(this, 'record', {});
      })
    },
  }
}
</script>
