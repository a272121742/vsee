<template>
  <a-modal
    :width="600"
    :title="editMode ? '编辑端口' : '新增端口'"
    :visible="visible"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-form :form="form">
      <a-form-item
        label="端口编号"
      >
        <a-input
          v-decorator="[
            'port', 
            {
              validateFirst: true,
              rules: [
                { required: true, message: '请输入端口编号'}, 
                { validator: portUniquedValidator, message: '端口名称重复' },
                { pattern: /^[A-Za-z][A-Za-z0-9_]*$/, message: '端口名称请遵循变量命名' },
              ]
            }
          ]"
          placeholder="请输入端口编号"
        />
      </a-form-item>

      <a-form-item
        label="端口类型"
      >
        <a-select
          v-decorator="[
            'type',
            {rules: [{ required: true, message: '请选择端口类型'}]}
          ]"
          placeholder="请选择端口类型"
        >
          <a-select-option value="in">
            输入
          </a-select-option>
          <a-select-option value="out">
            输出
          </a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item
        label="端口名称"
      >
        <a-input
          v-decorator="[
            'name', 
            {rules: [{ 
              required: true, message: '请输入端口名称'}
            ]}
          ]"
          placeholder="请输入端口名称"
        />
      </a-form-item>
      <a-form-item
        label="可用变量"
      >
        <a-select 
          v-decorator="[
            'vars',
          ]"
          allow-clear
          mode="multiple"
          not-found-content="查无变量"
          placeholder="请选择端口变量"
        >
          <a-select-option
            v-for="varName in optionalVars"
            :key="varName"
          >
            {{ varName }}
          </a-select-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script>
import { split2array } from '@/lib/util';

/**
 * 构建表单字段映射
 */
function getRecordFields (vm) {
  return {
    port: vm.$form.createFormField({value: vm.record.port}),
    type: vm.$form.createFormField({value: vm.record.type}),
    name: vm.$form.createFormField({value: vm.record.name}),
    vars: vm.$form.createFormField({value: vm.record.vars}),
  }
}
export default {
  /**
   * 端口定义的编辑窗口
   */
  name: 'PortDefineEdit',
  props: {
    /**
     * 已有端口名称集合
     */
    existPort: {
      type: Array,
      default: () => ([])
    },
    /**
     * 可供选择的变量集合
     */
    optionalVars: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      /**
       * 表单数据
       */
      record: {},
      /**
       * 弹出窗是否可见，默认`false`
       */
      visible: false,
    }
  },
  computed: {
    /**
     * 动态标题，若传入数据为空，则表示**新增**，反之表示**编辑**
     */
    editMode () {
      return this.record.hasOwnProperty('name');
    },
  },
  watch: {
    record () {
      // 更新映射
      this.form.updateFields(getRecordFields(this));
    }
  },
  created () {
    this.form = this.$form.createForm(this, {
      // 将`record`值映射到表单
      mapPropsToFields: () => getRecordFields(this)
    })
  },
  methods: {
    /**
     * 确认
     */
    handleOk () {
      this.form.validateFields(err => {
        if (!err) {
          const data = this.form.getFieldsValue();
          data.vars = data.vars.join(',');
          this.visible = false;
          this.$emit('update', {...this.record, ...data});
          this.clear();
        }
      });
    },
    /**
     * 取消
     */
    handleCancel () {
      this.visible = false;
      this.clear();
    },
    /**
     * 验证端口唯一性，不允许重复，且必须为英文
     */
    portUniquedValidator (rule, value, callback) {
      // 发现重名，则提出错误信息
      if (~this.existPort.indexOf(value) && value != this.record.port) {
        callback(new Error());
      }
      callback();
    },
    /**
     * 动态加载外部数据
     */
    load (data) {
      const vars = split2array(',', data.vars);
      this.$set(this, 'record', {
        ...data,
        vars,
      });
      this.visible = true;
    },
    /**
     * 清除表单数据
     */
    clear () {
      this.$nextTick(() => {
        this.$set(this, 'record', {});
      })
    },
  }
}
</script>

<style lang="less" scoped>

</style>

