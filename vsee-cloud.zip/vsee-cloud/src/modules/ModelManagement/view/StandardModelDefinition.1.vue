<template>
  <a-row :gutter="gutter">
    <!-- 菜单树 -->
    <a-col :span="6">
      <a-card
        class="full-fill-card"
        style="height: -webkit-fill-available; border: none;"
        title="标准模型"
      >
        <menu-tree
          :data-source="treeData"
          :search="true"
          @onDelete="deleteMenuTreeItem"
          @onEdit="editMenuTreeItem"
          @onAdd="addMenuTreeItem"
          @onSelect="selectMenuTreeItem"
        >
        </menu-tree>
      </a-card>
    </a-col>
    <a-col :span="18">
      <a-row :gutter="gutter">
        <a-col
          :span="16"
        >
          <div style="background: #FFF; height: 420px;">
            <!-- 模型/代码展示切换 -->
            <a-radio-group
              default-value="model"
              button-style="solid"
              v-model="showModel"
              @change="changeShowModel"
            >
              <a-radio-button value="model">
                模型
              </a-radio-button>
              <a-radio-button value="code">
                代码
              </a-radio-button>
            </a-radio-group>
            <div 
              v-if="stdnode.id"
              style="float: right; clear: both;"
            >
              编辑模式 <a-switch @change="checked => editable = checked" />
              <a-button
                @click="saveStdnode"
                :disabled="!editable"
              >
                保存
              </a-button>
            </div>
            <!-- </a-row> -->
            <!-- <div :gutter="gutter"> -->
            <keep-alive v-if="showModel === 'model'">
              <div>图片</div>
            </keep-alive>
            <div v-else>
              <codemirror
                :value="stdnode.codestr"
                :options="codeEditOptions"
              ></codemirror>
            </div>
          </div>
        </a-col>
        <a-col :span="8">
          <a-card title="模型属性">
            <a
              v-if="editable"
              slot="extra"
              @click="editModel"
              style="padding-right: 8px;"
            ><a-icon type="edit" /></a>
            <model-props-edit
              ref="editModelForm"
              @update="handleUpdateModel"
            ></model-props-edit>
            <model-props-table
              :editable="show"
              :record="stdnode"
            >
            </model-props-table>
          </a-card>
        </a-col>
      </a-row>
      <a-row
        :gutter="gutter"
        style="margin-top: 16px;"
      >
        <a-col :span="24">
          <!-- 端口定义 & 模型变量 -->
          <a-card
            ref="card"
            :tab-list="tabList"
            :active-tab-key="selectedTab"
            @tabChange="tabChange"
          >
            <!-- 标题计数器 -->
            <span
              slot="portDefine"
            >
              <a-icon type="usb" />端口定义{{ portDefineCount ? `(${portDefineCount})` : '' }}
            </span>
            <span
              slot="inoutVars"
            >
              <a-icon type="profile" />模型变量{{ inoutVarsCount ? `(${inoutVarsCount})` : '' }}
            </span>
            <keep-alive>
              <port-define-table
                v-if="selectedTab === 'portDefine'"
                :editable="show"
                :data-source="portDefine"
                :optional-vars="optionalVars"
                @update="handleUpdatePortDefine"
              ></port-define-table>
              <inout-vars-table
                v-else-if="selectedTab === 'inoutVars'"
                :editable="show"
                :data-source="inoutVars"
                @update="handleUpdateInoutVars"
              >
              </inout-vars-table>
            </keep-alive>
          </a-card>
        </a-col>
      </a-row>
    </a-col>
  </a-row>
</template>

<script>
import { createNamespacedHelpers } from 'vuex';
import {pipe, forEachObjIndexed, partialRight, clone, keys} from 'ramda';
import {string2json, map2list, list2map} from '@lib/util';

const { mapActions } = createNamespacedHelpers('ModelManagement');


export default {
  name: 'StandardModelDefinition',
  components: {
    MenuTree: () => import('@comp/Tree/MenuTree'),
    ModelPropsTable: () => import('../view/ModelProps'),
    PortDefineTable: () => import('../view/PortDefine'),
    InoutVarsTable: () => import('../view/InoutVars'),
    ModelPropsEdit: () => import('../view/ModelPropsEdit.vue'),
    Codemirror: () => (
      import('codemirror/mode/python/python'),
      import('codemirror/addon/selection/active-line'),
      import('vue-codemirror-lite/codemirror')
    )
  },
  data () {
    return {
      // 栅格配置
      gutter: { xs: 0, sm: 8, md: 16 },
      // tree的数据
      treeData: [],
      // 是显示图片模型还是显示代码
      showModel: 'model',
      stdnode: {
        portDefine: '',
        inoutVars: '',
        codestr: ''
      },
      // 是否开启编辑模式
      editable: false,
      codeEditOptions: {
        mode: 'python',
        lineNumbers: true,
        readOnly: 'nocursor',
        styleActiveLine: true
      },
      // 标签页配置
      tabList: [{
        key: 'portDefine', 
        name: '端口定义',
        // tab: '端口定义',
        scopedSlots: {tab: 'portDefine'}
      }, {
        key: 'inoutVars', 
        name: '模型变量',
        // tab: '模型变量',
        scopedSlots: {tab: 'inoutVars'}
      }],
      // 默认选中Tab页
      selectedTab: 'portDefine',
    }
  },
  computed: {
    show () {
      return this.editable && this.stdnode.hasOwnProperty('id');
    },
    /**
     * 端口定义的数据列表
     */
    portDefine () {
      return this.convertPortDefine(this.stdnode.portDefine);
    },
    portDefineCount () {
      return this.portDefine.length;
    },
    /**
     * 模型参数的数据列表
     */
    inoutVars () {
      return this.convertInoutVars(this.stdnode.inoutVars);
    },
    inoutVarsCount () {
      return this.inoutVars.length;
    },
    // 可选变量
    optionalVars () {
      return keys(string2json(this.stdnode.inoutVars));
    }
  },
  created () {
    // 1. 渲染Tree
    this.getAllStdnode().then(res => {
      this.treeData = clone(res.result);
    });
  },
  activated () {
    console.log('标准模型定义页面激活');
  },
  deactivated () {
    console.log('标准模型定义页面失活');
  },
  methods: {
    // 映射模块
    ...mapActions([
      'getAllStdnode',
      'getStdnode',
      'addStdnode',
      'updateStdnode',
      'removeStdnode'
    ]),
    // 转码 String -> Array<Object>
    convertPortDefine: pipe(string2json, map2list('port')),
    // 转码 Array<Object> -> String
    reconvertPortDefine: pipe(list2map('port'), partialRight(JSON.stringify, [null, 2])),
    // 转码 String -> Array<Object>
    convertInoutVars: pipe(string2json, map2list('name')),
    // 转码 Array<Object> -> String
    reconvertInoutVars: pipe(list2map('name'), partialRight(JSON.stringify, [null, 2])),
    /**
     * 增加菜单项
     * @param {*} parent - 父节点信息，该信息中只有`name`可用；
     * @param Function next - 回调函数， 传回true则表示操作成功。
     */
    addMenuTreeItem ({name, type}, next) {
      this.addStdnode({name, type}).then(res => {
        const stdnode = res.result;
        const typeIndex = this.treeData.findIndex(item => item.type === type);
        this.treeData[typeIndex].children.push({
          ...res.result,
          key: res.result.id,
          title: res.result.name
        });
        next(res.success);
      });
    },
    /**
     * @param {*} parent - 子节点信息，该信息中只有`name`可用；
     * @param Function next - 回调函数， 传回true则表示操作成功。
     */
    editMenuTreeItem (child, next) {
      this.updateStdnode(child).then(res => {
        const stdnode = res.result;
        const typeIndex = this.treeData.findIndex(item => item.type === stdnode.type);
        const dataIndex = this.treeData[typeIndex].children.findIndex(item => item.id === stdnode.id);
        const oldStdnode = this.treeData[typeIndex].children[dataIndex];
        this.$set(this.treeData[typeIndex].children, dataIndex, {...oldStdnode, title: stdnode.name, name: stdnode.name});
        next(res.success);
      });
    },
    /**
     * 菜单树删除
     * @param {*} child - 要删除的节点；
     */
    deleteMenuTreeItem (child) {
      this.removeStdnode(child).then(res => {
        const stdnode = res.result;
        const typeIndex = this.treeData.findIndex(item => item.type === stdnode.type);
        const dataIndex = this.treeData[typeIndex].children.findIndex(item => item.id === stdnode.id);
        this.$delete(this.treeData[typeIndex].children, dataIndex);
      });
    },
    /**
     * 菜单树选择
     * @param {*} record - 已选择到的节点数据
     */
    selectMenuTreeItem (record) {
      // 设置当前选择的stdnode
      this.loadStdnode(record.data.id);
    },
    // 获取std相应内容并渲染
    loadStdnode (id) {
      this.getStdnode(id).then(res => {
        console.log('获取到数据', res.result);
        this.$set(this, 'stdnode', res.result)
      });
    },
    // TODO: 待完善
    changeShowModel () {
      console.log(this.showModel);
    },
    
    // 触发更新
    handleUpdateModel (stdnode) {
      this.$set(this, 'stdnode', {...this.stdnode, ...stdnode});
    },
    handleUpdatePortDefine (portDefineList) {
      this.$set(this.stdnode, 'portDefine', this.reconvertPortDefine(portDefineList));
      this.$set(this.stdnode, 'portNum', this.portDefineCount);
    },
    handleUpdateInoutVars (inoutVarsList) {
      this.$set(this.stdnode, 'inoutVars', this.reconvertInoutVars(inoutVarsList));
    },
    /**
     * 弹出编辑模型的表单
     */
    editModel () {
      this.$refs.editModelForm.load(this.stdnode);
    },
    // 保存
    saveStdnode () {
      this.updateStdnode({...this.stdnode}).then(res => {
        if (res.success) {
          this.$set(this, 'stdnode', res.result);
          this.$message.success('保存成功！');
        } else {
          this.$message.error('保存失败！');
        }
      });
    },
    onChange (checked) {
      console.log(checked);
    },
    tabChange (key) {
      this.selectedTab = key;
    }
  }
}
</script>

<style lang="less" scoped>
  /*穿透卡片组件，设置标题紧凑*/
  .ant-card {
    /deep/ .ant-card-head {
      min-height: 32px;
      padding: 0px 8px;
      .ant-card-head-title {
        padding: 12px 8px;
      }
    }
    /deep/ .ant-card-body {
      padding: 0px;
      border-top: 1px solid #e8e8e8;
    }
    /deep/ .ant-table {
      border: none;
      .ant-table-content {
        border-right: 0px;
      }
    }
    /deep/ .ant-card-extra {
      padding: 0px;
    }
    /deep/ .ant-tabs-tab {
      padding-top: 12px;
      padding-bottom: 12px;
      font-weight: 500;
    }
  }
</style>


