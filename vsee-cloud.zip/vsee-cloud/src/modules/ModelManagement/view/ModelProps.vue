<template>
  <div>
    <img
      :src="record.iconpath"
      style="position: absolute; right: 48px; top: 96px; z-index: 100;"
    >
    <a-table
      style="width: 75%;"
      :row-key="(r, i) => i"
      :columns="columns"
      :data-source="data"
      :pagination="false"
      size="small"
      bordered
    >
    </a-table>
  </div>
</template>

<script>
import { json2mapEntries } from '@lib/util';

export default {
  /**
   * 模型属性
   */
  name: 'ModelProps',
  // components: {
  //   // ModelEdit: () => import('./ModelEdit.vue')
  // },
  props: {
    /**
     * 模型对象，从上层直接获取数据，深度监听此属性
     */
    record: {
      type: Object,
      default: () => ({})
    },
    /**
     * 是否可编辑
     */
    editable: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      columns: [{
        title: '名称',
        dataIndex: 'name',
        key: 'name',
        width: 64
      }, {
        title: '值',
        dataIndex: 'value',
        key: 'value',
      }],
      data: [],
    }
  },
  watch: {
    // 当外部`record`更新时，重新更新内部数据；
    record: {
      // 深度监听每一个属性
      deep: true,
      // 开始监听时立刻生效一次
      immediate: true,
      handler () {
        this.update();
      }
    }
  },
  created () {
    
  },
  methods: {
    update () {
      this.$set(this, 'data', this.convert2propsTable(this.record));
    },
    /**
     * 将对象按照如下对照表转换成数组
     */
    convert2propsTable: json2mapEntries({
      props: {
        nodeID: '编号',
        name: '名称',
        portNum: '端口数',
        desc: '描述',
      }
    })
  }
}
</script>

<style lang="less" scoped>
</style>

