<template>
  <a-row>
    <a-col :span="12">
      <!-- 可视化打点 -->
      <dot-image
        style="margin-left: 15%; margin-top: 15%;"
        :editable="editable"
        :source-map="pointMap"
        @add="addPort"
        @select="selectPort"
      ></dot-image>
    </a-col>
    <a-col :span="12">
      <!-- 端口定义的表单 -->
      <port-define-form
        ref="form"
        :editable="editable"
        :exist-port="existPort"
        :optional-vars="optionalVars"
        @update="updatePoint"
        @remove="removePoint"
      ></port-define-form>
    </a-col>
  </a-row>
</template>

<script>
import { map, prop, clone, keys, omit } from 'ramda';
import { split2array } from '@lib/util';


/**
 * 端口定义的表格组件
 * 组件模式：
 *  1. 外部将字符串数据传入组件内部，渲染成数组
 *  2. 数组列表进行增删改的操作后，触发上层组件的`update`事件
 */
export default {
  name: 'PortDefinedDot',
  components: {
    DotImage: () => import('@comp/DotImage/DotImage'),
    PortDefineForm: () => import('./PortDefineEditForm'),
  },
  props: {
    /**
     * 是否可编辑，默认false
     */
    editable: {
      type: Boolean,
      default: true
    },
    /**
     * 传入的标准列表数据源，无需像上面一样转换
     */
    sourceMap: {
      type: Object,
      default: () => ({})
    },
    /**
     * 可选变量（字符串）
     */
    optionalVars: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      /**
       * 点位映射集合
       */
      pointMap: {}
    }
  },
  computed: {
    /**
     * 动态获取存在的端口名称，用于向`端口编辑`的弹窗组件传递约束参数。
     * 端口编辑窗口中，端口名称必须唯一。
     */
    existPort () {
      return keys(this.sourceMap);
    },
    
  },
  watch: {
    sourceMap: {
      immediate: true,
      handler () {
        this.refresh();
      }
    }
  },
  created () {
    // this.refresh();
  },
  methods: {
    addPort () {

    },
    selectPort (point) {
      console.log('选择了点位', point);
      const record = this.sourceMap[point[2]];
      this.$refs.form.load({...record, port: point[2]});
    },
    updatePoint (point, old) {
      console.log('更新点位', point, old, this.sourceMap);
      if (this.sourceMap[point.port]) {
        const ports = omit([old.port], this.sourceMap);
        ports[point.port] = point;
        this.$emit('update', ports);
      }
    },
    removePoint (point) {
      console.log('删除点位', point);
      if (this.sourceMap[point.port]) {
        const ports = omit([point.port], this.sourceMap);
        this.$emit('update', ports);
      }
    },
    /**
     * 数据刷新，数据由上层组件字符串向下传递获得并对列表按照字段`order`进行排序
     */
    refresh () {
      console.log('加载全部端口', this.sourceMap);
      this.$set(this, 'pointMap', map(item => item.location || [], this.sourceMap));
    },
  }
};

</script>

<style lang="less" scoped>
</style>
