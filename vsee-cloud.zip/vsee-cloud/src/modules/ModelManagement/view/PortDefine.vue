<template>
  <div>
    <!-- 编辑表单（弹出）-->
    <port-define-edit
      ref="editForm"
      :exist-port="existPort"
      :optional-vars="optionalVars"
      @update="portDefineUpdate"
    ></port-define-edit>
    <!-- 可排序表格-->
    <a-table
      v-sortable="{el: '.ant-table-wrapper .ant-table-body table .ant-table-tbody', onEnd: handleDragEnd, handle: '.anticon-drag'}"
      :row-key="(r, i) => i"
      :columns="columns"
      :data-source="data"
      :pagination="false"
      :scroll="{ y: 240 }"
      size="small"
      bordered
    >
      <template
        slot="type"
        slot-scope="type"
      >
        {{ type }}
      </template>
      <template
        slot="typeIndex"
        slot-scope="type, record"
      >
        {{ formatType(record) }}
      </template>
      <!-- 自定义标题（操作栏） -->
      <template
        slot="operationTitle"
      >
        <a
          v-if="editable"
          @click="handleAdd"
        ><a-icon type="plus" /></a>
        <div v-else>
          操作
        </div>
      </template>
      <!-- 变量标签 -->
      <template
        slot="vars"
        slot-scope="vars"
      >
        <a-tag
          v-for="v in getVarsArray(vars)"
          color="blue"
          :key="v"
        >
          {{ v }}
        </a-tag>
      </template>
      <template
        v-if="editable"
        slot="operation"
        slot-scope="text, record, index"
      >
        <a
          @click="() => handleEdit(index, record)"
        ><a-icon type="edit" /></a>
        <a
          @click="() => handleRemove(index)"
        ><a-icon type="delete" /></a>
        <a
          style="cursor:move;"
        ><a-icon type="drag" /></a>
      </template>
    </a-table>
  </div>
</template>

<script>
import { map, prop, move, pipe, sortBy, groupBy, countBy } from 'ramda';
import { split2array } from '@lib/util';


/**
 * 端口定义的表格组件
 * 组件模式：
 *  1. 外部将字符串数据传入组件内部，渲染成数组
 *  2. 数组列表进行增删改的操作后，触发上层组件的`update`事件
 */
export default {
  name: 'PortDefined',
  components: {
    PortDefineEdit: () => import('./PortDefineEdit.vue')
  },
  props: {
    /**
     * 是否可编辑，默认false
     */
    editable: {
      type: Boolean,
      default: true
    },
    /**
     * 传入的标准列表数据源，无需像上面一样转换
     */
    dataSource: {
      type: Array,
      default: () => ([])
    },
    /**
     * 可选变量（字符串）
     */
    optionalVars: {
      type: Array,
      default: () => ([])
    }
  },
  data () {
    return {
      // 表格列信息
      columns: columns,
      // 表格数据
      data: [],
      // 操作行
      selectedRow: -1
    }
  },
  computed: {
    /**
     * 动态获取存在的端口名称，用于向`端口编辑`的弹窗组件传递约束参数。
     * 端口编辑窗口中，端口名称必须唯一。
     */
    existPort () {
      return map(prop('port'), this.data)
    },
    portTypeGroup () {
      const groupMap = pipe(sortBy(prop('order')), groupBy(prop('type')))(this.data);
      const countMap = countBy(prop('type'), this.data);
      const r = map(group => {
        const result = {};
        group.forEach((port, index) => {
          result[port.name] = index + 1;
        });
        return result;
      }, groupMap);
      return r;
    }
  },
  watch: {
    dataSource: {
      immediate: true,
      handler () {
        this.refresh();
      }
    }
  },
  created () {

  },
  methods: {
    /**
     * 数据刷新，数据由上层组件字符串向下传递获得并对列表按照字段`order`进行排序
     */
    refresh () {
      this.$set(this, 'data', sortBy(prop('order'), [...this.dataSource]));
    },
    /**
     * 内部数据更新结束
     */
    updated () {
      // 将数据发送给上层组件
      this.$emit('update', [...this.data]);
    },
    /**
     * 端口发生变化时，调用此方法：
     * 1. 端口新增时被调用，`this.selectedRow = -1`;
     * 2. 端口修改时被调用，`this.selectedRow > -1`;
     */
    portDefineUpdate (record) {
      ~this.selectedRow ? 
        this.$set(this.data, this.selectedRow, record) : 
        this.data.push(record);
      this.updated();
    },
    // UI: 添加操作
    handleAdd () {
      this.selectedRow = -1;
      this.$refs.editForm.load({order: this.data.length + 1});
    },
    // UI: 启用编辑模式
    handleEdit (index, record) {
      this.selectedRow = index;
      this.$refs.editForm.load(record);
    },
    // UI: 删除操作
    handleRemove (index) {
      this.$delete(this.data, index);
      this.updated();
    },
    /**
     * UI: 拖拽结束后，重新设置排序属性
     */
    handleDragEnd (e) {
      const from = e.oldIndex;
      const to = e.newIndex;
      // 是否从小到大？
      const isRise = from < to;
      // 如果是从小到大，那么起始值是`from`，否则是`to`;
      const begin = isRise ? from : to;
      // 如果是从小到大，那么终止值是`to`，否则是`from`;
      const end = isRise ? to : from;
      this.data.forEach((record) => {
        const { order } = record;
        // 只调整`[begin, end]`中间段的排序数据
        if (begin + 1 <= order && order <= end + 1) {
          // 起始点直接拖到终点
          if (order === from + 1) {
            this.$set(record, 'order', to + 1);
          } else {
            // 如果是从小拖到大，则中间段-1，如果是从大拖到小，则中间段+1
            this.$set(record, 'order', order + (isRise ? -1 : 1));
          }
        }
      });
    },
    getVarsArray (vars) {
      return split2array(',', vars);
    },
    formatType (record) {
      return this.portTypeGroup[record.type][record.name];
    }
  }
};
// 列信息
const columns = [{
  title: '#',
  dataIndex: 'order',
  scopedSlots: { customRender: 'order' },
  width: 24,
},{
  title: '端口',
  dataIndex: 'port',
  scopedSlots: { customRender: 'port' },
  width: 80,
}, {
  title: '类型',
  dataIndex: 'type',
  scopedSlots: { customRender: 'type' },
  width: 80,
}, {
  title: '顺序',
  dataIndex: 'typeIndex',
  scopedSlots: { customRender: 'typeIndex' },
  width: 80,
}, {
  title: '名称',
  dataIndex: 'name',
  scopedSlots: { customRender: 'name' },
  width: 80,
}, {
  title: '变量',
  dataIndex: 'vars',
  scopedSlots: { customRender: 'vars' },
}, {
  dataIndex: 'operation',
  slots: { title: 'operationTitle' },
  scopedSlots: { customRender: 'operation' },
  width: 68
}];
</script>

<style lang="less" scoped>
</style>
