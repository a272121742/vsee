<template>
  <div>
    <!-- 变量编辑 -->
    <inout-vars-edit
      ref="editForm"
      :exist-vars="existVars"
      :exist-categories="existCategories"
      @update="inoutVarsUpdate"
      @addCategory="addCategory"
    ></inout-vars-edit>
    <!-- 变量展示表格 -->
    <a-table
      :row-key="(r, i) => i"
      :columns="columns"
      :data-source="data"
      :pagination="false"
      :scroll="{ y: ('此处必须是37的或每行的倍数->', 185) }"
      size="small"
      bordered
    >
      <!-- 数字标记 -->
      <template
        slot="serial"
        slot-scope="text, record, index"
      >
        {{ index + 1 }}
      </template>
      <!-- 自定义`是否保存`列-->
      <template
        slot="saved"
        slot-scope="saved"
      >
        <a-icon
          :type="saved ? 'check' : 'close'"
          :style="{color: saved ? '#1890ff' : '#f5222d'}"
        />
      </template>
      <!-- 自定义操作标题 -->
      <template
        slot="operationTitle"
      >
        <a
          v-if="editable"
          @click="handleAdd"
        ><a-icon type="plus" /></a>
        <div v-else>
          操作
        </div>
      </template>
      
      <template
        v-if="editable"
        slot="operation"
        slot-scope="text, record, index"
      >
        <a
          @click="() => handleEdit(index, record)"
        ><a-icon type="edit" /></a>
        <a
          @click="() => handleRemove(index)"
        ><a-icon type="delete" /></a>
      </template>
    </a-table>
  </div>
</template>

<script>
import { pipe, clone, partialRight, keys, map, prop, move, sortBy, without, uniq } from 'ramda';
import { clearObserver, string2json, map2list, list2map, string2array } from '@lib/util';
/**
 * 模型变量的表格组件
 * 组件模式：
 *  1. 外部将字符串数据传入组件内部，渲染成数组
 *  2. 数组列表进行增删改的操作后，触发上层组件的`update`事件
 */
export default {
  name: 'InoutVars',
  components: {
    InoutVarsEdit: () => import('./InoutVarsEdit.vue')
  },
  props: {
    /**
     * 是否可编辑，默认false
     */
    editable: {
      type: Boolean,
      default: true
    },
    /**
     * 传入的标准列表数据源，无需像上面一样转换
     */
    dataSource: {
      type: Array,
      default: () => ([])
    },
  },
  data () {
    return {
      // 表格列信息
      columns: columns,
      // 表格数据
      data: [],
      // 操作行
      selectedRow: -1,
    }
  },
  computed: {
    // 计算已经存在的变量
    existVars () {
      return map(prop('name'), this.data);
    },
    // 计算已经存在的分类
    existCategories () {
      console.log('已经有分类', without(['', undefined, null], uniq(map(prop('category'), this.data))));
      return without([''], uniq(map(prop('category'), this.data)));
    }
  },
  watch: {
    dataSource: {
      immediate: true,
      handler () {
        this.refresh();
      }
    }
  },
  created () {

  },
  methods: {
    /**
     * 数据刷新，数据由上层组件字符串向下传递获得
     */
    refresh () {
      this.$set(this, 'data', [...this.dataSource]);
    },
    /**
     * 内部数据更新结束
     */
    updated () {
      // 将数据发送给上层组件
      this.$emit('update', [...this.data]);
    },
    /**
     * 新增分类
     */
    addCategory (category) {
      this.existCategories.push(category);
    },
    /**
     * 端口发生变化时，调用此方法：
     * 1. 端口新增时被调用，`this.selectedRow = -1`;
     * 2. 端口修改时被调用，`this.selectedRow > -1`;
     */
    inoutVarsUpdate (record) {
      ~this.selectedRow ? 
        this.$set(this.data, this.selectedRow, record) : 
        this.data.push(record);
      this.updated();
    },
    // UI: 添加操作
    handleAdd () {
      this.selectedRow = -1;
      this.$refs.editForm.load({});
    },
    // UI: 启用编辑模式
    handleEdit (index, record) {
      this.selectedRow = index;
      console.log(record);
      this.$refs.editForm.load(record);
    },
    // UI: 删除操作
    handleRemove (index) {
      this.$delete(this.data, index);
      this.updated();
    },
  }
};
// 列信息
const columns = [{
  title: '#',
  dataIndex: 'serial',
  scopedSlots: { customRender: 'serial' },
  width: 24,
},{
  title: '名称',
  dataIndex: 'name',
  scopedSlots: { customRender: 'name' },
  width: 100,
}, {
  title: '分类',
  dataIndex: 'category',
  scopedSlots: { customRender: 'category' },
  width: 100,
},{
  title: '默认值',
  dataIndex: 'defvalue',
  scopedSlots: { customRender: 'defvalue' },
  width: 80,
}, {
  title: '单位',
  dataIndex: 'unit',
  scopedSlots: { customRender: 'unit' },
  width: 100,
}, {
  title: '是否保存',
  dataIndex: 'saved',
  scopedSlots: { customRender: 'saved' },
  width: 80,
}, {
  title: '描述',
  dataIndex: 'desc',
  scopedSlots: { customRender: 'desc' },
}, {
  dataIndex: 'operation',
  slots: { title: 'operationTitle' },
  scopedSlots: { customRender: 'operation' },
  width: 68
}];
</script>

<style lang="less" scoped>
  
</style>
