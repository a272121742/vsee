<template>
  <a-modal
    :width="600"
    title="编辑模型属性"
    :visible="visible"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-form
      class="modal-edit-form"
      :form="form"
    >
      <a-tabs
        ref="formTab"
        default-active-key="1"
      >
        <a-tab-pane
          tab="基础属性"
          key="1"
        >
          <a-form-item
            label="模型名称"
          >
            <a-input
              disabled
              v-decorator="[
                'name',
              ]"
              placeholder="请输入模型名称"
            >
            </a-input>
          </a-form-item>
          <a-form-item
            label="模型编号"
          >
            <a-input
              v-decorator="[
                'nodeID', 
                {
                  validateFirst: true,
                  rules: [
                    { required: true, message: '模型编号不能为空'}, 
                    { pattern: /^[A-Za-z][A-Za-z0-9_-]*$/, message: '模型编号请遵循变量命名规则' },
                  ]
                }
              ]"
              placeholder="请输入模型编号"
            />
          </a-form-item>
          <a-form-item
            label="模型描述"
          >
            <a-input
              v-decorator="[
                'desc', 
              ]"
              placeholder="请输入模型描述"
            />
          </a-form-item>
        </a-tab-pane>
        <a-tab-pane
          tab="模型代码"
          key="2"
          force-render
        >
          <codemirror
            ref="codeEdit"
            :value="codestr"
            :options="codeEditOptions"
          ></codemirror>
        </a-tab-pane>
        <!-- <a-tab-pane
          tab="其他属性"
          key="3"
        >
          Content of Tab Pane 3
        </a-tab-pane> -->
      </a-tabs>
    </a-form>
  </a-modal>
</template>

<script>
export default {
  name: 'ModelEdit',
  components: {
    Codemirror: () => (
      import('codemirror/mode/python/python'),
      import('codemirror/addon/selection/active-line'),
      import('vue-codemirror-lite/codemirror')
    )
  },
  data () {
    return {
      record: {},
      form: null,
      visible: false,
      codestr: '',
      codeEditOptions: {
        mode: 'python',
        lineNumbers: true,
        extraKeys: {'Ctrl-Space': 'autocomplete'},
        styleActiveLine: true
      }
    }
  },
  computed: {
    codeEdit () {
      return this.$refs.codeEdit.editor;
    }
  },
  watch: {
    record () {
      this.form.updateFields({
        nodeID: this.$form.createFormField({value: this.record.nodeID}),
        name: this.$form.createFormField({value: this.record.name}),
        desc: this.$form.createFormField({value: this.record.desc}),
        codestr: this.$form.createFormField({value: this.record.codestr}),
      });
    }
  },
  created () {
    this.form = this.$form.createForm(this, {
      mapPropsToFields: () => ({
        nodeID: this.$form.createFormField({value: this.record.nodeID}),
        name: this.$form.createFormField({value: this.record.name}),
        desc: this.$form.createFormField({value: this.record.desc}),
        codestr: this.$form.createFormField({value: this.record.codestr}),
      })
    });
  },
  methods: {
    /**
     * 加载数据
     */
    load (data) {
      this.visible = true;
      this.$set(this, 'record', {...data});
      this.codestr = this.record.codestr;
    },
    handleOk () {
      this.form.validateFieldsAndScroll(err => {
        if (!err) {
          const codestr = this.codeEdit.getValue();
          const data = this.form.getFieldsValue();
          this.visible = false;
          this.$emit('update', {...this.record, ...data, codestr});
          this.clear();
        } else {
          this.$refs.formTab.$children[0].setActiveKey('1');
        }
      });
    },
    handleCancel () {
      this.visible = false;
    },
    /**
     * 清除表单数据
     */
    clear () {
      this.$nextTick(() => {
        this.$set(this, 'record', {});
      })
    },
  }
}
</script>

<style lang="less" scoped>
  .modal-edit-form {
    margin-top: -24px;
    margin-bottom: -24px;
  }
</style>