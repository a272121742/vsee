import api from '../api/stdnode';

export default {
  getAllStdnode: () => api.getAllStdnode(),
  getStdnode: (store, id) => api.getStdnode(id),
  addStdnode: (store, stdnode) => api.addStdnode(stdnode),
  updateStdnode: (store, stdnode) => api.updateStdnode(stdnode),
  removeStdnode: (store, stdnode) => api.removeStdnode(stdnode),
  
  // loadData: ({ commit }, token) => {
  //   return api.getUsers().then(data => {
  //     commit('setData', data);
  //   })
  // },
  // deleteData: ({commit}, id) => {
  //   api.deleteUser(id).then(data => {

  //   });
  // },
  // getTreeData: () => {
  //   return api.getTreeData()
  // },
  // getstdnode: (store, id) => {
  //   return api.getStdnode(id);
  // },
  // getnode: (store, id) => {
  //   return api.getNode(id);
  // },
  // updateStdNode (store, stdNode) {
  //   return api.updateStdNode(stdNode);
  // }
  
};