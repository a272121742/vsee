<template>
  <a-row :gutter="gutter">
    <!-- 菜单树 -->
    <a-col :span="6">
      <a-card
        style="height: 100%; border: none;"
        title="标准模型"
      >
        <menu-tree
          :data-source="treeData"
          :search="true"
          @onDelete="deleteMenuTreeItem"
          @onEdit="editMenuTreeItem"
          @onAdd="addMenuTreeItem"
          @onSelect="selectMenuTreeItem"
        >
        </menu-tree>
      </a-card>
    </a-col>
    <a-col :span="18">
      <a-row
        style="height: 60%;"
      >
        <a-col
          :span="24"
        >
          <a-tabs
            default-active-key="4"
            style="height: 100%; background: #FFF"
          >
            <template slot="tabBarExtraContent">
              <div 
                v-if="stdnode.id"
                style="margin-right: 8px;"
              >
                <a
                  v-if="editable"
                  slot="extra"
                  @click="editModel"
                  style="padding-right: 8px;"
                >
                  <a-icon type="edit" />
                </a>
                <a
                  v-if="editable"
                  style="padding-right: 8px;"
                >
                  <a-icon
                    type="save"
                    @click="saveStdnode"
                    :disabled="!editable"
                  ></a-icon>
                </a>
                编辑模式 <a-switch @change="checked => editable = checked" />
                
                
                <!-- <a-button
                  type="primary"
                  size="small"
                  @click="saveStdnode"
                  :disabled="!editable"
                >
                  保存
                </a-button> -->
              </div>
            </template>
            <a-tab-pane
              tab="模型属性"
              key="1"
            >
              <model-props-edit
                ref="editModelForm"
                @update="handleUpdateModel"
              ></model-props-edit>
              <model-props-table
                style="height: 100%"
                :editable="show"
                :record="stdnode"
              >
              </model-props-table>
            </a-tab-pane>
            <a-tab-pane
              tab="模型代码"
              key="2"
            >
              <codemirror
                :value="stdnode.codestr"
                :options="codeEditOptions"
              ></codemirror>
            </a-tab-pane>
            <a-tab-pane
              tab="端口定义"
              key="3"
            >
              <port-define-table
                v-if="selectedTab === 'portDefine'"
                :editable="show"
                :data-source="portDefine"
                :optional-vars="optionalVars"
                @update="handleUpdatePortDefine"
              ></port-define-table>
            </a-tab-pane>
            <a-tab-pane
              tab="端口定义"
              key="4"
            >
              <PortDefineDot
                :editable="show"
                :source-map="portDefine1"
                :optional-vars="optionalVars"
                @update="handleUpdatePortDefine"
              >
              </PortDefineDot>
            </a-tab-pane>
          </a-tabs>
        </a-col>
      </a-row>
      <a-row
        style="margin-top: 12px;"
      >
        <a-col
          :span="24"
        >
          <a-tabs
            v-model="selectedVarsTab"
            style="height: calc(40% - 12px); min-height: 231px; background: #FFF"
          >
            <a-tab-pane
              v-if="!varsGroupList.length"
              key=""
              class="ant-table-placeholder"
            >
              <template slot="tab">
                <span style="color: rgba(0, 0, 0, 0.45)">暂无分组</span>
              </template>
              暂无数据
            </a-tab-pane>
            <!-- 添加按钮 -->
            <!-- <a-icon
              v-if="show"
              style="fontSize: 16px; margin-right: 8px;"
              slot="tabBarExtraContent"
              type="plus"
              @click="addVarsGroupTab"
            /> -->
            <a-tab-pane
              v-for="(group) in varsGroupList"
              :key="group.title"
              :closable="true"
            >
              <!-- 可编辑的tab页头-->
              <template slot="tab">
                <!-- <span v-if="group.editable">
                  <input
                    v-focus
                    class="ant-input"
                    style="width: 80px;"
                    :value="group.title"
                    @change="e => valiGroupName(e, group)"
                    @keyup.enter="e => (group.editable = false)"
                    @blur="e => (group.editable = false)"
                  >
                </span>
                <span
                  v-else
                  @dblclick="e => (varsGroupList.forEach(item => item.editable = false),group.editable = true)"
                >
                  {{ group.title }}
                </span>
                <a-popconfirm
                  title="确认删除吗？"
                  @confirm="removeVarsGroupTab(index)"
                >
                  <a-icon
                    v-if="show"
                    class="ant-tabs-close-x"
                    type="close"
                  />
                </a-popconfirm> -->
                {{ group.title }}
              </template>
              <inout-vars-table
                :editable="show"
                :data-source="group.dataSource"
                @update="list => handleUpdateInoutVars(group, list)"
              ></inout-vars-table>
            </a-tab-pane>
          </a-tabs>
        </a-col>
      </a-row>
    </a-col>
  </a-row>
</template>

<script>
import { createNamespacedHelpers } from 'vuex';
import {pipe, forEachObjIndexed, partialRight, clone, keys, groupBy, prop, map, addIndex} from 'ramda';
import {string2json, map2list, list2map} from '@lib/util';

const { mapActions } = createNamespacedHelpers('ModelManagement');
const mapIndexed = addIndex(map);
/**
 * 累加器
 * @param {Boolean} flag - 是否重制累加
 * @returns {Number} - 返回计数
 */
const increment = (function () {
  let count = 0;
  return function (flag = false) {
    return flag ? (count = 0, ++count) : ++count;
  };
})();

export default {
  name: 'StandardModelDefinition',
  components: {
    MenuTree: () => import('@comp/Tree/MenuTree'),
    ModelPropsTable: () => import('../view/ModelProps'),
    PortDefineTable: () => import('../view/PortDefine'),
    PortDefineDot: () => import('../view/PortDefineDot'),
    // DotImage: () => import('@comp/DotImage/DotImage'),
    // PortDefineForm: () => import('../view/PortDefineEditForm'),
    InoutVarsTable: () => import('../view/InoutVars'),
    ModelPropsEdit: () => import('../view/ModelPropsEdit.vue'),
    // 代码展示组件
    Codemirror: () => (
      // 代码类型-python
      import('codemirror/mode/python/python'),
      // 选中行激活
      import('codemirror/addon/selection/active-line'),
      // 代码展示组件的核心部分
      import('vue-codemirror-lite/codemirror')
    )
  },
  data () {
    return {
      // 栅格配置
      gutter: { xs: 4, sm: 8, md: 12 },
      // tree的数据
      treeData: [],
      // 是显示图片模型还是显示代码
      showModel: 'model',
      stdnode: {
        portDefine: '',
        inoutVars: '',
        codestr: ''
      },
      // 是否开启编辑模式
      editable: false,
      codeEditOptions: {
        mode: 'python',
        lineNumbers: true,
        lineWrapping: true,
        readOnly: 'nocursor',
        styleActiveLine: true
      },
      // 标签页配置
      tabList: [{
        key: 'portDefine', 
        name: '端口定义',
        // tab: '端口定义',
        scopedSlots: {tab: 'portDefine'}
      }, {
        key: 'inoutVars', 
        name: '模型变量',
        // tab: '模型变量',
        scopedSlots: {tab: 'inoutVars'}
      }],
      // 默认选中Tab页
      selectedTab: 'portDefine',
      // 变量分组
      varsGroupList: [],
      selectedVarsTab: '',
      // 分组数据
      varsGroupMap: {

      }
    }
  },
  computed: {
    show () {
      return this.editable && this.stdnode.hasOwnProperty('id');
    },
    /**
     * 端口定义的数据列表
     */
    portDefine () {
      return this.convertPortDefine(this.stdnode.portDefine);
    },
    portDefine1 () {
      console.log('转换portdefined', JSON.parse(this.stdnode.portDefine || '{}'));
      return JSON.parse(this.stdnode.portDefine || '{}');
    },
    portDefineCount () {
      return this.portDefine.length;
    },
    /**
     * 模型参数的数据列表
     */
    inoutVars () {
      return this.convertInoutVars(this.stdnode.inoutVars);
    },
    inoutVarsCount () {
      return this.inoutVars.length;
    },
    // 可选变量
    optionalVars () {
      return keys(string2json(this.stdnode.inoutVars));
    }
  },
  created () {
    // 1. 渲染Tree
    this.getAllStdnode().then(res => {
      this.treeData = clone(res.result);
    });
  },
  activated () {
    console.log('标准模型定义页面激活');
  },
  deactivated () {
    console.log('标准模型定义页面失活');
  },
  methods: {
    // 映射模块
    ...mapActions([
      'getAllStdnode',
      'getStdnode',
      'addStdnode',
      'updateStdnode',
      'removeStdnode'
    ]),
    // 转码 String -> Array<Object>
    convertPortDefine: pipe(string2json, map2list('port')),
    // 转码 Array<Object> -> String
    reconvertPortDefine: pipe(list2map('port'), partialRight(JSON.stringify, [null, 2])),
    // 转码 String -> Array<Object>
    convertInoutVars: pipe(string2json, map2list('name')),
    // 转码 Array<Object> -> String
    reconvertInoutVars: pipe(list2map('name'), partialRight(JSON.stringify, [null, 2])),
    /**
     * 增加菜单项
     * @param {*} parent - 父节点信息，该信息中只有`name`可用；
     * @param Function next - 回调函数， 传回true则表示操作成功。
     */
    addMenuTreeItem ({name, type}, next) {
      this.addStdnode({name, type}).then(res => {
        const stdnode = res.result;
        const typeIndex = this.treeData.findIndex(item => item.type === type);
        this.treeData[typeIndex].children.push({
          ...res.result,
          key: res.result.id,
          title: res.result.name
        });
        next(res.success);
      });
    },
    /**
     * @param {*} parent - 子节点信息，该信息中只有`name`可用；
     * @param Function next - 回调函数， 传回true则表示操作成功。
     */
    editMenuTreeItem (child, next) {
      this.updateStdnode(child).then(res => {
        const stdnode = res.result;
        const typeIndex = this.treeData.findIndex(item => item.type === stdnode.type);
        const dataIndex = this.treeData[typeIndex].children.findIndex(item => item.id === stdnode.id);
        const oldStdnode = this.treeData[typeIndex].children[dataIndex];
        this.$set(this.treeData[typeIndex].children, dataIndex, {...oldStdnode, title: stdnode.name, name: stdnode.name});
        next(res.success);
      });
    },
    /**
     * 菜单树删除
     * @param {*} child - 要删除的节点；
     */
    deleteMenuTreeItem (child) {
      this.removeStdnode(child).then(res => {
        const stdnode = res.result;
        const typeIndex = this.treeData.findIndex(item => item.type === stdnode.type);
        const dataIndex = this.treeData[typeIndex].children.findIndex(item => item.id === stdnode.id);
        this.$delete(this.treeData[typeIndex].children, dataIndex);
      });
    },
    /**
     * 菜单树选择
     * @param {*} record - 已选择到的节点数据
     */
    selectMenuTreeItem (record) {
      // 设置当前选择的stdnode
      this.loadStdnode(record.data.id);
    },
    // 获取std相应内容并渲染
    loadStdnode (id) {
      this.getStdnode(id).then(res => {
        console.log('获取到数据', res.result);
        this.$set(this, 'stdnode', res.result);
        // 对数据进行转换和分组
        const inoutVars = this.convertInoutVars(res.result.inoutVars);
        const inoutVarsGroups = groupBy(prop('group') ,inoutVars);
        const varsGroupList = Object.keys(inoutVarsGroups).map(title => {
          return {
            title,
            editable: false,
            dataSource: inoutVarsGroups[title]
          }
        });
        console.log(varsGroupList);
        this.$set(this, 'varsGroupList', varsGroupList);
        this.$set(this, 'selectedVarsTab', varsGroupList[0].title);
      });
    },
    // TODO: 待完善
    changeShowModel () {
      console.log(this.showModel);
    },
    
    // 触发更新
    handleUpdateModel (stdnode) {
      this.$set(this, 'stdnode', {...this.stdnode, ...stdnode});
    },
    handleUpdatePortDefine (portDefineList) {
      this.$set(this.stdnode, 'portDefine', JSON.stringify(portDefineList));
      this.$set(this.stdnode, 'portNum', this.portDefineCount);
    },
    handleUpdateInoutVars (group, inoutVarsList) {
      console.log(group, inoutVarsList);
      inoutVarsList.forEach(item => {
        item.group = group.title;
      });
      group.dataSource = inoutVarsList;
      const inoutVars = this.varsGroupList.reduce((list, item) => {
        return list.concat(item.dataSource);
      }, []);
      console.log(inoutVars);
      this.$set(this.stdnode, 'inoutVars', this.reconvertInoutVars(inoutVars));
    },
    /**
     * 弹出编辑模型的表单
     */
    editModel () {
      this.$refs.editModelForm.load(this.stdnode);
    },
    // 保存
    saveStdnode () {
      console.log(this.stdnode);
      this.$set(this, 'varsGroupList', this.varsGroupList.filter(item => item.dataSource.length));
      this.updateStdnode({...this.stdnode}).then(res => {
        if (res.success) {
          this.$set(this, 'stdnode', res.result);
          this.$message.success('保存成功！');
        } else {
          this.$message.error('保存失败！');
        }
      });
    },
    onChange (checked) {
      console.log(checked);
    },
    tabChange (key) {
      this.selectedTab = key;
    },
    /**
     * 新增或删除变量标签页
     */
    editVarsTab (targetKey, action) {
      console.log('点击了', action, targetKey);
      this[action + 'VarsGroupTab'](targetKey);
    },
    // 增加变量分组标签页
    addVarsGroupTab () {
      this.varsGroupList.forEach(group => {
        // 设置所有的组标题为不可编辑
        group.editable = false;
      });
      const len = this.varsGroupList.length;
      // 添加新分组
      this.varsGroupList.push({
        title: '新分组' + increment(),
        editable: false,
        dataSource: []
      });
      this.selectedVarsTab = this.varsGroupList[len].title;
    },
    // 删除变量分组标签页
    removeVarsGroupTab (index) {
      this.varsGroupList.splice(index, 1);
      this.selectedVarsTab = this.varsGroupList[0] ? this.varsGroupList[0].title : '';
    },
    // 验证组名
    valiGroupName (e, group) {
      const groupName = e.target.value;
      // 查看是否有重复
      if (~this.varsGroupList.findIndex(group => group.title === groupName)) {
        this.$message.warning('分组名称重复，系统帮您做了自动修改！');
        group.title = groupName + '.1';
      } else if (!groupName) {
        this.$message.warning('分组名称为空，系统帮您做了自动修改！');
        group.title = '新分组' + increment();
      } else {
        group.title = groupName;
      }
      return false;
    },
    groupNameChange (input, index) {
      this.varsGroupList[index].title = input.value;
    },
  }
}
</script>

<style lang="less" scoped>
  .ant-row {
    height: 100%;
  }
  /deep/ [class|=ant-col] {
    height: 100%;
  }
  .ant-card-bordered {
    box-shadow: 0 2px 8px rgba(0,0,0,.15);
    &:hover {
      box-shadow: 0 2px 8px rgba(0,0,0,.25);
    }
  }
  .ant-tabs {
    box-shadow: 0 2px 8px rgba(0,0,0,.15);
    &:hover {
      box-shadow: 0 2px 8px rgba(0,0,0,.25);
    }
    /deep/ .ant-tabs-content {
      height: calc(100% - 40px);
      .ant-tabs-tabpane {
        height: 100%;
      }
    }
    /deep/ .vue-codemirror-wrap {
      height: 100%;
      .CodeMirror {
        height: 100%;
      }
    }
    /deep/ .ant-tabs-bar {
      margin-bottom: 0px;
    }
    /deep/ .ant-table-body {
      margin: 0px;
      padding: 0px;
    }
    // 穿透表格，设置超出部分隐藏
    /deep/ .ant-table{
      table {
        width: 100%; /*必须设置，否则还是会拉长单元格*/
        table-layout: fixed;/*只有定义表格的算法为fixed,th才有效果*/
        word-wrap:break-all;
      }
      th > div, td {
        overflow:hidden;/*超出长度的文字隐藏*/
        text-overflow:ellipsis;/*文字隐藏以后添加省略号*/
        white-space:nowrap;/*强制不换行*/
        word-break:keep-all;/*文字不换行*/
      }
    }
  }
  /*穿透卡片组件，设置标题紧凑*/
  .ant-card {
    /deep/ .ant-card-head {
      min-height: 32px;
      padding: 0px 8px;
      .ant-card-head-title {
        padding: 8px 8px;
      }
    }
    /deep/ .ant-card-body {
      padding: 0px;
      border-top: 1px solid #e8e8e8;
    }
    /deep/ .ant-card-extra {
      padding: 0px;
    }
    /deep/ .ant-menu-inline {
      border-right: none;
    }
  }
</style>


