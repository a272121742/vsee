import Vue from 'vue';
import App from './App';

// 加载本地组件
import Antd from 'ant-design-vue';
import 'ant-design-vue/dist/antd.css'

// 加载Chart组件
import Viser from 'viser-vue';
// 代码编辑器
// import VueCodeMirror from 'vue-codemirror-lite';

// 加载本地路由
import { router, appRouters } from './bootstrap-router';
// 加载本地store
import store from './bootstrap-store';
// 加载本地化文件
import i18n from './bootstrap-i18n';
// 加载指令插件
import('./lib/auto-directive');

////
import('./lib/socket');
////

Vue.config.productionTip = false;
Vue.use(Antd);
Vue.use(Viser);
// Vue.use(VueCodeMirror);


router.beforeEach((to, from, next) => {
  console.log(to, from);
  const toLogin = to.matched.some(r => r.path === '/login');
  const isLogin = store.state.login.isLogin;
  // 如果已经登陆，则获取token信息，重新发起请求获取用户信息
  if (isLogin) {
    store.dispatch('checkLogin');
  }
  // 如果进入的是登陆界面，且已经登陆过
  if (toLogin && isLogin) {
    next({
      path: '/'
    });
    
  }
  // 如果进入的不是登陆界面，且未登陆过
  if (!toLogin && !isLogin) {
    next({
      path: '/login',
      query: {
        redirect: to.fullPath
      }
    });
  }
  // 登陆过但不是登陆界面就直接放行，或者没登陆但进入的是登陆界面直接放行
  next();
  
});

router.afterEach((to, from, next) => {
  window.scrollTo(0, 0);

});

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  i18n,
  render: h => h(App)
});
